(function(){
"use strict";

/* ============================================================
   DATA MODEL — seeded in-memory, persisted to localStorage
   ============================================================ */
const STORAGE_KEY = "cos_demo_state_v2";

function uid(prefix){ return prefix + "_" + Math.random().toString(36).slice(2,9); }
function pad(n){ return n<10 ? "0"+n : ""+n; }
function todayISO(){ const d=new Date(); return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate()); }
function addDays(iso, n){ const d=new Date(iso+"T00:00:00"); d.setDate(d.getDate()+n); return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate()); }
function dayName(iso){ return new Date(iso+"T00:00:00").toLocaleDateString(undefined,{weekday:'short'}); }
function fmtDateLong(iso){ return new Date(iso+"T00:00:00").toLocaleDateString(undefined,{weekday:'long', year:'numeric', month:'long', day:'numeric'}); }
function fmtDateShort(iso){ return new Date(iso+"T00:00:00").toLocaleDateString(undefined,{month:'short', day:'numeric'}); }
function fmtDMY(iso){ return iso.split("-").reverse().join("/"); }
function timeToMin(t){ const [h,m]=t.split(":").map(Number); return h*60+m; }
function minToTime(m){ const h=Math.floor(m/60), mm=m%60; return pad(h)+":"+pad(mm); }
function fmtTime(t){ const [h,m]=t.split(":").map(Number); const ap=h>=12?"PM":"AM"; const hh=((h+11)%12)+1; return hh+":"+pad(m)+" "+ap; }
function esc(s){ return (s==null?"":String(s)).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

const THERAPISTS = [
  {id:"th_tendai", name:"Dr. Tendai Moyo", color:"#3B6FA0"},
  {id:"th_natasha", name:"Dr. Natasha Phiri", color:"#6E51C0"},
  {id:"th_brian", name:"Dr. Brian Ncube", color:"#0F6E5C"},
];
const ROOMS = ["Room 1","Room 2","Room 3","Gym Floor"];
const APPT_TYPES = [
  {id:"initial", name:"Initial Assessment", duration:60, color:"#3B6FA0", room:true},
  {id:"followup", name:"Follow-up", duration:30, color:"#0F6E5C", room:true},
  {id:"physio", name:"Physiotherapy Session", duration:45, color:"#6E51C0", room:true},
  {id:"sports", name:"Sports Rehabilitation", duration:45, color:"#B5502A", room:true},
  {id:"postop", name:"Post-operative Rehabilitation", duration:60, color:"#B4791E", room:true},
  {id:"consult", name:"Consultation", duration:30, color:"#54645C", room:false},
  {id:"review", name:"Review", duration:20, color:"#3B6FA0", room:false},
  {id:"discharge", name:"Discharge Assessment", duration:30, color:"#0F6E5C", room:true},
];
const INV_CATEGORIES = ["Clinical Supplies","Rehabilitation Equipment","Office Supplies"];

function seedState(){
  const today = todayISO();
  const patients = [
    {id:"P-1001", first:"John", last:"Moyo", dob:"1988-04-12", gender:"Male", phone:"+263 77 000 0101", email:"john.moyo@example.com",
     address:"14 Enterprise Rd, Harare", emergency:"Grace Moyo · +263 77 000 0102", reason:"Lower back pain", referral:"Self",
     referringDoctor:"", complaint:"Chronic lower back pain, 3 months", conditions:"None reported", allergies:"None known", medication:"Ibuprofen as needed",
     insurance:"Sample Health Plan A", membership:"CM-88213", commPref:"SMS", consent:"Signed", therapist:"th_tendai", createdAt: addDays(today,-40)},
    {id:"P-1002", first:"Sarah", last:"Kufa", dob:"1995-09-02", gender:"Female", phone:"+263 77 000 0103", email:"sarah.kufa@example.com",
     address:"22 Josiah Tongogara Ave, Harare", emergency:"Tapiwa Kufa · +263 77 000 0104", reason:"Post-op knee rehab", referral:"Referring Doctor",
     referringDoctor:"Dr. F. Chirwa", complaint:"ACL reconstruction follow-up", conditions:"None", allergies:"Penicillin", medication:"None",
     insurance:"Sample Health Plan B", membership:"FM-33210", commPref:"Email", consent:"Signed", therapist:"th_natasha", createdAt: addDays(today,-70)},
    {id:"P-1003", first:"Tapiwa", last:"Marufu", dob:"1979-11-23", gender:"Male", phone:"+263 77 000 0105", email:"t.marufu@example.com",
     address:"5 Borrowdale Rd, Harare", emergency:"Chido Marufu · +263 77 000 0106", reason:"Shoulder mobility", referral:"Referring Doctor",
     referringDoctor:"Dr. N. Sibanda", complaint:"Frozen shoulder, right side", conditions:"Type II diabetes", allergies:"None known", medication:"Metformin",
     insurance:"Sample Health Plan A", membership:"CM-10029", commPref:"Phone", consent:"Signed", therapist:"th_brian", createdAt: addDays(today,-12)},
    {id:"P-1004", first:"Ruvimbo", last:"Chuma", dob:"2001-02-18", gender:"Female", phone:"+263 77 000 0107", email:"ruvimbo.c@example.com",
     address:"9 Samora Machel Ave, Harare", emergency:"Ndau Chuma · +263 77 000 0108", reason:"Sports injury — ankle sprain", referral:"Coach",
     referringDoctor:"", complaint:"Grade II ankle sprain, left", conditions:"None", allergies:"None known", medication:"None",
     insurance:"Uninsured", membership:"", commPref:"SMS", consent:"Signed", therapist:"th_brian", createdAt: addDays(today,-3)},
    {id:"P-1005", first:"Farai", last:"Gumbo", dob:"1966-06-30", gender:"Male", phone:"+263 77 000 0109", email:"farai.gumbo@example.com",
     address:"3 Chinhoyi St, Harare", emergency:"Netsai Gumbo · +263 77 000 0110", reason:"Chronic neck pain", referral:"Self",
     referringDoctor:"", complaint:"Cervical spondylosis", conditions:"Hypertension", allergies:"None known", medication:"Amlodipine",
     insurance:"Sample Health Plan B", membership:"FM-55810", commPref:"Email", consent:"Signed", therapist:"th_tendai", createdAt: addDays(today,-200)},
  ];

  function mk(pid, therapist, type, date, time, status, room){
    const t = APPT_TYPES.find(x=>x.id===type);
    return {id:uid("A"), patientId:pid, therapist, type, date, start:time,
      end:minToTime(timeToMin(time)+t.duration), status, room: room||(t.room?ROOMS[Math.floor(Math.random()*3)]:"—"), notes:""};
  }

  const appointments = [
    mk("P-1001","th_tendai","initial",today,"09:00","confirmed","Room 2"),
    mk("P-1002","th_natasha","followup",today,"09:30","checkedin","Room 1"),
    mk("P-1003","th_brian","physio",today,"10:00","insession","Room 3"),
    mk("P-1004","th_brian","sports",today,"11:00","confirmed","Gym Floor"),
    mk("P-1005","th_tendai","review",today,"11:30","completed","—"),
    mk("P-1001","th_tendai","followup",today,"13:00","confirmed","Room 2"),
    mk("P-1002","th_natasha","postop",today,"14:00","noshow","Room 1"),
    mk("P-1003","th_brian","consult",today,"15:00","confirmed","—"),
    mk("P-1004","th_natasha","physio",today,"15:30","confirmed","Room 1"),
    mk("P-1005","th_tendai","discharge", addDays(today,1),"09:00","confirmed","Room 2"),
    mk("P-1001","th_brian","physio", addDays(today,1),"10:00","confirmed","Room 3"),
    mk("P-1002","th_natasha","followup", addDays(today,-1),"09:00","completed","Room 1"),
    mk("P-1003","th_tendai","physio", addDays(today,2),"09:30","confirmed","Room 2"),
    mk("P-1004","th_brian","sports", addDays(today,2),"11:00","confirmed","Gym Floor"),
    mk("P-1005","th_natasha","review", addDays(today,-2),"14:00","cancelled","—"),
  ];

  const checkIns = appointments.filter(a=>a.status==="checkedin"||a.status==="insession").map(a=>({
    id:uid("CI"), appointmentId:a.id, patientId:a.patientId, checkedInAt:"08:52", status: a.status
  }));

  const suppliers = [
    {id:"SUP-1", name:"Sample Medical Supplies", contact:"Tanaka Moyana", phone:"+263 77 000 0111", email:"orders@example.com",
     address:"Msasa, Harare", products:"Tape, gloves, ultrasound gel", lastOrder: addDays(today,-18), outstanding:1},
    {id:"SUP-2", name:"Sample Rehab Equipment Co", contact:"Linda Basopo", phone:"+263 77 000 0112", email:"sales@example.com",
     address:"Graniteside, Harare", products:"Resistance bands, exercise balls, weights", lastOrder: addDays(today,-45), outstanding:0},
    {id:"SUP-3", name:"Sample Office Supplies", contact:"Kudzai Mhonda", phone:"+263 77 000 0113", email:"office@example.com",
     address:"CBD, Harare", products:"Paper, toner, stationery", lastOrder: addDays(today,-9), outstanding:0},
  ];

  const inventoryItems = [
    {id:"INV-1", name:"Kinesiology Tape", sku:"KT-500", category:"Clinical Supplies", description:"5cm x 5m roll", qty:3, unit:"roll",
     min:10, reorder:20, supplier:"SUP-1", cost:2.4, price:5.0, location:"Store Room A · Shelf 2", expiry: addDays(today,25), batch:"BT-2291"},
    {id:"INV-2", name:"Disposable Gloves (M)", sku:"DG-M-100", category:"Clinical Supplies", description:"Box of 100, nitrile", qty:2, unit:"box",
     min:5, reorder:10, supplier:"SUP-1", cost:6.5, price:0, location:"Store Room A · Shelf 1", expiry: addDays(today,400), batch:"BT-3310"},
    {id:"INV-3", name:"Ultrasound Gel", sku:"UG-250", category:"Clinical Supplies", description:"250ml bottle", qty:14, unit:"bottle",
     min:6, reorder:12, supplier:"SUP-1", cost:1.8, price:0, location:"Store Room A · Shelf 2", expiry: addDays(today,50), batch:"BT-2280"},
    {id:"INV-4", name:"Electrodes (pack of 4)", sku:"EL-4PK", category:"Clinical Supplies", description:"Self-adhesive, reusable", qty:0, unit:"pack",
     min:8, reorder:16, supplier:"SUP-1", cost:3.1, price:0, location:"Store Room A · Shelf 3", expiry: addDays(today,300), batch:"BT-1187"},
    {id:"INV-5", name:"Athletic Tape", sku:"AT-38", category:"Clinical Supplies", description:"3.8cm rigid strapping tape", qty:22, unit:"roll",
     min:10, reorder:20, supplier:"SUP-1", cost:1.9, price:4.0, location:"Store Room A · Shelf 2", expiry: addDays(today,180), batch:"BT-2299"},
    {id:"INV-6", name:"Resistance Bands (set)", sku:"RB-SET5", category:"Rehabilitation Equipment", description:"5-level set", qty:9, unit:"set",
     min:4, reorder:8, supplier:"SUP-2", cost:12.0, price:0, location:"Gym Storage", expiry:"", batch:""},
    {id:"INV-7", name:"Exercise Balls (65cm)", sku:"EB-65", category:"Rehabilitation Equipment", description:"Anti-burst", qty:6, unit:"unit",
     min:3, reorder:6, supplier:"SUP-2", cost:14.5, price:0, location:"Gym Storage", expiry:"", batch:""},
    {id:"INV-8", name:"Foam Rollers", sku:"FR-90", category:"Rehabilitation Equipment", description:"90cm, high-density", qty:5, unit:"unit",
     min:4, reorder:8, supplier:"SUP-2", cost:9.0, price:0, location:"Gym Storage", expiry:"", batch:""},
    {id:"INV-9", name:"Balance Boards", sku:"BB-40", category:"Rehabilitation Equipment", description:"Wobble board", qty:2, unit:"unit",
     min:3, reorder:6, supplier:"SUP-2", cost:22.0, price:0, location:"Gym Storage", expiry:"", batch:""},
    {id:"INV-10", name:"Printer Paper (A4)", sku:"PP-A4", category:"Office Supplies", description:"Ream of 500", qty:18, unit:"ream",
     min:5, reorder:10, supplier:"SUP-3", cost:4.2, price:0, location:"Front Desk Cupboard", expiry:"", batch:""},
    {id:"INV-11", name:"Printer Toner", sku:"TN-880", category:"Office Supplies", description:"Black cartridge", qty:1, unit:"unit",
     min:2, reorder:4, supplier:"SUP-3", cost:38.0, price:0, location:"Front Desk Cupboard", expiry:"", batch:""},
  ];

  const inventoryTransactions = [
    {id:uid("TX"), itemId:"INV-1", type:"Stock Removed", qty:2, date: addDays(today,-1), user:"Rudo Chikwanha", reason:"Used in session"},
    {id:uid("TX"), itemId:"INV-4", type:"Stock Removed", qty:8, date: addDays(today,-2), user:"Rudo Chikwanha", reason:"Used in session"},
    {id:uid("TX"), itemId:"INV-9", type:"Stock Added", qty:2, date: addDays(today,-30), user:"Rudo Chikwanha", reason:"Restock delivery"},
  ];

  const purchaseRequests = [
    {id:"PR-1", items:[{itemId:"INV-4", qty:20}], supplier:"SUP-1", estCost:62.0, requestedBy:"Rudo Chikwanha", date: addDays(today,-2), status:"Submitted"},
    {id:"PR-2", items:[{itemId:"INV-11", qty:4}], supplier:"SUP-3", estCost:152.0, requestedBy:"Rudo Chikwanha", date: addDays(today,-6), status:"Approved"},
  ];

  const notifications = [
    {id:uid("N"), type:"waiting", title:"Sarah K. has been waiting 18 minutes", detail:"Checked in for 09:30 Follow-up with Dr. Natasha", time:"09:48", read:false, urgent:true},
    {id:uid("N"), type:"lowstock", title:"Low stock: Kinesiology Tape", detail:"3 rolls remaining · minimum 10", time:"08:10", read:false, urgent:false},
    {id:uid("N"), type:"outstock", title:"Out of stock: Electrodes (pack of 4)", detail:"Reorder from Sample Medical Supplies", time:"08:10", read:false, urgent:true},
    {id:uid("N"), type:"appointment", title:"New appointment booked", detail:"Ruvimbo Chuma · Sports Rehabilitation · 15:30", time:"07:55", read:true, urgent:false},
    {id:uid("N"), type:"cancellation", title:"Appointment cancelled", detail:"Farai Gumbo · Review · " + fmtDateShort(addDays(today,-2)), time:"Yesterday", read:true, urgent:false},
    {id:uid("N"), type:"expiring", title:"Kinesiology Tape expiring soon", detail:"Batch BT-2291 expires in 25 days", time:"Yesterday", read:true, urgent:false},
  ];

  return {
    patients, appointments, checkIns, suppliers, inventoryItems, inventoryTransactions, purchaseRequests, notifications,
    ui:{ view:"dashboard", sidebarCollapsed:false, calView:"week", calAnchor:today, patientFilter:"", selectedPatientId: patients[0].id, patientTab:"overview",
         invTab:"items", expiryTab:"30" }
  };
}

let state = loadState();
function loadState(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw) return JSON.parse(raw);
  }catch(e){ /* ignore, fall through to seed */ }
  return seedState();
}
function saveState(){
  try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }catch(e){ /* storage unavailable, continue in-memory */ }
}

/* ============================================================
   DERIVED HELPERS
   ============================================================ */
function patientById(id){ return state.patients.find(p=>p.id===id); }
function patientName(id){ const p=patientById(id); return p ? p.first+" "+p.last : "Unknown patient"; }
function therapistById(id){ return ALL_TH.find(t=>t.id===id); }
function therapistName(id){ const t=therapistById(id); return t? t.name : id; }
function typeById(id){ return APPT_TYPES.find(t=>t.id===id); }
function typeName(id){ const t=typeById(id); return t? t.name : id; }
function itemById(id){ return state.inventoryItems.find(i=>i.id===id); }
function supplierById(id){ return state.suppliers.find(s=>s.id===id); }
function statusClass(s){ return s.replace(/\s/g,"").toLowerCase(); }
function statusLabel(s){
  return {confirmed:"Confirmed", checkedin:"Checked In", insession:"In Session", completed:"Completed", cancelled:"Cancelled", noshow:"No Show"}[s] || s;
}
function apptsOn(date){ return state.appointments.filter(a=>a.date===date && a.status!=="cancelled" && (ROLE!=="therapist"||a.therapist===ME)); }
function invStatus(item){
  if(item.qty<=0) return "outstock";
  if(item.expiry && daysUntil(item.expiry)<=30 && daysUntil(item.expiry)>=0) return "expiring";
  if(item.qty<=item.min) return "lowstock";
  return "instock";
}
function invStatusLabel(s){ return {instock:"In Stock", lowstock:"Low Stock", outstock:"Out of Stock", expiring:"Expiring Soon"}[s]; }
function daysUntil(iso){ if(!iso) return null; const d=new Date(iso+"T00:00:00"), t=new Date(todayISO()+"T00:00:00"); return Math.round((d-t)/86400000); }
function invValue(){ return state.inventoryItems.reduce((s,i)=>s+i.qty*i.cost,0); }
function unreadNotifCount(){ return state.notifications.filter(n=>!n.read).length; }

function checkConflict(therapist, date, start, end, excludeId){
  return state.appointments.some(a=>
    a.id!==excludeId && a.therapist===therapist && a.date===date && a.status!=="cancelled" &&
    timeToMin(a.start) < timeToMin(end) && timeToMin(a.end) > timeToMin(start)
  );
}
function suggestAlternatives(date, start, end, excludeId){
  const dur = timeToMin(end)-timeToMin(start);
  const free = [];
  THERAPISTS.forEach(th=>{
    if(!checkConflict(th.id, date, start, end, excludeId)) free.push(th.name+" is free at "+fmtTime(start));
  });
  if(free.length) return free;
  // suggest next free slot for first therapist that day
  const th = THERAPISTS[0];
  for(let m=480; m<1080; m+=15){
    const s=minToTime(m), e=minToTime(m+dur);
    if(!checkConflict(th.id, date, s, e, excludeId)){ return [th.name+" is free at "+fmtTime(s)]; }
  }
  return ["No alternative slot found today"];
}

function pushNotification(type, title, detail, urgent){
  state.notifications.unshift({id:uid("N"), type, title, detail, time:"Just now", read:false, urgent:!!urgent});
  saveState();
}
function toast(msg){
  const host = document.getElementById("toast-host");
  const t = document.createElement("div");
  t.className="toast"; t.textContent=msg;
  host.appendChild(t);
  setTimeout(()=>t.remove(), 3400);
}

/* ============================================================
   RENDER: SHELL
   ============================================================ */
function setView(view){
  view = tMap(view);
  state.ui.view = view;
  document.querySelectorAll(".sb-item[data-view]").forEach(el=>el.classList.toggle("active", el.dataset.view===view));
  document.querySelectorAll("#main .view").forEach(el=>el.classList.add("hidden"));
  tEnsureView(view).classList.remove("hidden");
  renderView(view);
  saveState();
}
function renderView(view){
  if(ROLE==="therapist") return tRender(view);
  if(ROLE==="owner"||ROLE==="it") return aRender(view);
  if(view==="dashboard") renderDashboard();
  else if(view==="calendar") renderCalendar();
  else if(view==="patients") renderPatients();
  else if(view==="inventory") renderInventory();
  else if(view==="reports") renderReports();
  else if(view==="settings") renderPlaceholder("settings","Settings","Account and clinic settings for your role will appear here.");
  else if(view==="help") renderPlaceholder("help","Help &amp; Support","Need a hand? Reach the Clinic OS support team from the notification bell, or ask your clinic administrator.");
}
function renderPlaceholder(key, title, body){
  document.getElementById("view-"+key).innerHTML =
    '<div class="dash-head"><div><h1>'+title+'</h1></div></div>' +
    '<div class="panel"><div class="panel-body pad"><p style="color:var(--ink-soft);max-width:520px;">'+body+'</p></div></div>';
}

function refreshBadges(){
  const lowCount = state.inventoryItems.filter(i=> invStatus(i)==="lowstock" || invStatus(i)==="outstock").length;
  const b = document.getElementById("sb-inv-badge"); if(!b) return;
  b.textContent = lowCount;
  b.style.display = lowCount? "inline-block":"none";
}

/* ============================================================
   RENDER: DASHBOARD
   ============================================================ */
function renderDashboard(){
  const today = todayISO();
  const todays = apptsOn(today);
  const checkedIn = todays.filter(a=>a.status==="checkedin"||a.status==="insession").length;
  const completed = todays.filter(a=>a.status==="completed").length;
  const noshow = todays.filter(a=>a.status==="noshow").length;
  const newPatients = state.patients.filter(p=>p.createdAt>=addDays(today,-7)).length;
  const sorted = todays.slice().sort((a,b)=>timeToMin(a.start)-timeToMin(b.start));

  const host = document.getElementById("view-dashboard");
  host.innerHTML = `
  <div class="dash-head">
    <div>
      <h1>Good morning, Rudo</h1>
      <div class="dash-meta"><span>${fmtDateLong(today)}</span></div>
    </div>
    <button class="btn btn-primary" data-qa="book-appointment">+ New Appointment</button>
  </div>

  <div class="stat-strip">
    <div class="stat" data-stat="all"><div class="n">${todays.length}</div><div class="l">Today's Appointments</div></div>
    <div class="stat" data-stat="checkedin"><div class="n">${checkedIn}</div><div class="l">Checked In</div></div>
    <div class="stat" data-stat="completed"><div class="n">${completed}</div><div class="l">Completed</div></div>
    <div class="stat" data-stat="noshow"><div class="n">${noshow}</div><div class="l">No Shows</div></div>
    <div class="stat" data-stat="new"><div class="n">${newPatients}</div><div class="l">New Patients (7d)</div></div>
  </div>

  <div class="dash-grid">
    <div class="panel">
      <div class="panel-head"><h3>Today's Schedule</h3><button class="btn btn-ghost btn-sm" data-view-link="calendar">Open calendar</button></div>
      <div class="panel-body" id="dash-schedule"></div>
    </div>
    <div class="dash-side">
      <div class="panel">
        <div class="panel-head"><h3>Recent Notifications</h3><button class="btn btn-ghost btn-sm" id="dash-see-all-notif">See all</button></div>
        <div class="panel-body" id="dash-notifs"></div>
      </div>
    </div>
  </div>`;

  const schedHost = document.getElementById("dash-schedule");
  schedHost.innerHTML = sorted.length ? sorted.map(a=>`
    <div class="sched-row">
      <div class="sched-time">${fmtTime(a.start)}</div>
      <div class="sched-main">
        <div class="name">${esc(patientName(a.patientId))} <span style="font-weight:400;color:var(--ink-faint)">· ${esc(typeName(a.type))}</span></div>
        <div class="sub">${esc(therapistName(a.therapist))}</div>
      </div>
      <div class="sched-room">${esc(a.room)}</div>
      <span class="chip chip-${statusClass(a.status)}">${statusLabel(a.status)}</span>
    </div>`).join("") : '<div class="empty-note">No appointments scheduled for today yet.</div>';
  schedHost.querySelectorAll(".sched-row").forEach((row,i)=>{
    row.addEventListener("click", ()=>openAppointmentPanel(sorted[i].id));
    row.style.cursor="pointer";
  });

  document.getElementById("dash-notifs").innerHTML = state.notifications.slice(0,4).map(n=>
    `<div class="notif-mini"><div class="t">${esc(n.title)}</div><div class="d">${esc(n.detail)} · ${n.time}</div></div>`).join("");
  document.getElementById("dash-see-all-notif").addEventListener("click", openNotifications);
  host.querySelectorAll("[data-view-link]").forEach(b=> b.addEventListener("click", ()=>setView(b.dataset.viewLink)));
  host.querySelectorAll("[data-qa]").forEach(bindQA);
  host.querySelectorAll(".stat").forEach(s=>{
    s.addEventListener("click", ()=>{
      setView("calendar");
      toast("Showing "+(s.dataset.stat==="all"?"all appointments":s.querySelector(".l").textContent.toLowerCase())+" for today");
    });
  });
}

/* ============================================================
   RENDER: CALENDAR
   ============================================================ */
const CAL_START_MIN = 8*60, CAL_END_MIN = 18*60, SLOT_MIN = 30, SLOT_H = 26;

function weekStart(iso){
  const d = new Date(iso+"T00:00:00");
  const day = d.getDay(); // 0 sun
  const diff = (day===0? -6 : 1-day);
  d.setDate(d.getDate()+diff);
  return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate());
}

function renderCalendar(){
  const ui = state.ui;
  const host = document.getElementById("view-calendar");
  host.innerHTML = `
  <div class="cal-toolbar">
    <h1>${ROLE==="therapist"?"My Schedule":"Calendar"}</h1>
    <div class="cal-nav">
      <button class="btn btn-sm" id="cal-prev" aria-label="Previous">‹</button>
      <div class="cal-range" id="cal-range"></div>
      <button class="btn btn-sm" id="cal-next" aria-label="Next">›</button>
    </div>
    <div class="spacer"></div>
    <div class="seg" id="cal-view-seg">
      <button data-v="day">Day</button><button data-v="week">Week</button><button data-v="month">Month</button><button data-v="agenda">Agenda</button>
    </div>
  </div>
  <div id="cal-content"></div>`;

  document.getElementById("cal-prev").addEventListener("click", ()=>navCal(-1));
  document.getElementById("cal-next").addEventListener("click", ()=>navCal(1));
  document.querySelectorAll("#cal-view-seg button").forEach(b=>{
    b.classList.toggle("active", b.dataset.v===ui.calView);
    b.addEventListener("click", ()=>{ ui.calView=b.dataset.v; renderCalendar(); });
  });

  if(ui.calView==="week") renderWeekView();
  else if(ui.calView==="day") renderDayView();
  else if(ui.calView==="month") renderMonthView();
  else renderAgendaView();
  document.getElementById("cal-range").textContent = fmtDMY(ui.calAnchor);
}

function navCal(dir){
  const ui = state.ui;
  if(ui.calView==="day") ui.calAnchor = addDays(ui.calAnchor, dir);
  else if(ui.calView==="week") ui.calAnchor = addDays(ui.calAnchor, dir*7);
  else if(ui.calView==="month"){ const d=new Date(ui.calAnchor+"T00:00:00"); d.setMonth(d.getMonth()+dir); ui.calAnchor = d.getFullYear()+"-"+pad(d.getMonth()+1)+"-01"; }
  else ui.calAnchor = addDays(ui.calAnchor, dir*7);
  renderCalendar();
}

function timeColHtml(){
  let rows="";
  for(let m=CAL_START_MIN; m<CAL_END_MIN; m+=SLOT_MIN){
    rows += `<div class="cal-time-label">${m%60===0?fmtTime(minToTime(m)):""}</div>`;
  }
  return rows;
}

function slotsHtml(date, therapist){
  let html="";
  for(let m=CAL_START_MIN; m<CAL_END_MIN; m+=SLOT_MIN){
    const isHour = m%60===0;
    html += `<div class="cal-slot ${isHour?'hour':''} avail" data-date="${date}" data-therapist="${therapist}" data-min="${m}"></div>`;
  }
  return html;
}

function appointmentsBlocksHtml(date, therapist){
  const list = state.appointments.filter(a=>a.date===date && a.therapist===therapist && a.status!=="cancelled");
  return list.map(a=>{
    const top = (timeToMin(a.start)-CAL_START_MIN)/SLOT_MIN*SLOT_H;
    const height = Math.max(20,(timeToMin(a.end)-timeToMin(a.start))/SLOT_MIN*SLOT_H - 2);
    return `<div class="appt-block appt-${statusClass(a.status)}" draggable="true" data-id="${a.id}" style="top:${top}px;height:${height}px;">
      <div class="t">${fmtTime(a.start)} · ${esc(patientName(a.patientId))}</div>
      <div class="s">${esc(typeName(a.type))} · ${esc(a.room)}</div>
      <div class="rz" data-resize="${a.id}"></div>
    </div>`;
  }).join("");
}

function renderWeekView(){
  const ws = weekStart(state.ui.calAnchor);
  const days = [0,1,2,3,4,5,6].map(i=>addDays(ws,i));
  document.getElementById("cal-range").textContent = fmtDateShort(days[0])+" – "+fmtDateShort(days[6]);
  const host = document.getElementById("cal-content");
  host.innerHTML = `<div class="cal-wrap"><div class="cal-grid-scroll"><div class="cal-grid" style="grid-template-columns:64px repeat(7,1fr);">
    <div class="cal-head-row" style="grid-template-columns:64px repeat(7,1fr);grid-column:1/-1;">
      <div class="cal-head-cell"></div>
      ${days.map(d=>`<div class="cal-head-cell">${dayName(d)}<div class="d2">${fmtDateShort(d)}</div></div>`).join("")}
    </div>
    <div class="cal-time-col">${timeColHtml()}</div>
    ${days.map(d=>`<div class="cal-col" data-date="${d}" style="min-height:${((CAL_END_MIN-CAL_START_MIN)/SLOT_MIN)*SLOT_H}px;">
        ${slotsHtml(d,"__any")}
        <div class="cal-appts-layer" style="position:absolute;inset:0;pointer-events:none;">${dayAllTherapistBlocks(d)}</div>
      </div>`).join("")}
  </div></div></div>`;
  attachCalendarInteractions();
}

function dayAllTherapistBlocks(date){
  // in week view (all therapists merged), stack narrower columns per therapist
  const thWidth = 100/THERAPISTS.length;
  return THERAPISTS.map((th,i)=>{
    const list = state.appointments.filter(a=>a.date===date && a.therapist===th.id && a.status!=="cancelled");
    return list.map(a=>{
      const top = (timeToMin(a.start)-CAL_START_MIN)/SLOT_MIN*SLOT_H;
      const height = Math.max(18,(timeToMin(a.end)-timeToMin(a.start))/SLOT_MIN*SLOT_H - 2);
      return `<div class="appt-block appt-${statusClass(a.status)}" draggable="true" data-id="${a.id}"
        style="pointer-events:auto;top:${top}px;height:${height}px;left:calc(${thWidth*i}% + 2px);width:calc(${thWidth}% - 4px);">
        <div class="t">${fmtTime(a.start)} ${esc(patientName(a.patientId).split(" ")[0])}</div>
        <div class="s">${esc(th.name.replace('Dr. ',''))}</div>
        <div class="rz" data-resize="${a.id}"></div>
      </div>`;
    }).join("");
  }).join("");
}

function renderDayView(){
  const date = state.ui.calAnchor;
  document.getElementById("cal-range").textContent = fmtDateLong(date);
  const host = document.getElementById("cal-content");
  host.innerHTML = `<div class="cal-wrap"><div class="cal-grid-scroll"><div class="cal-grid" style="grid-template-columns:64px repeat(${THERAPISTS.length},1fr);">
    <div class="cal-head-row" style="grid-template-columns:64px repeat(${THERAPISTS.length},1fr);grid-column:1/-1;">
      <div class="cal-head-cell"></div>
      ${THERAPISTS.map(t=>`<div class="cal-head-cell">${esc(t.name)}</div>`).join("")}
    </div>
    <div class="cal-time-col">${timeColHtml()}</div>
    ${THERAPISTS.map(t=>`<div class="cal-col" data-date="${date}" data-therapist="${t.id}" style="min-height:${((CAL_END_MIN-CAL_START_MIN)/SLOT_MIN)*SLOT_H}px;">
        ${slotsHtml(date,t.id)}
        <div class="cal-appts-layer" style="position:absolute;inset:0;pointer-events:none;">${appointmentsBlocksHtml(date,t.id).replace(/pointer-events:none/,'')}</div>
      </div>`).join("")}
  </div></div></div>`;
  // fix: appointmentsBlocksHtml already returns pointer-events auto blocks, re-enable clicks
  host.querySelectorAll(".appt-block").forEach(b=> b.style.pointerEvents="auto");
  attachCalendarInteractions();
}

function renderMonthView(){
  const anchor = state.ui.calAnchor;
  const d = new Date(anchor+"T00:00:00");
  const monthStart = new Date(d.getFullYear(), d.getMonth(), 1);
  const startOffset = (monthStart.getDay()===0? 6 : monthStart.getDay()-1);
  const gridStart = new Date(monthStart); gridStart.setDate(gridStart.getDate()-startOffset);
  document.getElementById("cal-range").textContent = monthStart.toLocaleDateString(undefined,{month:'long',year:'numeric'});
  const host = document.getElementById("cal-content");
  let cells = "";
  for(let i=0;i<42;i++){
    const cd = new Date(gridStart); cd.setDate(cd.getDate()+i);
    const iso = cd.getFullYear()+"-"+pad(cd.getMonth()+1)+"-"+pad(cd.getDate());
    const inMonth = cd.getMonth()===monthStart.getMonth();
    const count = apptsOn(iso).length;
    cells += `<div class="month-cell ${iso===todayISO()?'today':''}" data-date="${iso}" style="opacity:${inMonth?1:.4}">
      <div class="mn">${cd.getDate()}</div>
      ${count? `<div class="month-count">${count} booked</div>`:""}
    </div>`;
  }
  host.innerHTML = `<div class="cal-wrap"><div class="month-grid" style="border-top:1px solid var(--line);border-left:1px solid var(--line);">${cells}</div></div>`;
  host.querySelectorAll(".month-cell").forEach(c=> c.addEventListener("click", ()=>{ state.ui.calAnchor=c.dataset.date; state.ui.calView="day"; renderCalendar(); }));
}

function renderAgendaView(){
  const start = state.ui.calAnchor;
  const days = [0,1,2,3,4,5,6].map(i=>addDays(start,i));
  document.getElementById("cal-range").textContent = fmtDateShort(days[0])+" – "+fmtDateShort(days[6]);
  const host = document.getElementById("cal-content");
  host.innerHTML = `<div class="cal-wrap">` + days.map(d=>{
    const list = apptsOn(d).sort((a,b)=>timeToMin(a.start)-timeToMin(b.start));
    return `<div class="agenda-day"><div class="agenda-day-head">${dayName(d)}, ${fmtDateShort(d)}</div>` +
      (list.length? list.map(a=>`<div class="sched-row" data-id="${a.id}" style="cursor:pointer;">
        <div class="sched-time">${fmtTime(a.start)}</div>
        <div class="sched-main"><div class="name">${esc(patientName(a.patientId))}</div><div class="sub">${esc(typeName(a.type))} · ${esc(therapistName(a.therapist))}</div></div>
        <div class="sched-room">${esc(a.room)}</div>
        <span class="chip chip-${statusClass(a.status)}">${statusLabel(a.status)}</span>
      </div>`).join("") : `<div class="empty-note">No appointments</div>`) + `</div>`;
  }).join("") + `</div>`;
  host.querySelectorAll("[data-id]").forEach(r=> r.addEventListener("click", ()=>openAppointmentPanel(r.dataset.id)));
}

function attachCalendarInteractions(){
  const host = document.getElementById("cal-content");
  // click empty slot -> new appointment
  host.querySelectorAll(".cal-slot.avail").forEach(slot=>{
    slot.addEventListener("click", ()=>{
      const date = slot.dataset.date;
      const therapist = slot.dataset.therapist==="__any" ? THERAPISTS[0].id : slot.dataset.therapist;
      const min = Number(slot.dataset.min);
      openAppointmentModal({date, therapist, start:minToTime(min)});
    });
  });
  // click appointment -> side panel
  host.querySelectorAll(".appt-block").forEach(b=>{
    b.addEventListener("click", (e)=>{ if(e.target.dataset.resize) return; openAppointmentPanel(b.dataset.id); });
    b.addEventListener("dragstart", (e)=>{ b.classList.add("dragging"); e.dataTransfer.setData("text/plain", b.dataset.id); });
    b.addEventListener("dragend", ()=> b.classList.remove("dragging"));
  });
  host.querySelectorAll(".cal-col").forEach(col=>{
    col.addEventListener("dragover", (e)=>{ e.preventDefault(); col.classList.add("dragover"); });
    col.addEventListener("dragleave", ()=> col.classList.remove("dragover"));
    col.addEventListener("drop", (e)=>{
      e.preventDefault(); col.classList.remove("dragover");
      const id = e.dataTransfer.getData("text/plain");
      const rect = col.getBoundingClientRect();
      const y = e.clientY - rect.top;
      let min = CAL_START_MIN + Math.round(y/SLOT_H)*SLOT_MIN;
      min = Math.max(CAL_START_MIN, Math.min(CAL_END_MIN-SLOT_MIN, min));
      handleDrop(id, col.dataset.date, col.dataset.therapist, minToTime(min));
    });
  });
  // resize
  let resizing = null;
  host.querySelectorAll("[data-resize]").forEach(handle=>{
    handle.addEventListener("mousedown", (e)=>{
      e.preventDefault(); e.stopPropagation();
      resizing = {id:handle.dataset.resize, startY:e.clientY, block:handle.closest(".appt-block")};
    });
  });
  document.addEventListener("mousemove", onResizeMove);
  document.addEventListener("mouseup", onResizeUp);
  function onResizeMove(e){
    if(!resizing) return;
    const dy = e.clientY - resizing.startY;
    const deltaSlots = Math.round(dy/SLOT_H);
    const newH = Math.max(20, parseInt(resizing.block.style.height) + deltaSlots*SLOT_H);
    if(deltaSlots!==0){ resizing.block.style.height = newH+"px"; resizing.startY = e.clientY; resizing.accum = (resizing.accum||0)+deltaSlots; }
  }
  function onResizeUp(){
    if(!resizing) return;
    const appt = state.appointments.find(a=>a.id===resizing.id);
    if(appt && resizing.accum){
      let newEnd = timeToMin(appt.end) + resizing.accum*SLOT_MIN;
      newEnd = Math.max(timeToMin(appt.start)+15, newEnd);
      appt.end = minToTime(newEnd);
      saveState(); toast("Updated "+patientName(appt.patientId)+"'s appointment to end at "+fmtTime(appt.end));
      renderCalendar();
    }
    resizing = null;
  }
}

function handleDrop(id, date, therapist, start){
  const appt = state.appointments.find(a=>a.id===id);
  if(!appt) return;
  const dur = timeToMin(appt.end)-timeToMin(appt.start);
  const end = minToTime(timeToMin(start)+dur);
  const targetTherapist = therapist==="__any" ? appt.therapist : therapist;
  if(checkConflict(targetTherapist, date, start, end, appt.id)){
    const alts = suggestAlternatives(date, start, end, appt.id);
    toast("Therapist unavailable at this time. Try: "+alts[0]);
    return;
  }
  confirmDialog(
    "Move appointment?",
    `Move ${patientName(appt.patientId)}'s ${typeName(appt.type)} to ${fmtDateShort(date)} at ${fmtTime(start)} with ${therapistName(targetTherapist)}?`,
    ()=>{
      appt.date=date; appt.start=start; appt.end=end; appt.therapist=targetTherapist;
      saveState(); toast("Appointment moved"); renderCalendar();
    }
  );
}

/* ---- Appointment modal (create) ---- */
function openAppointmentModal(prefill){
  prefill = prefill || {};
  const date = prefill.date || todayISO();
  const modal = modalTemplate("New Appointment", `
    <div class="field"><label>Patient</label>
      <select class="input" id="am-patient">
        <option value="">Select patient…</option>
        ${state.patients.map(p=>`<option value="${p.id}" ${p.id===prefill.patientId?'selected':''}>${esc(p.first)} ${esc(p.last)} · ${p.id}</option>`).join("")}
      </select>
    </div>
    <div class="row-2">
      <div class="field"><label>Therapist</label>
        <select class="input" id="am-therapist">${THERAPISTS.map(t=>`<option value="${t.id}" ${t.id===prefill.therapist?'selected':''}>${esc(t.name)}</option>`).join("")}</select>
      </div>
      <div class="field"><label>Appointment Type</label>
        <select class="input" id="am-type">${APPT_TYPES.map(t=>`<option value="${t.id}">${esc(t.name)} (${t.duration}m)</option>`).join("")}</select>
      </div>
    </div>
    <div class="row-3">
      <div class="field"><label>Date</label><input class="input" type="date" id="am-date" value="${date}"></div>
      <div class="field"><label>Time</label><input class="input" type="time" id="am-time" value="${prefill.start||'09:00'}"></div>
      <div class="field"><label>Room</label><select class="input" id="am-room">${ROOMS.map(r=>`<option>${r}</option>`).join("")}<option>—</option></select></div>
    </div>
    <div class="field"><label>Notes</label><textarea class="input" id="am-notes" placeholder="Optional notes for the therapist"></textarea></div>
    <div id="am-conflict" class="hint" style="color:var(--red);"></div>
  `, [
    {label:"Cancel", cls:"btn-ghost", action:closeModal},
    {label:"Book Appointment", cls:"btn-primary", action:()=>{
      const patientId = val("am-patient"), therapist = val("am-therapist"), type = val("am-type"),
        date = val("am-date"), start = val("am-time"), room = val("am-room"), notes = val("am-notes");
      if(!patientId){ toast("Select a patient to continue"); return; }
      const dur = typeById(type).duration;
      const end = minToTime(timeToMin(start)+dur);
      if(checkConflict(therapist, date, start, end)){
        const alts = suggestAlternatives(date, start, end);
        document.getElementById("am-conflict").textContent = "Therapist unavailable at this time. Suggestion: "+alts[0];
        return;
      }
      state.appointments.push({id:uid("A"), patientId, therapist, type, date, start, end, status:"confirmed", room, notes});
      pushNotification("appointment", "New appointment booked", patientName(patientId)+" · "+typeName(type)+" · "+fmtTime(start), false);
      saveState(); closeModal(); toast("Appointment booked for "+patientName(patientId));
      if(state.ui.view==="calendar") renderCalendar(); if(state.ui.view==="dashboard") renderDashboard();
    }}
  ]);
  showModal(modal);
}

/* ---- Appointment side panel (view/edit) ---- */
function openAppointmentPanel(id){
  if(ROLE==="therapist") return tApptPanel(id);
  const appt = state.appointments.find(a=>a.id===id);
  if(!appt) return;
  const panel = sidePanelTemplate("Appointment", `
    <div class="kv-grid" style="margin-bottom:18px;">
      <div class="kv"><div class="k">Patient</div><div class="v">${esc(patientName(appt.patientId))}</div></div>
      <div class="kv"><div class="k">Status</div><div class="v"><span class="chip chip-${statusClass(appt.status)}">${statusLabel(appt.status)}</span></div></div>
      <div class="kv"><div class="k">Therapist</div><div class="v">${esc(therapistName(appt.therapist))}</div></div>
      <div class="kv"><div class="k">Room</div><div class="v">${esc(appt.room)}</div></div>
      <div class="kv"><div class="k">Date</div><div class="v">${fmtDateShort(appt.date)}</div></div>
      <div class="kv"><div class="k">Time</div><div class="v">${fmtTime(appt.start)} – ${fmtTime(appt.end)}</div></div>
    </div>
    <div class="field"><label>Type</label><select class="input" id="ap-type">${APPT_TYPES.map(t=>`<option value="${t.id}" ${t.id===appt.type?'selected':''}>${esc(t.name)}</option>`).join("")}</select></div>
    <div class="row-2">
      <div class="field"><label>Date</label><input class="input" type="date" id="ap-date" value="${appt.date}"></div>
      <div class="field"><label>Time</label><input class="input" type="time" id="ap-time" value="${appt.start}"></div>
    </div>
    <div class="field"><label>Notes</label><textarea class="input" id="ap-notes">${esc(appt.notes||"")}</textarea></div>
  `, [
    {label:"Contact Patient", cls:"btn-ghost", action:()=>{ const p=patientById(appt.patientId); toast("Calling "+p.phone+" …"); }},
    {label:"Cancel Appointment", cls:"btn-danger", action:()=>{
      confirmDialog("Cancel appointment?","This will mark the appointment as cancelled.", ()=>{
        appt.status="cancelled"; pushNotification("cancellation","Appointment cancelled", patientName(appt.patientId)+" · "+typeName(appt.type), false);
        saveState(); closePanel(); refreshCurrentView(); toast("Appointment cancelled");
      });
    }},
    {label: appt.status==="checkedin"?"Mark In Session":"Mark Checked In", cls:"btn-ghost", action:()=>{
      appt.status = appt.status==="checkedin" ? "insession" : "checkedin";
      if(appt.status==="checkedin"){
        state.checkIns.push({id:uid("CI"), appointmentId:appt.id, patientId:appt.patientId, checkedInAt: nowTimeStr(), status:"checkedin"});
      }
      saveState(); closePanel(); refreshCurrentView(); toast("Status updated to "+statusLabel(appt.status));
    }},
    {label:"Mark Completed", cls:"btn-primary", action:()=>{
      appt.status="completed"; saveState(); closePanel(); refreshCurrentView(); toast("Marked as completed");
    }},
  ], ()=>{
    // save on close of editable fields via explicit save button appended below actions
  });
  showPanel(panel);
  // wire live field updates (reschedule)
  document.getElementById("ap-type").addEventListener("change", e=>{ appt.type=e.target.value; const t=typeById(appt.type); appt.end=minToTime(timeToMin(appt.start)+t.duration); saveState(); });
  document.getElementById("ap-date").addEventListener("change", e=>{
    if(checkConflict(appt.therapist, e.target.value, appt.start, appt.end, appt.id)){ toast("Therapist unavailable at this time."); e.target.value=appt.date; return; }
    appt.date=e.target.value; saveState(); refreshCurrentView(); toast("Appointment rescheduled");
  });
  document.getElementById("ap-time").addEventListener("change", e=>{
    const dur = timeToMin(appt.end)-timeToMin(appt.start);
    const newEnd = minToTime(timeToMin(e.target.value)+dur);
    if(checkConflict(appt.therapist, appt.date, e.target.value, newEnd, appt.id)){ toast("Therapist unavailable at this time."); e.target.value=appt.start; return; }
    appt.start=e.target.value; appt.end=newEnd; saveState(); refreshCurrentView(); toast("Appointment rescheduled");
  });
  document.getElementById("ap-notes").addEventListener("change", e=>{ appt.notes=e.target.value; saveState(); });
}
function nowTimeStr(){ const d=new Date(); return pad(d.getHours())+":"+pad(d.getMinutes()); }
function refreshCurrentView(){ renderView(state.ui.view); refreshBadges(); }

/* ============================================================
   RENDER: PATIENTS
   ============================================================ */
function renderPatients(){
  const ui = state.ui;
  const host = document.getElementById("view-patients");
  host.innerHTML = `
  <div class="dash-head">
    <div><h1>Patients</h1><div class="dash-meta"><span>${state.patients.length} registered</span></div></div>
    <button class="btn btn-primary" data-qa="register-patient">+ Register Patient</button>
  </div>
  <div class="panel">
    <div class="dir-toolbar">
      <input class="input" id="p-search" placeholder="Search name, ID, phone, email…" value="${esc(ui.patientFilter)}">
      <span class="dir-count" id="dir-count"></span>
    </div>
    <div class="scrollx">
      <table class="dtable dir-table">
        <thead><tr><th>Patient</th><th>Patient ID</th><th>Phone</th><th>Therapist</th><th>Next appointment</th><th>Today</th></tr></thead>
        <tbody id="dir-body"></tbody>
      </table>
    </div>
  </div>`;
  document.getElementById("p-search").addEventListener("input", e=>{ ui.patientFilter=e.target.value; renderDirectoryRows(); });
  renderDirectoryRows();
  host.querySelectorAll("[data-qa]").forEach(bindQA);
}

function ageFromDob(dob){
  if(!dob) return "";
  const a = Math.floor((Date.now()-new Date(dob+"T00:00:00").getTime())/31557600000);
  return isNaN(a) ? "" : a+" yrs";
}

function renderDirectoryRows(){
  const q = state.ui.patientFilter.trim().toLowerCase();
  const list = state.patients.filter(p=>{
    if(!q) return true;
    return (p.first+" "+p.last).toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || p.phone.includes(q) || p.email.toLowerCase().includes(q);
  }).sort((a,b)=>(a.last+a.first).localeCompare(b.last+b.first));
  document.getElementById("dir-count").textContent = list.length+" of "+state.patients.length;
  const body = document.getElementById("dir-body");
  if(!list.length){ body.innerHTML = '<tr><td colspan="6"><div class="empty-note">No patients match your search.</div></td></tr>'; return; }
  let html="", letter="";
  list.forEach(p=>{
    const L = ((p.last||"#")[0]).toUpperCase();
    if(L!==letter){ letter=L; html += `<tr class="dir-letter"><td colspan="6">${esc(L)}</td></tr>`; }
    const next = nextAppt(p.id);
    const todayAppt = state.appointments.find(a=>a.patientId===p.id && a.date===todayISO() && a.status!=="cancelled");
    const sub = [p.gender, ageFromDob(p.dob)].filter(Boolean).join(" · ");
    html += `<tr class="dir-row" data-id="${p.id}" tabindex="0">
      <td><div class="dir-name"><div class="avatar">${esc((p.first[0]||"")+(p.last[0]||""))}</div>
        <div><div style="font-weight:600;">${esc(p.last)}, ${esc(p.first)}</div><div class="sub">${esc(sub)}</div></div></div></td>
      <td class="mono">${p.id}</td>
      <td>${esc(p.phone)}</td>
      <td>${esc(therapistName(p.therapist))}</td>
      <td>${next? fmtDateShort(next.date)+" · "+fmtTime(next.start) : '<span style="color:var(--ink-faint)">None</span>'}</td>
      <td>${todayAppt? `<span class="chip chip-${statusClass(todayAppt.status)}">${statusLabel(todayAppt.status)}</span>` : '<span style="color:var(--ink-faint)">—</span>'}</td>
    </tr>`;
  });
  body.innerHTML = html;
  body.querySelectorAll(".dir-row").forEach(r=>{
    r.addEventListener("click", ()=>openPatientPanel(r.dataset.id));
    r.addEventListener("keydown", e=>{ if(e.key==="Enter") openPatientPanel(r.dataset.id); });
  });
}

function nextAppt(pid){
  const now = todayISO();
  return state.appointments.filter(a=>a.patientId===pid && a.status!=="cancelled" && a.status!=="completed" && a.date>=now).sort((a,b)=>a.date+a.start<b.date+b.start?-1:1)[0];
}
function lastAppt(pid){
  const now = todayISO();
  return state.appointments.filter(a=>a.patientId===pid && a.date<now).sort((a,b)=>a.date+a.start>b.date+b.start?-1:1)[0];
}

function openPatientPanel(pid){
  if(ROLE==="therapist") return tPatientPanel(pid,"overview");
  state.ui.selectedPatientId = pid; state.ui.patientTab = "overview"; saveState();
  const root = document.getElementById("modal-root");
  root.innerHTML = "";
  const wrap = document.createElement("div");
  wrap.className = "overlay";
  wrap.innerHTML = `<div class="side-panel wide">
    <div class="panel-title-row"><h2>Patient profile</h2><button class="btn btn-icon btn-ghost" id="panel-close" aria-label="Close">✕</button></div>
    <div class="panel-scroll" id="pp-body" style="padding:0;"></div>
  </div>`;
  wrap.addEventListener("mousedown", e=>{ if(e.target===wrap) closePanel(); });
  root.appendChild(wrap);
  wrap.querySelector("#panel-close").addEventListener("click", closePanel);
  renderPatientDetail(wrap.querySelector("#pp-body"));
}

function renderPatientDetail(host){
  const p = patientById(state.ui.selectedPatientId);
  if(!p){ host.innerHTML = '<div class="empty-note">Patient not found.</div>'; return; }
  const tab = state.ui.patientTab;
  host.innerHTML = `
    <div class="p-detail-head">
      <div>
        <h2>${esc(p.first)} ${esc(p.last)}</h2>
        <div class="pid2">${p.id} · ${esc(p.gender)}, born ${esc(p.dob)}</div>
      </div>
      <div style="display:flex;gap:8px;">
        <button class="btn btn-sm" id="pd-book">Book Appointment</button>
        <button class="btn btn-sm btn-ghost" id="pd-checkin">Check In</button>
      </div>
    </div>
    <div class="tabs">
      <div class="tab ${tab==='overview'?'active':''}" data-tab="overview">Overview</div>
      <div class="tab ${tab==='appointments'?'active':''}" data-tab="appointments">Appointments</div>
      <div class="tab ${tab==='billing'?'active':''}" data-tab="billing">Billing</div>
      <div class="tab ${tab==='documents'?'active':''}" data-tab="documents">Documents</div>
    </div>
    <div class="tab-panel" id="pd-panel"></div>`;

  host.querySelectorAll(".tab").forEach(t=> t.addEventListener("click", ()=>{ state.ui.patientTab=t.dataset.tab; saveState(); renderPatientDetail(host); }));
  host.querySelector("#pd-book").addEventListener("click", ()=>{ closePanel(); openAppointmentModal({patientId:p.id}); });
  host.querySelector("#pd-checkin").addEventListener("click", ()=>{ closePanel(); openCheckInModal(p.id); });

  const panel = host.querySelector("#pd-panel");
  if(tab==="overview"){
    const next = nextAppt(p.id);
    panel.innerHTML = `<div class="kv-grid">
      <div class="kv"><div class="k">Phone</div><div class="v">${esc(p.phone)}</div></div>
      <div class="kv"><div class="k">Email</div><div class="v">${esc(p.email)}</div></div>
      <div class="kv"><div class="k">Address</div><div class="v">${esc(p.address)}</div></div>
      <div class="kv"><div class="k">Emergency Contact</div><div class="v">${esc(p.emergency)}</div></div>
      <div class="kv"><div class="k">Assigned Therapist</div><div class="v">${esc(therapistName(p.therapist))}</div></div>
      <div class="kv"><div class="k">Next Appointment</div><div class="v">${next? fmtDateShort(next.date)+" · "+fmtTime(next.start)+" · "+esc(typeName(next.type)) : "None scheduled"}</div></div>
      <div class="kv"><div class="k">Preferred Contact</div><div class="v">${esc(p.commPref)}</div></div>
      <div class="kv"><div class="k">Consent Status</div><div class="v">${esc(p.consent)}</div></div>
    </div>`;
  } else if(tab==="appointments"){
    const all = state.appointments.filter(a=>a.patientId===p.id).sort((a,b)=>b.date+b.start>a.date+a.start?1:-1);
    const groups = {Upcoming:[], Previous:[], Cancelled:[], "No Shows":[]};
    const now = todayISO();
    all.forEach(a=>{
      if(a.status==="cancelled") groups.Cancelled.push(a);
      else if(a.status==="noshow") groups["No Shows"].push(a);
      else if(a.date>=now && a.status!=="completed") groups.Upcoming.push(a);
      else groups.Previous.push(a);
    });
    panel.innerHTML = Object.keys(groups).map(g=>`
      <div class="section-title" style="margin-top:6px;">${g}</div>
      ${groups[g].length? `<table class="dtable"><tbody>${groups[g].map(a=>`
        <tr class="clickable" data-id="${a.id}"><td>${fmtDateShort(a.date)}</td><td>${fmtTime(a.start)}</td><td>${esc(typeName(a.type))}</td>
        <td><span class="chip chip-${statusClass(a.status)}">${statusLabel(a.status)}</span></td></tr>`).join("")}</tbody></table>` :
        `<div class="empty-note" style="padding-left:0;">None</div>`}
    `).join("");
    panel.querySelectorAll("[data-id]").forEach(r=> r.addEventListener("click", ()=>openAppointmentPanel(r.dataset.id)));
  } else if(tab==="billing"){
    panel.innerHTML = `<div class="empty-note" style="padding-left:0;">Billing is not enabled for this clinic yet. Ask your Clinic Owner to turn it on in Settings.</div>`;
  } else if(tab==="documents"){
    panel.innerHTML = `
      <table class="dtable"><tbody>
        <tr><td>Intake Form.pdf</td><td style="color:var(--ink-faint)">Uploaded ${fmtDMY(p.createdAt)}</td><td style="text-align:right;"><button class="btn btn-sm btn-ghost">View</button></td></tr>
        <tr><td>Insurance Card.jpg</td><td style="color:var(--ink-faint)">Uploaded ${fmtDMY(p.createdAt)}</td><td style="text-align:right;"><button class="btn btn-sm btn-ghost">View</button></td></tr>
      </tbody></table>
      <div class="locked-row">🔒 Clinical notes and SOAP documentation are managed by the treating therapist and aren't shown here.</div>`;
  }
}

function openCheckInModal(pid){
  const appt = nextAppt(pid) || state.appointments.find(a=>a.patientId===pid && a.date===todayISO());
  if(!appt){ toast("No appointment found for today — book one first."); return; }
  appt.status="checkedin";
  state.checkIns.push({id:uid("CI"), appointmentId:appt.id, patientId:pid, checkedInAt: nowTimeStr(), status:"checkedin"});
  saveState(); toast(patientName(pid)+" checked in for "+fmtTime(appt.start));
  refreshCurrentView();
}

/* ============================================================
   PATIENT REGISTRATION WIZARD
   ============================================================ */
function openRegisterWizard(){
  let step = 1;
  const data = {first:"",last:"",dob:"",gender:"Female",phone:"",email:"",address:"",emergency:"",
    reason:"",referral:"Self",referringDoctor:"",complaint:"",conditions:"",allergies:"",medication:"",
    insurance:"",membership:"",commPref:"SMS",consent:"Signed",
    bookNow:true, therapist:THERAPISTS[0].id, apptDate:todayISO(), apptTime:"09:00", apptType:"initial", apptRoom:ROOMS[0]};

  function stepsBar(){
    return `<div class="wizard-steps">${[1,2,3,4].map(n=>`<div class="st ${n<=step?'done':''}"></div>`).join("")}</div>`;
  }
  function body(){
    if(step===1) return `
      ${stepsBar()}
      <h3 style="margin-bottom:14px;font-size:15px;">Step 1 — Basic Information</h3>
      <div class="row-2">
        <div class="field"><label>First Name</label><input class="input" id="w-first" value="${esc(data.first)}"></div>
        <div class="field"><label>Last Name</label><input class="input" id="w-last" value="${esc(data.last)}"></div>
      </div>
      <div class="row-2">
        <div class="field"><label>Date of Birth</label><input class="input" type="date" id="w-dob" value="${data.dob}"></div>
        <div class="field"><label>Gender</label><select class="input" id="w-gender">
          <option ${data.gender==='Female'?'selected':''}>Female</option><option ${data.gender==='Male'?'selected':''}>Male</option><option ${data.gender==='Other'?'selected':''}>Other</option></select></div>
      </div>
      <div class="row-2">
        <div class="field"><label>Phone</label><input class="input" id="w-phone" value="${esc(data.phone)}"></div>
        <div class="field"><label>Email</label><input class="input" id="w-email" value="${esc(data.email)}"></div>
      </div>
      <div class="field"><label>Address</label><input class="input" id="w-address" value="${esc(data.address)}"></div>
      <div class="field"><label>Emergency Contact</label><input class="input" id="w-emergency" placeholder="Name · phone" value="${esc(data.emergency)}"></div>
    `;
    if(step===2) return `
      ${stepsBar()}
      <h3 style="margin-bottom:14px;font-size:15px;">Step 2 — Clinical Intake</h3>
      <div class="field"><label>Reason for Visit</label><input class="input" id="w-reason" value="${esc(data.reason)}"></div>
      <div class="row-2">
        <div class="field"><label>Referral Source</label><select class="input" id="w-referral">
          <option ${data.referral==='Self'?'selected':''}>Self</option><option ${data.referral==='Referring Doctor'?'selected':''}>Referring Doctor</option><option ${data.referral==='Coach'?'selected':''}>Coach</option><option ${data.referral==='Insurance'?'selected':''}>Insurance</option></select></div>
        <div class="field"><label>Referring Doctor</label><input class="input" id="w-refdoc" value="${esc(data.referringDoctor)}" placeholder="If applicable"></div>
      </div>
      <div class="field"><label>Initial Complaint</label><textarea class="input" id="w-complaint">${esc(data.complaint)}</textarea></div>
      <div class="row-2">
        <div class="field"><label>Relevant Medical Conditions</label><input class="input" id="w-conditions" value="${esc(data.conditions)}"></div>
        <div class="field"><label>Allergies</label><input class="input" id="w-allergies" value="${esc(data.allergies)}"></div>
      </div>
      <div class="field"><label>Current Medication</label><input class="input" id="w-medication" value="${esc(data.medication)}"></div>
      <div class="hint">This covers only what reception needs to route the patient — detailed clinical history is captured by the physiotherapist.</div>
    `;
    if(step===3) return `
      ${stepsBar()}
      <h3 style="margin-bottom:14px;font-size:15px;">Step 3 — Administrative Information</h3>
      <div class="field"><label>Patient ID</label><input class="input" value="Auto-generated on save" disabled></div>
      <div class="row-2">
        <div class="field"><label>Insurance Provider</label><input class="input" id="w-insurance" value="${esc(data.insurance)}" placeholder="e.g. Sample Health Plan A, or Uninsured"></div>
        <div class="field"><label>Membership Number</label><input class="input" id="w-membership" value="${esc(data.membership)}"></div>
      </div>
      <div class="row-2">
        <div class="field"><label>Preferred Communication</label><select class="input" id="w-commpref">
          <option ${data.commPref==='SMS'?'selected':''}>SMS</option><option ${data.commPref==='Email'?'selected':''}>Email</option><option ${data.commPref==='Phone'?'selected':''}>Phone</option></select></div>
        <div class="field"><label>Consent Status</label><select class="input" id="w-consent">
          <option ${data.consent==='Signed'?'selected':''}>Signed</option><option ${data.consent==='Pending'?'selected':''}>Pending</option></select></div>
      </div>
    `;
    return `
      ${stepsBar()}
      <h3 style="margin-bottom:14px;font-size:15px;">Step 4 — Book Initial Assessment</h3>
      <label style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;margin-bottom:14px;">
        <input type="checkbox" id="w-booknow" ${data.bookNow?'checked':''}> Book Initial Assessment now
      </label>
      <div id="w-booking-fields" style="${data.bookNow?'':'display:none;opacity:.5;pointer-events:none;'}">
        <div class="row-2">
          <div class="field"><label>Therapist</label><select class="input" id="w-therapist">${THERAPISTS.map(t=>`<option value="${t.id}" ${t.id===data.therapist?'selected':''}>${esc(t.name)}</option>`).join("")}</select></div>
          <div class="field"><label>Appointment Type</label><select class="input" id="w-appttype">${APPT_TYPES.map(t=>`<option value="${t.id}" ${t.id===data.apptType?'selected':''}>${esc(t.name)}</option>`).join("")}</select></div>
        </div>
        <div class="row-3">
          <div class="field"><label>Date</label><input class="input" type="date" id="w-apptdate" value="${data.apptDate}"></div>
          <div class="field"><label>Time</label><input class="input" type="time" id="w-appttime" value="${data.apptTime}"></div>
          <div class="field"><label>Room</label><select class="input" id="w-room">${ROOMS.map(r=>`<option ${r===data.apptRoom?'selected':''}>${r}</option>`).join("")}</select></div>
        </div>
      </div>
      <div id="w-conflict" class="hint" style="color:var(--red);"></div>
    `;
  }
  function collect(){
    if(step===1){ data.first=val("w-first"); data.last=val("w-last"); data.dob=val("w-dob"); data.gender=val("w-gender");
      data.phone=val("w-phone"); data.email=val("w-email"); data.address=val("w-address"); data.emergency=val("w-emergency"); }
    if(step===2){ data.reason=val("w-reason"); data.referral=val("w-referral"); data.referringDoctor=val("w-refdoc"); data.complaint=val("w-complaint");
      data.conditions=val("w-conditions"); data.allergies=val("w-allergies"); data.medication=val("w-medication"); }
    if(step===3){ data.insurance=val("w-insurance"); data.membership=val("w-membership"); data.commPref=val("w-commpref"); data.consent=val("w-consent"); }
    if(step===4){ data.bookNow=document.getElementById("w-booknow").checked;
      if(data.bookNow){ data.therapist=val("w-therapist"); data.apptType=val("w-appttype"); data.apptDate=val("w-apptdate"); data.apptTime=val("w-appttime"); data.apptRoom=val("w-room"); } }
  }
  function renderModal(){
    modal.querySelector(".panel-scroll").innerHTML = body();
    modal.querySelector(".panel-actions").innerHTML = actionsHtml();
    wireActions();
    if(step===1) document.getElementById("w-first").focus();
    if(step===4){
      document.getElementById("w-booknow").addEventListener("change", e=>{ data.bookNow=e.target.checked; document.getElementById("w-booking-fields").style.cssText = data.bookNow? "" : "display:block;opacity:.5;pointer-events:none;"; });
    }
  }
  function actionsHtml(){
    return `
      <button class="btn btn-ghost" id="w-cancel">Cancel</button>
      <div style="display:flex;gap:10px;">
        ${step>1? '<button class="btn" id="w-back">Back</button>':''}
        <button class="btn btn-primary" id="w-next">${step<4? 'Continue':'Confirm Registration'}</button>
      </div>`;
  }
  function wireActions(){
    document.getElementById("w-cancel").addEventListener("click", closeModal);
    if(step>1) document.getElementById("w-back").addEventListener("click", ()=>{ collect(); step--; renderModal(); });
    document.getElementById("w-next").addEventListener("click", ()=>{
      collect();
      if(step===1 && (!data.first || !data.last || !data.phone)){ toast("First name, last name and phone are required"); return; }
      if(step<4){ step++; renderModal(); return; }
      // final submit
      if(data.bookNow){
        const dur = typeById(data.apptType).duration;
        const end = minToTime(timeToMin(data.apptTime)+dur);
        if(checkConflict(data.therapist, data.apptDate, data.apptTime, end)){
          const alts = suggestAlternatives(data.apptDate, data.apptTime, end);
          document.getElementById("w-conflict").textContent = "Therapist unavailable at this time. Suggestion: "+alts[0];
          return;
        }
      }
      const newId = "P-"+(1000+state.patients.length+1);
      state.patients.push({id:newId, first:data.first, last:data.last, dob:data.dob, gender:data.gender, phone:data.phone, email:data.email,
        address:data.address, emergency:data.emergency, reason:data.reason, referral:data.referral, referringDoctor:data.referringDoctor,
        complaint:data.complaint, conditions:data.conditions, allergies:data.allergies, medication:data.medication,
        insurance:data.insurance, membership:data.membership, commPref:data.commPref, consent:data.consent, therapist:data.therapist, createdAt: todayISO()});
      if(data.bookNow){
        const dur = typeById(data.apptType).duration;
        state.appointments.push({id:uid("A"), patientId:newId, therapist:data.therapist, type:data.apptType, date:data.apptDate,
          start:data.apptTime, end:minToTime(timeToMin(data.apptTime)+dur), status:"confirmed", room:data.apptRoom, notes:""});
        pushNotification("appointment","New appointment booked", data.first+" "+data.last+" · "+typeName(data.apptType), false);
      }
      saveState(); closeModal();
      toast(data.first+" "+data.last+" registered"+(data.bookNow? " and initial assessment booked":""));
      state.ui.selectedPatientId = newId;
      if(state.ui.view==="patients") renderPatients(); else setView("patients");
    });
  }
  const modal = modalTemplate("Register Patient", "", []);
  showModal(modal);
  renderModal();
}

/* ============================================================
   RENDER: INVENTORY
   ============================================================ */
function renderInventory(){
  const ui = state.ui;
  const items = state.inventoryItems;
  const low = items.filter(i=> invStatus(i)==="lowstock" || invStatus(i)==="outstock");
  const outstock = items.filter(i=>invStatus(i)==="outstock").length;
  const expiring = items.filter(i=>invStatus(i)==="expiring").length;

  const host = document.getElementById("view-inventory");
  host.innerHTML = `
  <div class="dash-head">
    <div><h1>Inventory</h1><div class="dash-meta"><span>Clinical supplies, equipment &amp; office stock</span></div></div>
    <div style="display:flex;gap:8px;">
      <button class="btn" data-qa="stock-movement">Record Movement</button>
      <button class="btn btn-primary" data-qa="add-inventory">+ Add Inventory Item</button>
    </div>
  </div>
  <div class="stat-strip">
    <div class="stat"><div class="n">${items.length}</div><div class="l">Total Items</div></div>
    <div class="stat"><div class="n">${low.length}</div><div class="l">Low Stock</div></div>
    <div class="stat"><div class="n">${outstock}</div><div class="l">Out of Stock</div></div>
    <div class="stat"><div class="n">${expiring}</div><div class="l">Expiring Soon</div></div>
    <div class="stat"><div class="n">$${invValue().toFixed(0)}</div><div class="l">Inventory Value</div></div>
  </div>
  <div class="inv-tabs">
    ${[["items","Items"],["low","Low Stock"],["expiry","Expiry"],["suppliers","Suppliers"],["requests","Purchase Requests"]].map(([k,l])=>
      `<div class="inv-tab ${ui.invTab===k?'active':''}" data-tab="${k}">${l}</div>`).join("")}
  </div>
  <div id="inv-body"></div>`;

  host.querySelectorAll(".inv-tab").forEach(t=> t.addEventListener("click", ()=>{ ui.invTab=t.dataset.tab; saveState(); renderInventory(); }));
  host.querySelectorAll("[data-qa]").forEach(bindQA);
  const body = document.getElementById("inv-body");

  if(ui.invTab==="items"){
    body.innerHTML = `<table class="dtable"><thead><tr><th>Item</th><th>Category</th><th>Qty</th><th>Location</th><th>Status</th><th></th></tr></thead>
      <tbody>${items.map(i=>{
        const st = invStatus(i);
        return `<tr><td><b>${esc(i.name)}</b><div style="color:var(--ink-faint);font-size:11.5px;">${i.sku}</div></td>
        <td>${esc(i.category)}</td><td>${i.qty} ${esc(i.unit)}</td><td>${esc(i.location)}</td>
        <td><span class="chip chip-${st}">${invStatusLabel(st)}</span></td>
        <td style="text-align:right;"><button class="btn btn-sm" data-move="${i.id}">Adjust</button></td></tr>`;
      }).join("")}</tbody></table>`;
    body.querySelectorAll("[data-move]").forEach(b=> b.addEventListener("click", ()=>openStockMovementModal(b.dataset.move)));
  } else if(ui.invTab==="low"){
    body.innerHTML = low.length ? low.map(i=>`
      <div class="alert-card">
        <div><div class="an">${invStatus(i)==='outstock'?'OUT OF STOCK':'LOW STOCK'} — ${esc(i.name)}</div>
        <div class="ad">Current: ${i.qty} ${esc(i.unit)} · Minimum: ${i.min} ${esc(i.unit)}</div></div>
        <button class="btn btn-primary btn-sm" data-pr="${i.id}">Create Purchase Request</button>
      </div>`).join("") : `<div class="empty-note">No low stock items — everything is above its minimum level.</div>`;
    body.querySelectorAll("[data-pr]").forEach(b=> b.addEventListener("click", ()=>openPurchaseRequestModal(b.dataset.pr)));
  } else if(ui.invTab==="expiry"){
    const withExpiry = items.filter(i=>i.expiry);
    const groups = { "30":[], "60":[], "expired":[] };
    withExpiry.forEach(i=>{ const d=daysUntil(i.expiry); if(d<0) groups.expired.push(i); else if(d<=30) groups["30"].push(i); else if(d<=60) groups["60"].push(i); });
    body.innerHTML = `
      <div class="seg" style="width:fit-content;margin-bottom:16px;">
        <button data-e="30" class="${ui.expiryTab==='30'?'active':''}">Expiring in 30 Days</button>
        <button data-e="60" class="${ui.expiryTab==='60'?'active':''}">Expiring in 60 Days</button>
        <button data-e="expired" class="${ui.expiryTab==='expired'?'active':''}">Expired</button>
      </div>
      <div id="expiry-list"></div>`;
    body.querySelectorAll("[data-e]").forEach(b=> b.addEventListener("click", ()=>{ ui.expiryTab=b.dataset.e; saveState(); renderInventory(); }));
    const list = groups[ui.expiryTab];
    document.getElementById("expiry-list").innerHTML = list.length ? `<table class="dtable"><thead><tr><th>Item</th><th>Batch</th><th>Expiry Date</th><th>Qty</th><th>Status</th></tr></thead>
      <tbody>${list.map(i=>`<tr><td>${esc(i.name)}</td><td>${esc(i.batch)}</td><td>${i.expiry}</td><td>${i.qty} ${esc(i.unit)}</td>
        <td>${daysUntil(i.expiry)<0? `<span class="chip chip-outstock">Expired</span>` : `<span class="chip chip-expiring">${daysUntil(i.expiry)}d left</span>`}</td></tr>`).join("")}</tbody></table>`
      : `<div class="empty-note">Nothing in this window.</div>`;
  } else if(ui.invTab==="suppliers"){
    body.innerHTML = `<div style="display:flex;justify-content:flex-end;margin-bottom:12px;"><button class="btn btn-sm" id="add-supplier">+ Add Supplier</button></div>
      <table class="dtable"><thead><tr><th>Supplier</th><th>Contact</th><th>Phone</th><th>Products Supplied</th><th>Last Order</th><th>Outstanding POs</th></tr></thead>
      <tbody>${state.suppliers.map(s=>`<tr><td><b>${esc(s.name)}</b></td><td>${esc(s.contact)}</td><td>${esc(s.phone)}</td><td>${esc(s.products)}</td><td>${s.lastOrder}</td><td>${s.outstanding}</td></tr>`).join("")}</tbody></table>`;
    document.getElementById("add-supplier").addEventListener("click", openAddSupplierModal);
  } else if(ui.invTab==="requests"){
    body.innerHTML = `<table class="dtable"><thead><tr><th>Request</th><th>Items</th><th>Supplier</th><th>Est. Cost</th><th>Requested By</th><th>Date</th><th>Status</th></tr></thead>
      <tbody>${state.purchaseRequests.map(pr=>`<tr><td>${pr.id}</td><td>${pr.items.map(it=>itemById(it.itemId).name+" ×"+it.qty).join(", ")}</td>
        <td>${esc(supplierById(pr.supplier).name)}</td><td>$${pr.estCost.toFixed(2)}</td><td>${esc(pr.requestedBy)}</td><td>${pr.date}</td>
        <td><span class="chip chip-${statusClass(pr.status)}">${pr.status}</span></td></tr>`).join("")}</tbody></table>`;
  }
}

function openStockMovementModal(itemId){
  const items = state.inventoryItems;
  const modal = modalTemplate("Record Stock Movement", `
    <div class="field"><label>Item</label><select class="input" id="sm-item">${items.map(i=>`<option value="${i.id}" ${i.id===itemId?'selected':''}>${esc(i.name)} (${i.qty} ${esc(i.unit)} on hand)</option>`).join("")}</select></div>
    <div class="row-2">
      <div class="field"><label>Movement Type</label><select class="input" id="sm-type">
        <option>Stock Added</option><option>Stock Removed</option><option>Stock Adjusted</option><option>Stock Transferred</option><option>Stock Expired</option></select></div>
      <div class="field"><label>Quantity</label><input class="input" type="number" min="1" id="sm-qty" value="1"></div>
    </div>
    <div class="field"><label>Reason</label><input class="input" id="sm-reason" placeholder="e.g. Used in session, restock delivery"></div>
  `, [
    {label:"Cancel", cls:"btn-ghost", action:closeModal},
    {label:"Save Movement", cls:"btn-primary", action:()=>{
      const iid = val("sm-item"), type=val("sm-type"), qty=Number(val("sm-qty")), reason=val("sm-reason");
      const item = itemById(iid);
      if(type==="Stock Added") item.qty += qty;
      else if(type==="Stock Removed" || type==="Stock Expired") item.qty = Math.max(0, item.qty-qty);
      else if(type==="Stock Adjusted") item.qty = qty;
      state.inventoryTransactions.unshift({id:uid("TX"), itemId:iid, type, qty, date:todayISO(), user:"Rudo Chikwanha", reason});
      if(invStatus(item)==="lowstock") pushNotification("lowstock","Low stock: "+item.name, item.qty+" "+item.unit+" remaining · minimum "+item.min, false);
      if(invStatus(item)==="outstock") pushNotification("outstock","Out of stock: "+item.name, "Reorder from "+supplierById(item.supplier).name, true);
      saveState(); closeModal(); toast("Stock movement recorded"); if(state.ui.view==="inventory") renderInventory(); refreshBadges();
    }}
  ]);
  showModal(modal);
}

function openPurchaseRequestModal(itemId){
  const item = itemId ? itemById(itemId) : null;
  const modal = modalTemplate("Create Purchase Request", `
    <div class="field"><label>Item</label><select class="input" id="pr-item">${state.inventoryItems.map(i=>`<option value="${i.id}" ${item&&i.id===item.id?'selected':''}>${esc(i.name)}</option>`).join("")}</select></div>
    <div class="row-2">
      <div class="field"><label>Quantity</label><input class="input" type="number" min="1" id="pr-qty" value="${item?item.reorder:10}"></div>
      <div class="field"><label>Supplier</label><select class="input" id="pr-supplier">${state.suppliers.map(s=>`<option value="${s.id}" ${item&&s.id===item.supplier?'selected':''}>${esc(s.name)}</option>`).join("")}</select></div>
    </div>
    <div class="hint" id="pr-cost-hint" style="margin-bottom:14px;"></div>
  `, [
    {label:"Cancel", cls:"btn-ghost", action:closeModal},
    {label:"Submit Request", cls:"btn-primary", action:()=>{
      const iid=val("pr-item"), qty=Number(val("pr-qty")), sup=val("pr-supplier");
      const it = itemById(iid);
      const estCost = it.cost*qty;
      const newPr = {id:"PR-"+(state.purchaseRequests.length+1), items:[{itemId:iid,qty}], supplier:sup, estCost,
        requestedBy:"Rudo Chikwanha", date:todayISO(), status: estCost>THRESH() ? "Submitted" : "Approved"};
      state.purchaseRequests.push(newPr);
      pushNotification("purchase", "Purchase request "+(newPr.status==="Submitted"?"awaiting owner approval":"approved"), it.name+" ×"+qty+" from "+supplierById(sup).name, false);
      saveState(); closeModal();
      toast("Purchase request submitted"+(newPr.status==="Submitted"?" — pending Clinic Owner approval (over $"+THRESH()+")":""));
      if(state.ui.view==="inventory") renderInventory();
    }}
  ]);
  showModal(modal);
  document.getElementById("pr-cost-hint").textContent = "Requests over $"+THRESH()+" require Clinic Owner approval before ordering.";
}

function openAddInventoryModal(){
  const modal = modalTemplate("Add Inventory Item", `
    <div class="row-2">
      <div class="field"><label>Item Name</label><input class="input" id="ai-name"></div>
      <div class="field"><label>SKU</label><input class="input" id="ai-sku"></div>
    </div>
    <div class="row-2">
      <div class="field"><label>Category</label><select class="input" id="ai-category">${INV_CATEGORIES.map(c=>`<option>${c}</option>`).join("")}</select></div>
      <div class="field"><label>Unit</label><input class="input" id="ai-unit" placeholder="e.g. roll, box, unit"></div>
    </div>
    <div class="field"><label>Description</label><input class="input" id="ai-desc"></div>
    <div class="row-3">
      <div class="field"><label>Quantity</label><input class="input" type="number" id="ai-qty" value="0"></div>
      <div class="field"><label>Minimum Stock</label><input class="input" type="number" id="ai-min" value="5"></div>
      <div class="field"><label>Reorder Level</label><input class="input" type="number" id="ai-reorder" value="10"></div>
    </div>
    <div class="row-2">
      <div class="field"><label>Supplier</label><select class="input" id="ai-supplier">${state.suppliers.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("")}</select></div>
      <div class="field"><label>Storage Location</label><input class="input" id="ai-location"></div>
    </div>
    <div class="row-3">
      <div class="field"><label>Cost Per Unit</label><input class="input" type="number" step="0.01" id="ai-cost" value="0"></div>
      <div class="field"><label>Expiry Date</label><input class="input" type="date" id="ai-expiry"></div>
      <div class="field"><label>Batch Number</label><input class="input" id="ai-batch"></div>
    </div>
  `, [
    {label:"Cancel", cls:"btn-ghost", action:closeModal},
    {label:"Add Item", cls:"btn-primary", action:()=>{
      const name = val("ai-name"); if(!name){ toast("Item name is required"); return; }
      const id = "INV-"+(state.inventoryItems.length+1);
      state.inventoryItems.push({id, name, sku:val("ai-sku"), category:val("ai-category"), description:val("ai-desc"),
        qty:Number(val("ai-qty")), unit:val("ai-unit")||"unit", min:Number(val("ai-min")), reorder:Number(val("ai-reorder")),
        supplier:val("ai-supplier"), cost:Number(val("ai-cost"))||0, price:0, location:val("ai-location"), expiry:val("ai-expiry"), batch:val("ai-batch")});
      saveState(); closeModal(); toast(name+" added to inventory"); if(state.ui.view==="inventory") renderInventory(); refreshBadges();
    }}
  ]);
  showModal(modal);
}

function openAddSupplierModal(){
  const modal = modalTemplate("Add Supplier", `
    <div class="field"><label>Supplier Name</label><input class="input" id="as-name"></div>
    <div class="row-2">
      <div class="field"><label>Contact Person</label><input class="input" id="as-contact"></div>
      <div class="field"><label>Phone</label><input class="input" id="as-phone"></div>
    </div>
    <div class="row-2">
      <div class="field"><label>Email</label><input class="input" id="as-email"></div>
      <div class="field"><label>Address</label><input class="input" id="as-address"></div>
    </div>
    <div class="field"><label>Products Supplied</label><input class="input" id="as-products"></div>
  `, [
    {label:"Cancel", cls:"btn-ghost", action:closeModal},
    {label:"Add Supplier", cls:"btn-primary", action:()=>{
      const name = val("as-name"); if(!name){ toast("Supplier name is required"); return; }
      state.suppliers.push({id:"SUP-"+(state.suppliers.length+1), name, contact:val("as-contact"), phone:val("as-phone"),
        email:val("as-email"), address:val("as-address"), products:val("as-products"), lastOrder:"—", outstanding:0});
      saveState(); closeModal(); toast(name+" added to suppliers"); renderInventory();
    }}
  ]);
  showModal(modal);
}

/* ============================================================
   GENERIC MODAL / PANEL SYSTEM
   ============================================================ */
/* ============================================================
   REPORTS
   ============================================================ */
function defaultReportFilters(){
  const t = todayISO();
  return {from:addDays(t,-30), to:addDays(t,7), therapist:"all", status:"all", type:"all", category:"all", invStatus:"all",
    sections:{kpis:true, appointments:true, patients:true, inventory:true, requests:true, movements:true}};
}
function renderReports(){
  if(!state.ui.report) state.ui.report = defaultReportFilters();
  const f = state.ui.report;
  const host = document.getElementById("view-reports");
  const opt = (v,l,cur)=>`<option value="${v}" ${v===cur?'selected':''}>${esc(l)}</option>`;
  const sec = f.sections;
  host.innerHTML = `
  <div class="dash-head no-print">
    <div><h1>Reports</h1><div class="dash-meta"><span>Pick filters, then generate a report of the data your role can access.</span></div></div>
    <button class="btn" id="rp-print">Print report</button>
  </div>
  <div class="panel no-print" style="margin-bottom:8px;"><div class="panel-body pad">
    <div class="filter-grid">
      <div class="field"><label>From</label><input class="input" type="date" id="rp-from" value="${f.from}"></div>
      <div class="field"><label>To</label><input class="input" type="date" id="rp-to" value="${f.to}"></div>
      <div class="field"><label>Therapist</label><select class="input" id="rp-therapist">${opt("all","All therapists",f.therapist)}${THERAPISTS.map(t=>opt(t.id,t.name,f.therapist)).join("")}</select></div>
      <div class="field"><label>Appointment status</label><select class="input" id="rp-status">${opt("all","All statuses",f.status)}${["confirmed","checkedin","insession","completed","cancelled","noshow"].map(s=>opt(s,statusLabel(s),f.status)).join("")}</select></div>
      <div class="field"><label>Appointment type</label><select class="input" id="rp-type">${opt("all","All types",f.type)}${APPT_TYPES.map(t=>opt(t.id,t.name,f.type)).join("")}</select></div>
      <div class="field"><label>Inventory category</label><select class="input" id="rp-category">${opt("all","All categories",f.category)}${INV_CATEGORIES.map(c=>opt(c,c,f.category)).join("")}</select></div>
      <div class="field"><label>Inventory status</label><select class="input" id="rp-invstatus">${opt("all","All statuses",f.invStatus)}${["instock","lowstock","outstock","expiring"].map(s=>opt(s,invStatusLabel(s),f.invStatus)).join("")}</select></div>
    </div>
    <div class="field" style="margin-bottom:6px;"><label>Include in report</label></div>
    <div class="check-row">
      <label><input type="checkbox" id="rs-kpis" ${sec.kpis?'checked':''}> KPIs</label>
      <label><input type="checkbox" id="rs-appointments" ${sec.appointments?'checked':''}> Appointments</label>
      <label><input type="checkbox" id="rs-patients" ${sec.patients?'checked':''}> Patients</label>
      <label><input type="checkbox" id="rs-inventory" ${sec.inventory?'checked':''}> Inventory</label>
      <label><input type="checkbox" id="rs-requests" ${sec.requests?'checked':''}> Purchase requests</label>
      <label><input type="checkbox" id="rs-movements" ${sec.movements?'checked':''}> Stock movements</label>
    </div>
    <div style="display:flex;gap:10px;">
      <button class="btn btn-primary" id="rp-generate">Generate Report</button>
      <button class="btn btn-ghost" id="rp-reset">Reset filters</button>
    </div>
  </div></div>
  <div id="report-out"></div>`;

  document.getElementById("rp-generate").addEventListener("click", ()=>{
    const from = val("rp-from"), to = val("rp-to");
    if(!from || !to){ toast("Choose both a start and an end date"); return; }
    if(from>to){ toast("The start date must be on or before the end date"); return; }
    f.from=from; f.to=to; f.therapist=val("rp-therapist"); f.status=val("rp-status"); f.type=val("rp-type");
    f.category=val("rp-category"); f.invStatus=val("rp-invstatus");
    ["kpis","appointments","patients","inventory","requests","movements"].forEach(k=>{ f.sections[k]=document.getElementById("rs-"+k).checked; });
    saveState(); renderReportOutput(); toast("Report generated");
  });
  document.getElementById("rp-reset").addEventListener("click", ()=>{ state.ui.report=defaultReportFilters(); saveState(); renderReports(); });
  document.getElementById("rp-print").addEventListener("click", ()=>{ try{ window.print(); }catch(e){ toast("Printing isn't available here"); } });
  renderReportOutput();
}

function renderReportOutput(){
  const f = state.ui.report, sec = f.sections;
  const out = document.getElementById("report-out");
  const appts = state.appointments.filter(a=> a.date>=f.from && a.date<=f.to &&
      (f.therapist==="all"||a.therapist===f.therapist) && (f.status==="all"||a.status===f.status) && (f.type==="all"||a.type===f.type))
    .sort((a,b)=>(a.date+a.start)<(b.date+b.start)?-1:1);
  const patientIds = [...new Set(appts.map(a=>a.patientId))];
  const patients = patientIds.map(patientById).filter(Boolean);
  const newPatients = state.patients.filter(p=>p.createdAt>=f.from && p.createdAt<=f.to).length;
  const items = state.inventoryItems.filter(i=> (f.category==="all"||i.category===f.category) && (f.invStatus==="all"||invStatus(i)===f.invStatus));
  const requests = state.purchaseRequests.filter(r=> r.date>=f.from && r.date<=f.to);
  const moves = state.inventoryTransactions.filter(t=>{
    const it = itemById(t.itemId);
    return t.date>=f.from && t.date<=f.to && it && (f.category==="all"||it.category===f.category);
  });
  const cnt = s=>appts.filter(a=>a.status===s).length;
  const noShowRate = appts.length ? Math.round(cnt("noshow")/appts.length*100) : 0;
  const k = (n,l)=>`<div class="k"><div class="n">${n}</div><div class="l">${l}</div></div>`;
  const tbl = (head, rows, empty)=> rows.length
    ? `<div class="panel scrollx"><table class="dtable"><thead><tr>${head.map(x=>`<th>${x}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`
    : `<div class="panel"><div class="empty-note">${empty}</div></div>`;
  const therapistLabel = f.therapist==="all" ? "All therapists" : therapistName(f.therapist);

  let html = `<div class="rp-title"><h2>Clinic report</h2>
    <div class="rp-sub">${fmtDMY(f.from)} to ${fmtDMY(f.to)} · ${esc(therapistLabel)} · Generated ${fmtDMY(todayISO())} at ${nowTimeStr()}</div></div>`;

  if(sec.kpis){
    html += `<h3 class="section-title">KPIs</h3>
      <div class="kpi-grid">
        ${k(appts.length,"Appointments")}${k(cnt("completed"),"Completed")}${k(cnt("checkedin")+cnt("insession"),"Checked in / in session")}
        ${k(cnt("confirmed"),"Confirmed")}${k(cnt("cancelled"),"Cancelled")}${k(cnt("noshow"),"No shows")}${k(noShowRate+"%","No-show rate")}${k(newPatients,"New patients")}
      </div>
      <div class="kpi-grid" style="margin-top:12px;">
        ${k(items.length,"Inventory items")}${k(items.filter(i=>invStatus(i)==="lowstock").length,"Low stock")}${k(items.filter(i=>invStatus(i)==="outstock").length,"Out of stock")}
        ${k(items.filter(i=>invStatus(i)==="expiring").length,"Expiring soon")}${k("$"+items.reduce((s,i)=>s+i.qty*i.cost,0).toFixed(0),"Inventory value")}
      </div>`;
  }
  if(sec.appointments){
    html += `<h3 class="section-title">Appointments (${appts.length})</h3>` + tbl(["Date","Time","Patient","Type","Therapist","Room","Status"],
      appts.map(a=>`<tr><td>${fmtDMY(a.date)}</td><td>${fmtTime(a.start)}</td><td>${esc(patientName(a.patientId))}</td><td>${esc(typeName(a.type))}</td><td>${esc(therapistName(a.therapist))}</td><td>${esc(a.room)}</td><td><span class="chip chip-${statusClass(a.status)}">${statusLabel(a.status)}</span></td></tr>`),
      "No appointments match these filters.");
  }
  if(sec.patients){
    html += `<h3 class="section-title">Patients (${patients.length})</h3>` + tbl(["Patient","ID","Assigned therapist","Appointments in range","Registered"],
      patients.map(p=>`<tr><td>${esc(p.first)} ${esc(p.last)}</td><td class="mono">${p.id}</td><td>${esc(therapistName(p.therapist))}</td><td>${appts.filter(a=>a.patientId===p.id).length}</td><td>${fmtDMY(p.createdAt)}</td></tr>`),
      "No patients match these filters.");
  }
  if(sec.inventory){
    html += `<h3 class="section-title">Inventory (${items.length})</h3>` + tbl(["Item","Category","Qty","Min","Location","Expiry","Status"],
      items.map(i=>{ const st=invStatus(i); return `<tr><td>${esc(i.name)}<div style="font-size:11.5px;color:var(--ink-faint);">${esc(i.sku)}</div></td><td>${esc(i.category)}</td><td>${i.qty} ${esc(i.unit)}</td><td>${i.min}</td><td>${esc(i.location)}</td><td>${i.expiry?fmtDMY(i.expiry):"—"}</td><td><span class="chip chip-${st}">${invStatusLabel(st)}</span></td></tr>`; }),
      "No inventory items match these filters.");
  }
  if(sec.requests){
    html += `<h3 class="section-title">Purchase requests (${requests.length})</h3>` + tbl(["Request","Items","Supplier","Est. cost","Requested by","Date","Status"],
      requests.map(r=>`<tr><td>${r.id}</td><td>${r.items.map(it=>esc(itemById(it.itemId).name)+" ×"+it.qty).join(", ")}</td><td>${esc(supplierById(r.supplier).name)}</td><td>$${r.estCost.toFixed(2)}</td><td>${esc(r.requestedBy)}</td><td>${fmtDMY(r.date)}</td><td><span class="chip chip-${statusClass(r.status)}">${r.status}</span></td></tr>`),
      "No purchase requests in this date range.");
  }
  if(sec.movements){
    html += `<h3 class="section-title">Stock movements (${moves.length})</h3>` + tbl(["Date","Item","Movement","Qty","User","Reason"],
      moves.map(t=>`<tr><td>${fmtDMY(t.date)}</td><td>${esc(itemById(t.itemId).name)}</td><td>${esc(t.type)}</td><td>${t.qty}</td><td>${esc(t.user)}</td><td>${esc(t.reason||"—")}</td></tr>`),
      "No stock movements in this date range.");
  }
  if(!Object.values(sec).some(Boolean)) html += `<div class="panel" style="margin-top:16px;"><div class="empty-note">Select at least one section to include, then generate the report again.</div></div>`;
  html += `<p class="hint" style="margin-top:18px;color:var(--ink-faint);font-size:12px;">Billing and clinical notes aren't included in reports for the Reception role.</p>`;
  out.innerHTML = html;
}

/* ============================================================
   PROFILE / LOG OUT
   ============================================================ */
function openProfilePanel(){
  if(ROLE!=="reception") return tProfile();
  const panel = sidePanelTemplate("My profile", `
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:22px;">
      <div class="avatar" style="width:56px;height:56px;font-size:18px;">RC</div>
      <div><div style="font-family:var(--font-display);font-size:18px;font-weight:600;">Rudo Chikwanha</div><div style="color:var(--ink-faint);font-size:12.5px;">Receptionist</div></div>
    </div>
    <div class="kv-grid">
      <div class="kv"><div class="k">Email</div><div class="v">rudo.chikwanha@clinicos.demo</div></div>
      <div class="kv"><div class="k">Portal</div><div class="v">Reception Desk</div></div>
      <div class="kv"><div class="k">Clinic</div><div class="v">Clinic OS Physiotherapy — Borrowdale, Harare</div></div>
      <div class="kv"><div class="k">Operating hours</div><div class="v">08:00 – 17:00</div></div>
    </div>
    <h3 class="section-title">Your access</h3>
    <p style="color:var(--ink-soft);font-size:13px;margin-bottom:8px;">You can register patients, manage appointments and check-ins, and manage inventory.</p>
    <p style="color:var(--ink-faint);font-size:13px;">Clinical notes, assessments, diagnoses and treatment plans are managed by therapists and aren't available in this portal.</p>
  `, [
    {label:"Close", cls:"btn-ghost", action:closePanel},
    {label:"Log out", cls:"btn-danger", action:logOut}
  ]);
  showPanel(panel);
}
function logOut(){
  closePanel();
  document.getElementById("app").classList.add("hidden");
  document.getElementById("login-screen").classList.remove("hidden");
  toast("You've been logged out");
}

function val(id){ return document.getElementById(id).value; }
function modalTemplate(title, bodyHtml, actions){
  const wrap = document.createElement("div");
  wrap.className = "overlay center";
  wrap.innerHTML = `<div class="modal-box">
    <div class="panel-title-row"><h2>${title}</h2><button class="btn btn-icon btn-ghost" id="modal-close">✕</button></div>
    <div class="panel-scroll">${bodyHtml}</div>
    <div class="panel-actions">${actions.map((a,i)=>`<button class="btn ${a.cls}" data-i="${i}">${a.label}</button>`).join("")}</div>
  </div>`;
  wrap._actions = actions;
  wrap.addEventListener("mousedown", (e)=>{ if(e.target===wrap) closeModal(); });
  return wrap;
}
function showModal(wrap){
  document.getElementById("modal-root").appendChild(wrap);
  wrap.querySelector("#modal-close").addEventListener("click", closeModal);
  wrap.querySelectorAll(".panel-actions [data-i]").forEach(btn=>{
    btn.addEventListener("click", ()=> wrap._actions[Number(btn.dataset.i)].action());
  });
}
function closeModal(){ document.getElementById("modal-root").innerHTML = ""; }

function sidePanelTemplate(title, bodyHtml, actions){
  const wrap = document.createElement("div");
  wrap.className = "overlay";
  wrap.innerHTML = `<div class="side-panel">
    <div class="panel-title-row"><h2>${title}</h2><button class="btn btn-icon btn-ghost" id="panel-close">✕</button></div>
    <div class="panel-scroll">${bodyHtml}</div>
    <div class="panel-actions">${actions.map((a,i)=>`<button class="btn ${a.cls} btn-sm" data-i="${i}">${a.label}</button>`).join("")}</div>
  </div>`;
  wrap._actions = actions;
  wrap.addEventListener("mousedown", (e)=>{ if(e.target===wrap) closePanel(); });
  return wrap;
}
function showPanel(wrap){
  document.getElementById("modal-root").appendChild(wrap);
  wrap.querySelector("#panel-close").addEventListener("click", closePanel);
  wrap.querySelectorAll(".panel-actions [data-i]").forEach(btn=>{
    btn.addEventListener("click", ()=> wrap._actions[Number(btn.dataset.i)].action());
  });
}
function closePanel(){ document.getElementById("modal-root").innerHTML = ""; }

function confirmDialog(title, body, onConfirm){
  const modal = modalTemplate(title, `<p style="color:var(--ink-soft);">${body}</p>`, [
    {label:"Cancel", cls:"btn-ghost", action:closeModal},
    {label:"Confirm", cls:"btn-primary", action:()=>{ closeModal(); onConfirm(); }}
  ]);
  showModal(modal);
}

/* ============================================================
   NOTIFICATIONS PANEL
   ============================================================ */
function openNotifications(){
  const icons = {waiting:"⏱", lowstock:"▣", outstock:"▣", expiring:"⏳", appointment:"▤", cancellation:"⊘", purchase:"▧"};
  const body = state.notifications.map(n=>`
    <div class="notif-mini" style="cursor:pointer;${n.read?'':'background:var(--brand-soft);'}" data-id="${n.id}">
      <div class="t">${icons[n.type]||"•"} ${esc(n.title)}</div>
      <div class="d">${esc(n.detail)} · ${n.time}</div>
    </div>`).join("");
  const panel = sidePanelTemplate("Notifications", body || '<div class="empty-note">No notifications yet.</div>', [
    {label:"Mark all as read", cls:"btn-ghost", action:()=>{ state.notifications.forEach(n=>n.read=true); saveState(); refreshBadges(); closePanel(); }}
  ]);
  showPanel(panel);
  panel.querySelectorAll("[data-id]").forEach(row=>{
    row.addEventListener("click", ()=>{
      const n = state.notifications.find(x=>x.id===row.dataset.id);
      n.read = true; saveState(); refreshBadges();
      row.style.background = "transparent";
    });
  });
}

/* ============================================================
   GLOBAL SEARCH
   ============================================================ */
function runGlobalSearch(q){
  q = q.trim().toLowerCase();
  if(!q) return null;
  const patients = state.patients.filter(p=> (p.first+" "+p.last).toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || p.phone.includes(q) || p.email.toLowerCase().includes(q)).slice(0,5);
  const appts = state.appointments.filter(a=> patientName(a.patientId).toLowerCase().includes(q) || typeName(a.type).toLowerCase().includes(q)).slice(0,5);
  const inv = state.inventoryItems.filter(i=> i.name.toLowerCase().includes(q) || i.sku.toLowerCase().includes(q)).slice(0,5);
  const sup = state.suppliers.filter(s=> s.name.toLowerCase().includes(q)).slice(0,5);
  return {patients, appts, inv, sup};
}
function renderSearchResults(q){
  const host = document.getElementById("search-results");
  const r = runGlobalSearch(q);
  if(!r || (!r.patients.length && !r.appts.length && !r.inv.length && !r.sup.length)){ host.classList.add("hidden"); return; }
  host.classList.remove("hidden");
  let html = "";
  if(r.patients.length){ html += `<div class="search-group-title">Patients</div>` + r.patients.map(p=>`
    <div class="search-row" data-goto="patient" data-id="${p.id}"><div><div class="t1">${esc(p.first)} ${esc(p.last)}</div><div class="t2">${p.id} · ${esc(p.phone)}</div></div></div>`).join(""); }
  if(r.appts.length){ html += `<div class="search-group-title">Appointments</div>` + r.appts.map(a=>`
    <div class="search-row" data-goto="appt" data-id="${a.id}"><div><div class="t1">${esc(patientName(a.patientId))} — ${fmtTime(a.start)}</div><div class="t2">${esc(typeName(a.type))} · ${fmtDateShort(a.date)}</div></div></div>`).join(""); }
  if(r.inv.length){ html += `<div class="search-group-title">Inventory</div>` + r.inv.map(i=>`
    <div class="search-row" data-goto="inv" data-id="${i.id}"><div><div class="t1">${esc(i.name)}</div><div class="t2">${i.qty} ${esc(i.unit)} · ${esc(i.category)}</div></div></div>`).join(""); }
  if(r.sup.length){ html += `<div class="search-group-title">Suppliers</div>` + r.sup.map(s=>`
    <div class="search-row" data-goto="sup" data-id="${s.id}"><div><div class="t1">${esc(s.name)}</div><div class="t2">${esc(s.contact)}</div></div></div>`).join(""); }
  host.innerHTML = html;
  host.querySelectorAll("[data-goto]").forEach(row=>{
    row.addEventListener("click", ()=>{
      const type=row.dataset.goto, id=row.dataset.id;
      document.getElementById("global-search").value="";
      host.classList.add("hidden");
      if(type==="patient"){ setView("patients"); openPatientPanel(id); }
      else if(type==="appt"){ setView("calendar"); openAppointmentPanel(id); }
      else if(type==="inv"){ state.ui.invTab="items"; setView("inventory"); }
      else if(type==="sup"){ state.ui.invTab="suppliers"; setView("inventory"); }
    });
  });
}

/* ============================================================
   QUICK ACTIONS
   ============================================================ */
function bindQA(el){
  el.addEventListener("click", ()=>{
    const action = el.dataset.qa;
    document.getElementById("qa-menu").classList.add("hidden");
    if(action==="register-patient") openRegisterWizard();
    else if(action==="book-appointment") openAppointmentModal({patientId: el.dataset.pid||""});
    else if(action==="check-in") openGlobalCheckIn();
    else if(action==="add-inventory") openAddInventoryModal();
    else if(action==="stock-movement") openStockMovementModal();
    else if(action==="purchase-request") openPurchaseRequestModal();
  });
}
function openGlobalCheckIn(){
  const modal = modalTemplate("Check In Patient", `
    <div class="field"><label>Search Patient</label><input class="input" id="ci-search" placeholder="Name, ID or phone…"></div>
    <div id="ci-results"></div>
  `, [{label:"Close", cls:"btn-ghost", action:closeModal}]);
  showModal(modal);
  const input = document.getElementById("ci-search");
  const results = document.getElementById("ci-results");
  function draw(){
    const q = input.value.trim().toLowerCase();
    const list = state.patients.filter(p=>!q || (p.first+" "+p.last).toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || p.phone.includes(q));
    results.innerHTML = list.map(p=>{
      const appt = state.appointments.find(a=>a.patientId===p.id && a.date===todayISO() && a.status!=="cancelled");
      return `<div class="search-row"><div><div class="t1">${esc(p.first)} ${esc(p.last)}</div><div class="t2">${appt? fmtTime(appt.start)+" · "+esc(typeName(appt.type)) : "No appointment today"}</div></div>
        <button class="btn btn-sm ${appt?'btn-primary':''}" data-id="${p.id}" ${appt?'':'disabled'}>Check In</button></div>`;
    }).join("") || '<div class="empty-note">No matches.</div>';
    results.querySelectorAll("[data-id]").forEach(b=> b.addEventListener("click", ()=>{ openCheckInModal(b.dataset.id); closeModal(); }));
  }
  input.addEventListener("input", draw); draw();
}

/* ============================================================
   INIT
   ============================================================ */
function init(){
  document.getElementById("login-btn").addEventListener("click", ()=>{
    document.getElementById("login-screen").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
    setView(state.ui.view || "dashboard");
    refreshBadges();
  });
  document.querySelectorAll(".role-chip").forEach(c=>{
    c.addEventListener("click", ()=>{
      document.querySelectorAll(".role-chip").forEach(x=>x.classList.remove("active"));
      c.classList.add("active");
      setRole(c.dataset.role);
    });
  });

  document.querySelectorAll(".sb-item[data-qa]").forEach(bindQA);
  if(window.innerWidth<1150) document.getElementById("sidebar").classList.add("collapsed");
  document.querySelectorAll(".sb-item").forEach(el=>{ const l=el.querySelector(".sb-label"); if(l) el.title=l.textContent; });
  document.getElementById("mobile-collapse-btn").addEventListener("click", ()=>{
    document.getElementById("sidebar").classList.toggle("collapsed");
  });

  const qaBtn = document.getElementById("qa-btn"), qaMenu = document.getElementById("qa-menu");
  qaBtn.addEventListener("click", (e)=>{ e.stopPropagation(); document.getElementById("avatar-menu").classList.add("hidden"); qaMenu.classList.toggle("hidden"); });
  const avBtn = document.getElementById("avatar-btn"), avMenu = document.getElementById("avatar-menu");
  avBtn.addEventListener("click", (e)=>{ e.stopPropagation(); qaMenu.classList.add("hidden"); avMenu.classList.toggle("hidden"); });
  document.getElementById("menu-profile").addEventListener("click", ()=>{ avMenu.classList.add("hidden"); openProfilePanel(); });
  document.getElementById("menu-logout").addEventListener("click", ()=>{ avMenu.classList.add("hidden"); logOut(); });
  document.addEventListener("click", ()=>{ qaMenu.classList.add("hidden"); avMenu.classList.add("hidden"); });
  qaMenu.querySelectorAll("[data-qa]").forEach(bindQA);

  const search = document.getElementById("global-search");
  search.addEventListener("input", ()=> renderSearchResults(search.value));
  search.addEventListener("focus", ()=> { if(search.value) renderSearchResults(search.value); });
  document.addEventListener("click", (e)=>{ if(!e.target.closest(".search-wrap")) document.getElementById("search-results").classList.add("hidden"); });

  window.addEventListener("keydown", (e)=>{
    if((e.metaKey||e.ctrlKey) && e.key==="k"){ e.preventDefault(); search.focus(); }
    if(e.key==="Escape"){ closeModal(); }
  });
}
/* ============================================================
   PHYSIOTHERAPIST PORTAL (shares state, helpers and UI patterns with Reception)
   ============================================================ */
const ALL_TH=THERAPISTS.slice(), ME="th_tendai", MYNAME="Dr. Tendai Moyo";
let ROLE="reception", RNAV=null, RQA=null;
const T_NAV=[["dashboard","▦","Dashboard"],["schedule","▤","My Schedule"],["patients","◍","Patients"],["assessments","✎","Assessments"],["soap","▧","SOAP Notes"],["plans","◈","Treatment Plans"],["reports","▥","Progress Reports"]];
const T_VIEWS=T_NAV.map(n=>n[0]).concat(["settings","help"]);
const R_VIEWS=["dashboard","calendar","patients","inventory","reports","settings","help"];
const ATYPES=["Initial Physiotherapy Assessment","Musculoskeletal Assessment","Sports Injury Assessment","Post-operative Assessment","Neurological Assessment","Paediatric Assessment","Cardiopulmonary Assessment","Reassessment","Discharge Assessment"];
const DOCS={
  note:{coll:"notes",title:"SOAP note",req:["S","O","A","P"],fields:[["S","S — Subjective","Patient-reported condition, symptoms, changes since last session"],["O","O — Objective","Measurable findings, ROM, strength, treatment observations"],["A","A — Assessment","Clinical interpretation, progress, response to treatment, barriers"],["P","P — Plan","Treatment provided, exercises / HEP, frequency, reassessment date"]]},
  assess:{coll:"assessments",title:"Assessment",req:["complaint","impression"],fields:[["complaint","Presenting complaint & history"],["onset","Onset and mechanism of injury"],["aggr","Aggravating / easing factors"],["obs","Observation, posture & gait"],["rom","Range of motion"],["strength","Muscle strength & neurological"],["special","Special tests & palpation"],["impression","Clinical impression & reasoning"],["goals","Goals — short-term, long-term, review date"]]}
};
const C=()=>state.clin, g$=id=>document.getElementById(id);
const myPts=()=>state.patients.filter(p=>p.therapist===ME);
const kindFor=a=>["initial","discharge"].includes(a.type)?"assess":"note";
const hasFinal=a=>C()[DOCS[kindFor(a)].coll].some(x=>x.status==="final"&&(x.apptId===a.id||(x.pid===a.patientId&&x.date===a.date)));
const mineToday=()=>apptsOn(todayISO()).filter(a=>a.therapist===ME).sort((a,b)=>timeToMin(a.start)-timeToMin(b.start));
const pendingNotes=()=>state.appointments.filter(a=>a.therapist===ME&&a.date<=todayISO()&&["completed","insession"].includes(a.status)&&!hasFinal(a));
const dueReviews=()=>C().plans.filter(p=>p.status==="Active"&&p.review<=addDays(todayISO(),7));
const planOf=pid=>C().plans.find(p=>p.pid===pid&&["Active","Under Review"].includes(p.status))||C().plans.filter(p=>p.pid===pid).slice(-1)[0];
const notesOf=pid=>C().notes.filter(n=>n.pid===pid).sort((a,b)=>a.date<b.date?1:-1);
const lastFinal=pid=>notesOf(pid).find(n=>n.status==="final");
const newDoc=(k,pid,apptId)=>({id:uid(k==="note"?"N":"AS"),pid,apptId:apptId||null,date:todayISO(),status:"draft",author:ME,m:{},amendments:[],type:k==="assess"?ATYPES[0]:undefined});
const stampStr=s=>s?fmtDMY(s.slice(0,10))+(s.length>10?" "+new Date(s).toTimeString().slice(0,5):""):"";
const dchip=s=>`<span class="chip chip-${s==="final"?"approved":"draft"}">${s==="final"?"Final":"Draft"}</span>`;
const pchip=s=>`<span class="chip chip-${{Active:"checkedin",Draft:"draft","Under Review":"insession",Completed:"completed",Discontinued:"cancelled"}[s]||"draft"}">${s}</span>`;
const tHead=(h,sub,btn)=>`<div class="dash-head"><div><h1>${h}</h1><div class="dash-meta"><span>${sub}</span></div></div>${btn||""}</div>`;
const strip=a=>`<div class="stat-strip">${a.map(([n,l])=>`<div class="stat"><div class="n">${n}</div><div class="l">${l}</div></div>`).join("")}</div>`;
function alerts(p){ const o=[],bad=v=>v&&!/^(none|none known|none reported)$/i.test(v.trim());
  if(bad(p.allergies)) o.push("Allergy: "+p.allergies); if(bad(p.conditions)) o.push("Medical: "+p.conditions); if(bad(p.medication)) o.push("Medication: "+p.medication);
  return o.map(x=>`<span class="alert-chip">${esc(x)}</span>`).join(""); }

/* ---- measurements & goals ---- */
function series(pid,key){ const a=[]; ["notes","assessments"].forEach(c=>C()[c].filter(n=>n.pid===pid&&n.status==="final"&&n.m&&n.m[key]!=null).forEach(n=>a.push({d:n.date,v:n.m[key]})));
  C().measures.filter(m=>m.pid===pid&&m.key===key).forEach(m=>a.push({d:m.date,v:m.value})); return a.sort((x,y)=>x.d<y.d?-1:1); }
function goalProg(pid,g){ const s=series(pid,g.key); if(!s.length) return null; const l=s[s.length-1].v, ch=l-g.baseline, tot=g.target-g.baseline;
  return {latest:l,change:Math.abs(ch),pct:Math.max(0,Math.min(100,Math.round(ch/tot*100))),good:ch*tot>0}; }
function chart(label,unit,s){
  if(s.length<2) return `<div class="hint" style="margin-bottom:12px">${esc(label)}: not enough recorded measurements to chart.</div>`;
  const W=340,H=130,p=30,xs=s.map((_,i)=>p+i*(W-2*p)/(s.length-1)),mn=Math.min(...s.map(x=>x.v)),mx=Math.max(...s.map(x=>x.v)),y=v=>H-p-(mx===mn?.5:(v-mn)/(mx-mn))*(H-2*p);
  return `<div style="margin-bottom:16px"><div style="font-weight:600;font-size:12.5px;margin-bottom:4px">${esc(label)} (${esc(unit)})</div><svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:${W}px" role="img" aria-label="${esc(label)} over time"><polyline fill="none" stroke="var(--brand)" stroke-width="2" points="${s.map((x,i)=>xs[i]+","+y(x.v)).join(" ")}"/>${s.map((x,i)=>`<circle cx="${xs[i]}" cy="${y(x.v)}" r="3.5" fill="var(--brand)"/><text x="${xs[i]}" y="${y(x.v)-8}" font-size="9" text-anchor="middle" fill="currentColor">${x.v}</text><text x="${xs[i]}" y="${H-10}" font-size="8" text-anchor="middle" fill="var(--ink-faint)">${fmtDMY(x.d).slice(0,5)}</text>`).join("")}</svg></div>`; }
function charts(pid,from,to){ const pl=planOf(pid), f=s=>s.filter(x=>(!from||x.d>=from)&&(!to||x.d<=to));
  return chart("Pain score","/10",f(series(pid,"pain")))+(pl?pl.goals.filter(x=>x.key!=="pain").map(x=>chart(x.label,x.unit,f(series(pid,x.key)))).join(""):""); }

/* ---- role / portal switching ---- */
function tMap(v){
  if(ROLE==="therapist"){ if(v==="calendar") v="schedule"; return T_VIEWS.includes(v)?v:"dashboard"; }
  if(isAdmin()){ if(["calendar","patients","inventory"].includes(v)) v="rx-"+v; if(ROLE==="it"&&v==="servicedesk") v="dashboard"; return VIEWS_FOR[ROLE].includes(v)?v:"dashboard"; }
  return R_VIEWS.includes(v)?v:"dashboard"; }
function tEnsureView(v){ const id=(ROLE==="therapist"&&v==="schedule")?"calendar":v.replace(/^rx-/,""); let el=g$("view-"+id);
  if(!el){ el=document.createElement("div"); el.className="view hidden"; el.id="view-"+id; g$("main").appendChild(el); } return el; }
function tRender(v){ const m={dashboard:tDashboard,schedule:renderCalendar,patients:tPatients,assessments:tAssess,soap:tSoap,plans:tPlans,reports:tReports};
  (m[v]||(()=>renderPlaceholder(v,v==="help"?"Help &amp; Support":"Settings","This area is available in the full Clinic OS build.")))(); }
function applyRole(){
  const sb=document.querySelector(".sb-scroll"), qa=g$("qa-menu"), r=ROLE, P=PEOPLE[r];
  if(RNAV===null){ RNAV=sb.innerHTML; RQA=qa.innerHTML; }
  const it=(v,i,l)=>`<div class="sb-item" data-view="${v}" title="${l}"><span class="ic">${i}</span><span class="sb-label">${l}</span></div>`, sec=(t,items)=>`<div class="sb-section-title">${t}</div>${items.map(n=>it(...n)).join("")}`, tail=sec("Additional",[["settings","⚙","Settings"],["help","?","Help"]]);
  sb.innerHTML=r==="therapist"?sec("Main",T_NAV)+tail:isAdmin()?ADMIN_NAV[r].map(x=>sec(x[0],x[1])).join("")+tail:RNAV;
  const extra=`<button data-aqa="ticket">☎ New IT Ticket</button><button data-aqa="user">◍ Add User</button>`;
  qa.innerHTML=r==="therapist"?`<button data-tqa="open">◍ Open Patient Record</button><button data-tqa="assess">✎ Start Assessment</button><button data-tqa="note">▧ Create SOAP Note</button><button data-tqa="plan">◈ Create Treatment Plan</button><button data-tqa="report">▥ Generate Progress Report</button>`:r==="owner"?RQA+`<button data-aqa="user">◍ Add Staff Member</button>`:r==="it"?extra+`<button data-aqa="backup">♥ Run Backup</button>`:RQA;
  if(r==="owner"||r==="reception") qa.querySelectorAll("[data-qa]").forEach(bindQA);
  THERAPISTS.length=0; (r==="therapist"?[ALL_TH.find(x=>x.id===ME)]:ALL_TH).forEach(x=>THERAPISTS.push(x));
  g$("avatar-btn").textContent=P.ini; document.querySelector("#avatar-menu .mh1").textContent=P.name; document.querySelector("#avatar-menu .mh2").textContent=P.role;
  document.querySelector(".search-wrap").style.visibility=r==="it"?"hidden":""; state.ui.view="dashboard"; closePanel();
}
function setRole(r,keepEmail){ ROLE=["therapist","owner","it"].includes(r)?r:"reception"; const P=PEOPLE[ROLE];
  if(!keepEmail) g$("login-email").value=P.email;
  g$("login-btn").textContent="Sign in to "+{reception:"Reception Desk",therapist:"Physiotherapist Portal",owner:"Clinic Owner Portal",it:"IT Manager Portal"}[ROLE];
  document.querySelectorAll(".role-chip").forEach(c=>c.classList.toggle("active",c.dataset.role===ROLE)); applyRole(); }

/* ---- shared generic UI helpers ---- */
function tPanel(title,cls){ const root=g$("modal-root"); root.innerHTML=""; const w=document.createElement("div"); w.className="overlay";
  w.innerHTML=`<div class="side-panel ${cls||"wide"}"><div class="panel-title-row"><h2>${title}</h2><button class="btn btn-icon btn-ghost no-print" id="panel-close" aria-label="Close">✕</button></div><div class="panel-scroll" style="padding:0"></div></div>`;
  w.addEventListener("mousedown",e=>{ if(e.target===w) closePanel(); }); root.appendChild(w); w.querySelector("#panel-close").onclick=closePanel; return w.querySelector(".panel-scroll"); }
function tList(host,head,rows,empty){
  host.innerHTML=rows.length?`<div class="scrollx"><table class="dtable dir-table"><thead><tr>${head.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map((r,i)=>`<tr class="dir-row" data-i="${i}" tabindex="0">${r[0].map(c=>`<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`:`<div class="empty-note">${empty}</div>`;
  host.querySelectorAll("tr.dir-row").forEach(tr=>{ const f=rows[tr.dataset.i][1]; tr.addEventListener("click",f); tr.addEventListener("keydown",e=>{ if(e.key==="Enter") f(); }); }); }
function tPickPatient(title,cb){
  const m=modalTemplate(title,`<div class="field"><label>Patient</label><select class="input" id="pk-p">${myPts().map(p=>`<option value="${p.id}">${esc(p.first)} ${esc(p.last)} · ${p.id}</option>`).join("")}</select></div>`,
    [{label:"Cancel",cls:"btn-ghost",action:closeModal},{label:"Continue",cls:"btn-primary",action:()=>{ const v=val("pk-p"); closeModal(); cb(v); }}]); showModal(m); }
function tQuick(a){ const f={open:id=>tPatientPanel(id,"overview"),assess:id=>tDoc("assess",newDoc("assess",id)),note:id=>tDoc("note",newDoc("note",id)),plan:id=>tPlanForm(id),report:id=>tReportForm(id)}[a];
  tPickPatient({open:"Open patient record",assess:"Start assessment",note:"Create SOAP note",plan:"Create treatment plan",report:"Generate progress report"}[a],f); }

/* ---- Dashboard ---- */
function tDashboard(){
  const mine=mineToday(), open=mine.filter(a=>["confirmed","checkedin","insession"].includes(a.status)), seen=mine.filter(a=>a.status==="completed").length;
  const pend=pendingNotes(), rev=dueReviews(), noA=mine.filter(a=>kindFor(a)==="assess"&&a.status!=="completed"&&!hasFinal(a));
  const fu=new Set(rev.map(p=>p.pid).concat(C().plans.filter(p=>p.status==="Active"&&!nextAppt(p.pid)).map(p=>p.pid)));
  const nx=open[0], h=tEnsureView("dashboard"), tasks=[];
  pend.forEach(a=>tasks.push([`Complete ${DOCS[kindFor(a)].title.toLowerCase()} — ${patientName(a.patientId)}`,`${fmtDMY(a.date)} · ${typeName(a.type)}`,()=>tDocForAppt(a)]));
  noA.forEach(a=>tasks.push([`Assessment due — ${patientName(a.patientId)}`,`${fmtTime(a.start)} · ${typeName(a.type)}`,()=>tApptPanel(a.id)]));
  rev.forEach(pl=>tasks.push([`Treatment plan review due — ${patientName(pl.pid)}`,`${pl.condition} · review ${fmtDMY(pl.review)}`,()=>tPlanPanel(pl.id)]));
  let np=`<div class="panel" style="margin-bottom:22px"><div class="empty-note">No more appointments today.</div></div>`;
  if(nx){ const p=patientById(nx.patientId), lv=lastAppt(p.id), pl=planOf(p.id);
    np=`<div class="panel" style="margin-bottom:22px"><div class="panel-head"><h3>My Next Appointment</h3><span class="chip chip-${statusClass(nx.status)}">${statusLabel(nx.status)}</span></div><div class="panel-body pad"><div style="display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap"><div><div style="font-family:var(--font-display);font-size:20px;font-weight:600">${esc(patientName(p.id))}</div><div class="hint">${fmtTime(nx.start)} · ${esc(typeName(nx.type))} · ${timeToMin(nx.end)-timeToMin(nx.start)} min · ${p.id}</div><div class="hint" style="margin-top:6px">Last visit: ${lv?fmtDMY(lv.date):"First visit"} · Plan: ${pl?esc(pl.condition):"None yet"}</div><div style="margin-top:10px">${alerts(p)}</div></div><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-start"><button class="btn btn-sm" id="nx-rec">Open Patient Record</button><button class="btn btn-sm" id="nx-soap">View Previous SOAP Note</button><button class="btn btn-primary btn-sm" id="nx-start">${nx.status==="insession"?"Resume Session":"Start Session"}</button></div></div></div></div>`; }
  const rem=C().plans.filter(p=>p.status==="Active").map(p=>{ const r=[]; if(p.review<=addDays(todayISO(),7)) r.push("Due for reassessment · review "+fmtDMY(p.review)); if(!nextAppt(p.pid)) r.push("No follow-up booked");
    const gp=p.goals.map(x=>goalProg(p.pid,x)).filter(Boolean); if(gp.length&&gp.every(x=>x.pct>=80)) r.push("Approaching end of plan"); return r.length?[p,r]:null; }).filter(Boolean);
  h.innerHTML=`<div class="dash-head"><div><h1>Good morning, Dr. Tendai</h1><div class="dash-meta"><span>${fmtDateLong(todayISO())}</span></div></div><button class="btn btn-primary" id="t-sched">View My Schedule</button></div>
  <div class="stat-strip">${[[mine.length,"Today's Appointments","schedule"],[seen,"Patients Seen","schedule"],[open.length,"Patients Remaining","schedule"],[noA.length,"Assessments Due","assessments"],[pend.length,"Notes Pending","soap"],[fu.size,"Follow-ups Required","plans"]].map(([n,l,v])=>`<div class="stat" data-v="${v}"><div class="n">${n}</div><div class="l">${l}</div></div>`).join("")}</div>${np}
  <div class="dash-grid"><div><div class="panel" style="margin-bottom:22px"><div class="panel-head"><h3>Today's Schedule</h3><button class="btn btn-ghost btn-sm" data-v="schedule">Open schedule</button></div><div class="panel-body" id="td-sched"></div></div>
  <div class="panel"><div class="panel-head"><h3>Needs Attention</h3></div><div class="panel-body" id="td-tasks"></div></div></div>
  <div class="dash-side"><div class="panel"><div class="panel-head"><h3>Follow-up Reminders</h3></div><div class="panel-body" id="td-rem"></div></div></div></div>`;
  g$("td-sched").innerHTML=mine.length?mine.map(a=>`<div class="sched-row" data-id="${a.id}" style="cursor:pointer"><div class="sched-time">${fmtTime(a.start)}</div><div class="sched-main"><div class="name">${esc(patientName(a.patientId))} <span style="font-weight:400;color:var(--ink-faint)">· ${esc(typeName(a.type))}</span></div><div class="sub">${timeToMin(a.end)-timeToMin(a.start)} min</div></div><div class="sched-room">${esc(a.room)}</div><span class="chip chip-${statusClass(a.status)}">${statusLabel(a.status)}</span></div>`).join(""):'<div class="empty-note">No appointments scheduled for today.</div>';
  g$("td-sched").querySelectorAll("[data-id]").forEach(r=>r.onclick=()=>tApptPanel(r.dataset.id));
  const T=g$("td-tasks"); T.innerHTML=tasks.length?tasks.map((x,i)=>`<div class="notif-mini" data-i="${i}" style="cursor:pointer"><div class="t">${esc(x[0])}</div><div class="d">${esc(x[1])}</div></div>`).join(""):'<div class="empty-note">Nothing needs attention — documentation is up to date.</div>';
  T.querySelectorAll("[data-i]").forEach(r=>r.onclick=tasks[r.dataset.i][2]);
  const R=g$("td-rem"); R.innerHTML=rem.length?rem.map(([p,r],i)=>`<div class="notif-mini" data-i="${i}" style="cursor:pointer"><div class="t">${esc(patientName(p.pid))}</div><div class="d">${esc(r.join(" · "))}</div></div>`).join(""):'<div class="empty-note">No reminders right now.</div>';
  R.querySelectorAll("[data-i]").forEach(r=>r.onclick=()=>tPatientPanel(rem[r.dataset.i][0].pid,"treatment"));
  h.querySelectorAll("[data-v]").forEach(b=>b.onclick=()=>setView(b.dataset.v)); g$("t-sched").onclick=()=>setView("schedule");
  if(nx){ g$("nx-rec").onclick=()=>tPatientPanel(nx.patientId,"overview"); g$("nx-start").onclick=()=>nx.status==="insession"?tDocForAppt(nx):tStart(nx);
    g$("nx-soap").onclick=()=>{ const n=lastFinal(nx.patientId); n?tDoc("note",n):toast("No previous SOAP note for this patient yet."); }; }
}

/* ---- Sessions & appointment panel ---- */
function tDocForAppt(a){ const k=kindFor(a); tDoc(k,C()[DOCS[k].coll].find(x=>x.apptId===a.id)||newDoc(k,a.patientId,a.id)); }
function tStart(a){ a.status="insession"; saveState(); refreshCurrentView(); tDocForAppt(a); }
function tComplete(a){ if(!hasFinal(a)){ toast("Finalize the "+DOCS[kindFor(a)].title.toLowerCase()+" before completing this session."); return; }
  a.status="completed"; saveState(); closePanel(); refreshCurrentView(); toast("Session completed"); }
function tApptPanel(id){
  const a=state.appointments.find(x=>x.id===id); if(!a) return; const p=patientById(a.patientId), lv=lastAppt(p.id), ln=lastFinal(p.id), pl=planOf(p.id), b=tPanel("Appointment");
  const live=a.status==="insession", can=["confirmed","checkedin"].includes(a.status), need=["completed","insession"].includes(a.status)&&!hasFinal(a);
  b.innerHTML=`<div style="padding:20px 24px"><div class="kv-grid" style="margin-bottom:16px"><div class="kv"><div class="k">Patient</div><div class="v">${esc(patientName(p.id))} · ${p.id}</div></div><div class="kv"><div class="k">Status</div><div class="v"><span class="chip chip-${statusClass(a.status)}">${statusLabel(a.status)}</span></div></div>
  <div class="kv"><div class="k">When</div><div class="v">${fmtDMY(a.date)} · ${fmtTime(a.start)}–${fmtTime(a.end)}</div></div><div class="kv"><div class="k">Type · Room</div><div class="v">${esc(typeName(a.type))} · ${esc(a.room)}</div></div>
  <div class="kv"><div class="k">Previous visit</div><div class="v">${lv?fmtDMY(lv.date)+" · "+esc(typeName(lv.type)):"None"}</div></div><div class="kv"><div class="k">Active treatment plan</div><div class="v">${pl?esc(pl.condition):"None yet"}</div></div></div>
  <div class="kv" style="margin-bottom:14px"><div class="k">Last documented treatment</div><div class="v">${ln?fmtDMY(ln.date)+" — "+esc(ln.P):"No finalized SOAP note yet"}</div></div>
  ${alerts(p)?`<div class="kv" style="margin-bottom:14px"><div class="k">Clinical alerts</div><div class="v" style="margin-top:6px">${alerts(p)}</div></div>`:""}
  ${need?`<div class="kv" style="margin-bottom:14px"><div class="k">Outstanding documentation</div><div class="v" style="color:var(--clay)">${DOCS[kindFor(a)].title} not yet finalized</div></div>`:""}
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-sm" id="ap-rec">Open Patient Record</button><button class="btn btn-sm" id="ap-ass">View Assessment</button><button class="btn btn-sm" id="ap-hist">View SOAP History</button>
  ${can?'<button class="btn btn-primary btn-sm" id="ap-start">Start Session</button>':""}${live?'<button class="btn btn-sm" id="ap-doc">Resume Documentation</button><button class="btn btn-primary btn-sm" id="ap-done">Complete Session</button>':""}</div></div>`;
  g$("ap-rec").onclick=()=>tPatientPanel(p.id,"overview"); g$("ap-hist").onclick=()=>tPatientPanel(p.id,"history");
  g$("ap-ass").onclick=()=>{ const x=C().assessments.filter(s=>s.pid===p.id).sort((s,t)=>s.date<t.date?1:-1)[0]; x?tDoc("assess",x):toast("No assessment recorded for this patient yet."); };
  if(can) g$("ap-start").onclick=()=>tStart(a); if(live){ g$("ap-doc").onclick=()=>tDocForAppt(a); g$("ap-done").onclick=()=>tComplete(a); }
}

/* ---- Clinical document editor (SOAP notes & assessments) ---- */
function tDoc(kind,d){
  const cfg=DOCS[kind], fin=d.status==="final", p=patientById(d.pid), plan=planOf(d.pid), keys=(plan?plan.goals:[]).filter(x=>x.key!=="pain"), dis=fin?"disabled":"";
  const prev=C()[cfg.coll].filter(x=>x.pid===d.pid&&x.status==="final"&&x.id!==d.id).sort((a,b)=>a.date<b.date?1:-1)[0];
  const b=tPanel(`${cfg.title} — ${esc(p.first)} ${esc(p.last)}`,"xwide");
  const fld=cfg.fields.map(([k,l,ph])=>`<div class="field"><label>${l}</label><textarea class="input" id="df-${k}" rows="${kind==="note"?4:3}" placeholder="${esc(ph||"")}" ${dis}>${esc(d[k]||"")}</textarea></div>`).join("");
  b.innerHTML=`<div class="doc-grid"><div><div style="display:flex;gap:10px;align-items:center;margin-bottom:14px;flex-wrap:wrap">${dchip(d.status)}<span class="mono">${p.id} · ${fmtDMY(d.date)}</span>
  ${kind==="assess"?`<select class="input" id="df-type" style="max-width:270px" ${dis}>${ATYPES.map(t=>`<option ${t===d.type?"selected":""}>${t}</option>`).join("")}</select>`:""}<span class="hint" id="df-saved"></span></div>${fld}
  <div class="row-3"><div class="field"><label>Pain score (0–10)</label><input class="input" type="number" min="0" max="10" id="df-pain" value="${d.m.pain??""}" ${dis}></div>
  <div class="field"><label>Goal measurement</label><select class="input" id="df-key" ${dis}><option value="">None</option>${keys.map(x=>`<option value="${x.key}" ${d.mk===x.key?"selected":""}>${esc(x.label)} (${esc(x.unit)})</option>`).join("")}</select></div>
  <div class="field"><label>Value</label><input class="input" type="number" id="df-val" value="${d.mk?d.m[d.mk]??"":""}" ${dis}></div></div>
  ${fin?`<div class="hint" style="margin:4px 0 14px">Finalized by ${MYNAME} on ${stampStr(d.finalizedAt)}. The original entry cannot be edited — record an amendment instead.</div>${d.amendments.map(a=>`<div class="kv" style="margin-bottom:8px"><div class="k">Amendment · ${stampStr(a.at)} · ${esc(a.by)}</div><div class="v">${esc(a.text)}</div></div>`).join("")}<div class="field"><label>Add amendment</label><textarea class="input" id="df-amend"></textarea></div><button class="btn btn-sm" id="df-amendbtn">Record amendment</button>`
  :`<div style="display:flex;gap:10px;margin-top:6px"><button class="btn" id="df-save">Save draft</button><button class="btn btn-primary" id="df-final">Finalize ${cfg.title.toLowerCase()}</button></div>`}</div>
  <div>${prev?`<div class="doc-prev"><b style="margin-top:0">Previous ${cfg.title.toLowerCase()} · ${fmtDMY(prev.date)}</b>${cfg.fields.map(([k,l])=>prev[k]?`<b>${l}</b>${esc(prev[k])}`:"").join("")}${prev.m.pain!=null?`<b>Pain</b>${prev.m.pain}/10`:""}</div>`:`<div class="doc-prev">No previous finalized ${cfg.title.toLowerCase()} for this patient.</div>`}</div></div>`;
  const collect=()=>{ cfg.fields.forEach(([k])=>d[k]=g$("df-"+k).value); if(kind==="assess") d.type=g$("df-type").value;
    d.m={}; const pn=g$("df-pain").value,k=g$("df-key").value,v=g$("df-val").value; if(pn!=="") d.m.pain=Math.max(0,Math.min(10,+pn)); d.mk=k||null; if(k&&v!=="") d.m[k]=+v; };
  const persist=()=>{ const a=C()[cfg.coll]; if(!a.includes(d)) a.push(d); saveState(); const s=g$("df-saved"); if(s) s.textContent="Draft saved "+nowTimeStr(); };
  if(fin){ g$("df-amendbtn").onclick=()=>{ const t=g$("df-amend").value.trim(); if(!t){ toast("Enter the amendment text first"); return; }
    d.amendments.push({at:new Date().toISOString(),by:MYNAME,text:t}); C().audit.push({at:new Date().toISOString(),by:ME,act:"Amended "+cfg.title,ref:d.id}); saveState(); tDoc(kind,d); toast("Amendment recorded — original entry preserved"); }; return; }
  let tm; b.addEventListener("input",()=>{ clearTimeout(tm); tm=setTimeout(()=>{ collect(); persist(); },600); });
  g$("df-save").onclick=()=>{ collect(); persist(); toast("Draft saved"); };
  g$("df-final").onclick=()=>{ collect(); const miss=cfg.req.filter(k=>!(d[k]||"").trim()); if(miss.length){ toast("Complete the required sections before finalizing: "+miss.join(", ")); return; }
    d.status="final"; d.finalizedAt=new Date().toISOString(); persist(); C().audit.push({at:d.finalizedAt,by:ME,act:"Finalized "+cfg.title,ref:d.id}); closePanel(); refreshCurrentView(); toast(cfg.title+" finalized"); };
}

/* ---- Patients ---- */
function pStatus(p){ if(!C().assessments.some(a=>a.pid===p.id&&a.status==="final")) return "Awaiting Assessment"; return (C().plans.some(x=>x.pid===p.id&&x.status==="Active")||nextAppt(p.id))?"Active":"Inactive"; }
function tPatients(){
  const h=tEnsureView("patients"), st=state.ui; st.tpf=st.tpf||"all"; st.tpq=st.tpq||"";
  h.innerHTML=tHead("Patients",myPts().length+" assigned to you")+`<div class="panel"><div class="dir-toolbar"><input class="input" id="tp-q" placeholder="Search name, ID, phone, referral reason…" value="${esc(st.tpq)}"><select class="input" id="tp-f" style="max-width:230px">${[["all","All patients"],["active","Active"],["new","New (14 days)"],["awaiting","Awaiting assessment"],["plans","Active treatment plans"],["review","Due for review"]].map(([k,l])=>`<option value="${k}" ${st.tpf===k?"selected":""}>${l}</option>`).join("")}</select><span class="dir-count" id="tp-c"></span></div><div id="tp-body"></div></div>`;
  const draw=()=>{ const q=st.tpq.trim().toLowerCase(), rv=dueReviews().map(x=>x.pid);
    const list=myPts().filter(p=>(!q||(p.first+" "+p.last).toLowerCase().includes(q)||p.id.toLowerCase().includes(q)||p.phone.includes(q)||(p.reason||"").toLowerCase().includes(q))&&({all:1,active:pStatus(p)==="Active",new:p.createdAt>=addDays(todayISO(),-14),awaiting:pStatus(p)==="Awaiting Assessment",plans:C().plans.some(x=>x.pid===p.id&&x.status==="Active"),review:rv.includes(p.id)}[st.tpf])).sort((a,b)=>(a.last+a.first).localeCompare(b.last+b.first));
    g$("tp-c").textContent=list.length+" of "+myPts().length;
    tList(g$("tp-body"),["Patient","ID","Phone","Referral reason","Last visit","Next appointment","Treatment plan","Status"],list.map(p=>{ const nx=nextAppt(p.id), lv=lastAppt(p.id), pl=planOf(p.id), s=pStatus(p);
      return [[`<div class="dir-name"><div class="avatar">${esc(p.first[0]+p.last[0])}</div><div><div style="font-weight:600">${esc(p.last)}, ${esc(p.first)}</div><div class="sub">${esc(p.gender)} · ${ageFromDob(p.dob)}</div></div></div>`,`<span class="mono">${p.id}</span>`,esc(p.phone),esc(p.reason||"—"),lv?fmtDMY(lv.date):"—",nx?fmtDMY(nx.date)+" · "+fmtTime(nx.start):"None",pl?pchip(pl.status):"—",`<span class="chip chip-${s==="Active"?"checkedin":s==="Inactive"?"completed":"noshow"}">${s}</span>`],()=>tPatientPanel(p.id,"overview")]; }),"No patients match these filters."); };
  g$("tp-q").oninput=e=>{ st.tpq=e.target.value; draw(); }; g$("tp-f").onchange=e=>{ st.tpf=e.target.value; draw(); }; draw();
}
function tPatientPanel(pid,tab){
  state.ui.tpTab=tab||state.ui.tpTab||"overview"; const p=patientById(pid), t=state.ui.tpTab, b=tPanel("Patient clinical record");
  b.innerHTML=`<div class="p-detail-head"><div><h2>${esc(p.first)} ${esc(p.last)}</h2><div class="pid2">${p.id} · ${esc(p.gender)} · ${ageFromDob(p.dob)} · <i>fictional demo record</i></div><div style="margin-top:10px">${alerts(p)}</div></div></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;padding:12px 24px;border-bottom:1px solid var(--line)"><button class="btn btn-sm" data-a="assess">Start Assessment</button><button class="btn btn-sm" data-a="note">New SOAP Note</button><button class="btn btn-sm" data-a="plan">Create Plan</button><button class="btn btn-sm" data-a="report">Progress Report</button></div>
  <div class="tabs" style="overflow-x:auto">${[["overview","Overview"],["history","History"],["appointments","Appointments"],["treatment","Treatment"],["progress","Progress"],["documents","Documents"]].map(([k,l])=>`<div class="tab ${t===k?"active":""}" data-tab="${k}">${l}</div>`).join("")}</div><div class="tab-panel" id="tp"></div>`;
  b.querySelectorAll(".tab").forEach(x=>x.onclick=()=>tPatientPanel(pid,x.dataset.tab));
  b.querySelectorAll("[data-a]").forEach(x=>x.onclick=()=>({assess:()=>tDoc("assess",newDoc("assess",pid)),note:()=>tDoc("note",newDoc("note",pid)),plan:()=>tPlanForm(pid),report:()=>tReportForm(pid)}[x.dataset.a])());
  const P=g$("tp"), kv=(k,v)=>`<div class="kv"><div class="k">${k}</div><div class="v">${v||"—"}</div></div>`;
  if(t==="overview"){ const as=C().assessments.filter(x=>x.pid===pid&&x.status==="final").sort((a,c)=>a.date<c.date?1:-1)[0];
    P.innerHTML=`<div class="kv-grid">${kv("Date of birth",fmtDMY(p.dob))}${kv("Phone",esc(p.phone))}${kv("Email",esc(p.email))}${kv("Emergency contact",esc(p.emergency))}${kv("Referral source",esc(p.referral)+(p.referringDoctor?" · "+esc(p.referringDoctor):""))}${kv("Assigned physiotherapist",esc(therapistName(p.therapist)))}${kv("Allergies",esc(p.allergies))}${kv("Current medication",esc(p.medication))}</div>
    <h3 class="section-title">Clinical summary</h3><div class="kv-grid">${kv("Primary complaint",esc(p.complaint))}${kv("Presenting condition",esc(p.reason))}${kv("Relevant medical history",esc(p.conditions))}${kv("Mechanism / onset",as?esc(as.onset):"Pending assessment")}${kv("Clinical impression",as?esc(as.impression):"Pending assessment")}${kv("Functional goals",as?esc(as.goals):"Pending assessment")}</div>`; }
  else if(t==="history"){ const ev=[]; C().assessments.filter(x=>x.pid===pid).forEach(x=>ev.push([x.date,"Assessment — "+(x.type||""),dchip(x.status),()=>tDoc("assess",x)]));
    C().notes.filter(x=>x.pid===pid).forEach(x=>ev.push([x.date,"SOAP note",dchip(x.status),()=>tDoc("note",x)])); C().plans.filter(x=>x.pid===pid).forEach(x=>ev.push([x.created,"Treatment plan — "+x.condition,pchip(x.status),()=>tPlanPanel(x.id)]));
    C().reports.filter(x=>x.pid===pid).forEach(x=>ev.push([x.date,"Progress report",dchip(x.status),()=>tReportPanel(x)])); ev.sort((a,c)=>a[0]<c[0]?1:-1);
    P.innerHTML=ev.length?ev.map((e,i)=>`<div class="tl-row" data-i="${i}"><div class="d">${fmtDMY(e[0])}</div><div style="flex:1"><b>${esc(e[1])}</b></div><div>${e[2]}</div></div>`).join(""):'<div class="empty-note" style="padding-left:0">No clinical history recorded yet.</div>';
    P.querySelectorAll(".tl-row").forEach(r=>r.onclick=ev[r.dataset.i][3]); }
  else if(t==="appointments"){ const a=state.appointments.filter(x=>x.patientId===pid).sort((x,y)=>x.date+x.start<y.date+y.start?1:-1);
    P.innerHTML=a.length?`<table class="dtable"><tbody>${a.map(x=>`<tr class="clickable" data-id="${x.id}"><td>${fmtDMY(x.date)}</td><td>${fmtTime(x.start)}</td><td>${esc(typeName(x.type))}</td><td><span class="chip chip-${statusClass(x.status)}">${statusLabel(x.status)}</span></td></tr>`).join("")}</tbody></table>`:'<div class="empty-note" style="padding-left:0">No appointments.</div>';
    P.querySelectorAll("[data-id]").forEach(r=>r.onclick=()=>tApptPanel(r.dataset.id)); }
  else if(t==="treatment"){ const pl=C().plans.filter(x=>x.pid===pid);
    P.innerHTML=pl.length?pl.map(x=>`<div class="alert-card" data-id="${x.id}" style="cursor:pointer"><div><div class="an">${esc(x.condition)}</div><div class="ad">${x.freq} · review ${fmtDMY(x.review)}</div></div>${pchip(x.status)}</div>`).join(""):'<div class="empty-note" style="padding-left:0">No treatment plan yet. Create one after the assessment.</div>';
    P.querySelectorAll("[data-id]").forEach(r=>r.onclick=()=>tPlanPanel(r.dataset.id)); }
  else if(t==="progress"){ P.innerHTML=planOf(pid)||series(pid,"pain").length?charts(pid):'<div class="empty-note" style="padding-left:0">No measurements recorded yet.</div>'; }
  else { const d=C().assessments.filter(x=>x.pid===pid&&x.status==="final").map(x=>[x.date,"Assessment — "+x.type,()=>tDoc("assess",x)]).concat(C().reports.filter(x=>x.pid===pid&&x.status==="final").map(x=>[x.date,"Progress report",()=>tReportPanel(x)]));
    P.innerHTML=(d.length?d.map((x,i)=>`<div class="tl-row" data-i="${i}"><div class="d">${fmtDMY(x[0])}</div><div>${esc(x[1])}</div></div>`).join(""):'<div class="empty-note" style="padding-left:0">No finalized clinical documents yet.</div>')+'<div class="locked-row">🔒 Documents shown are limited to those you are permitted to access.</div>';
    P.querySelectorAll(".tl-row").forEach(r=>r.onclick=d[r.dataset.i][2]); }
}

/* ---- Assessments & SOAP lists ---- */
function tDocList(view,kind,title,sub,newLabel,stripFn){
  const h=tEnsureView(view), cfg=DOCS[kind], st=state.ui, key="tf_"+view; st[key]=st[key]||"all"; const docs=C()[cfg.coll];
  h.innerHTML=tHead(title,sub,`<button class="btn btn-primary" id="t-new">+ ${newLabel}</button>`)+strip(stripFn(docs))+`<div class="panel"><div class="dir-toolbar"><select class="input" id="t-f" style="max-width:220px">${[["all","All"],["due","Due"],["draft","Drafts"],["final","Completed"]].map(([k,l])=>`<option value="${k}" ${st[key]===k?"selected":""}>${l}</option>`).join("")}</select></div><div id="t-body"></div></div>`;
  const dueA=state.appointments.filter(a=>a.therapist===ME&&kindFor(a)===kind&&a.date<=todayISO()&&["completed","insession"].includes(a.status)&&!hasFinal(a));
  const f=st[key], rows=[]; if(f==="all"||f==="due") dueA.forEach(a=>rows.push([[fmtDMY(a.date),esc(patientName(a.patientId)),esc(typeName(a.type)),'<span class="chip chip-noshow">Due</span>'],()=>tDocForAppt(a)]));
  docs.filter(d=>f==="all"||f===d.status).slice().sort((a,b)=>a.date<b.date?1:-1).forEach(d=>rows.push([[fmtDMY(d.date),esc(patientName(d.pid)),esc(d.type||"Session note")+(d.amendments.length?" · amended":""),dchip(d.status)],()=>tDoc(kind,d)]));
  tList(g$("t-body"),["Date","Patient","Type","Status"],rows,"Nothing to show for this filter.");
  g$("t-f").onchange=e=>{ st[key]=e.target.value; tRender(view); }; g$("t-new").onclick=()=>tQuick(kind==="note"?"note":"assess");
}
const tSoap=()=>tDocList("soap","note","SOAP Notes","Structured session documentation","New SOAP Note",d=>[[pendingNotes().filter(a=>kindFor(a)==="note").length,"Notes Due"],[d.filter(x=>x.status==="draft").length,"Draft Notes"],[d.filter(x=>x.status==="final").length,"Completed Notes"],[d.filter(x=>x.amendments.length).length,"Amended Notes"]]);
const tAssess=()=>tDocList("assessments","assess","Assessments","Initial assessments, reassessments and discharge","New Assessment",d=>[[state.appointments.filter(a=>a.therapist===ME&&kindFor(a)==="assess"&&a.date>=todayISO()&&["confirmed","checkedin"].includes(a.status)).length,"Scheduled"],[d.filter(x=>x.status==="draft").length,"In Progress"],[d.filter(x=>x.status==="final").length,"Completed"],[pendingNotes().filter(a=>kindFor(a)==="assess").length,"Awaiting Documentation"]]);

/* ---- Treatment plans ---- */
function tPlans(){
  const h=tEnsureView("plans"), pl=C().plans, near=p=>{ const g=p.goals.map(x=>goalProg(p.pid,x)).filter(Boolean); return p.status==="Active"&&g.length&&g.every(x=>x.pct>=80); };
  h.innerHTML=tHead("Treatment Plans","Goal-based rehabilitation roadmaps",`<button class="btn btn-primary" id="t-new">+ Create Treatment Plan</button>`)+strip([[pl.filter(p=>p.status==="Active").length,"Active"],[dueReviews().length,"Awaiting Review"],[pl.filter(near).length,"Near Completion"],[pl.filter(p=>p.status==="Completed").length,"Completed"],[pl.filter(p=>p.status==="Discontinued").length,"Discontinued"]])+`<div class="panel"><div id="t-body"></div></div>`;
  tList(g$("t-body"),["Patient","Condition","Status","Frequency","Review date","Goal progress"],pl.map(p=>{ const g=p.goals.map(x=>goalProg(p.pid,x)).filter(Boolean), avg=g.length?Math.round(g.reduce((s,x)=>s+x.pct,0)/g.length)+"%":"No data";
    return [[esc(patientName(p.pid)),esc(p.condition),pchip(p.status),esc(p.freq),fmtDMY(p.review),avg],()=>tPlanPanel(p.id)]; }),"No treatment plans yet."); g$("t-new").onclick=()=>tQuick("plan");
}
function tPlanPanel(id){
  const pl=C().plans.find(x=>x.id===id), b=tPanel("Treatment plan");
  const goals=pl.goals.map(x=>{ const r=goalProg(pl.pid,x); return `<div style="margin-bottom:16px"><div style="font-weight:600">${esc(x.label)}</div><div class="hint">Baseline ${x.baseline}${esc(x.unit)} → target ${x.target}${esc(x.unit)} by ${fmtDMY(x.date)}</div>${r?`<div class="bar"><i style="width:${r.pct}%"></i></div><div style="font-size:12.5px">Latest ${r.latest}${esc(x.unit)} · ${r.good?"improved by":"changed by"} ${r.change}${esc(x.unit)} from baseline · ${r.pct}% of target achieved</div>`:'<div class="hint">No measurements recorded yet.</div>'}</div>`; }).join("");
  b.innerHTML=`<div style="padding:20px 24px"><h2 style="font-size:18px;margin-bottom:4px">${esc(pl.condition)}</h2><div class="hint" style="margin-bottom:16px">${esc(patientName(pl.pid))} · created ${fmtDMY(pl.created)} · ${esc(MYNAME)}</div>
  <div class="kv-grid" style="margin-bottom:8px"><div class="kv"><div class="k">Status</div><div class="v"><select class="input" id="pl-st">${["Draft","Active","Under Review","Completed","Discontinued"].map(s=>`<option ${s===pl.status?"selected":""}>${s}</option>`).join("")}</select></div></div><div class="kv"><div class="k">Frequency · duration</div><div class="v">${esc(pl.freq)} · ${esc(pl.duration||"—")}</div></div><div class="kv"><div class="k">Review date</div><div class="v">${fmtDMY(pl.review)}</div></div></div>
  <h3 class="section-title">Rehabilitation goals</h3>${goals}
  <div class="row-3 no-print" style="align-items:end"><div class="field"><label>Record measurement</label><select class="input" id="ms-k">${pl.goals.map(x=>`<option value="${x.key}">${esc(x.label)} (${esc(x.unit)})</option>`).join("")}</select></div><div class="field"><label>Value</label><input class="input" type="number" id="ms-v"></div><div class="field"><button class="btn btn-primary" id="ms-add">Add</button></div></div>
  <h3 class="section-title">Interventions</h3>${pl.interventions.map(i=>`<div class="kv" style="margin-bottom:8px"><div class="v">${esc(i.name)}</div><div class="hint">${esc(i.purpose||"")} · ${esc(i.freq||"")}</div></div>`).join("")||'<div class="hint">None recorded.</div>'}
  <h3 class="section-title">Home exercise programme</h3>${pl.hep.map(x=>`<div class="kv" style="margin-bottom:8px"><div class="v">${esc(x)}</div></div>`).join("")||'<div class="hint">None prescribed.</div>'}
  <h3 class="section-title">Revision history</h3>${pl.revisions.map(r=>`<div class="hint">${stampStr(r.at)} · ${esc(r.by)} — ${esc(r.text)}</div>`).join("")}</div>`;
  g$("pl-st").onchange=e=>{ pl.revisions.push({at:new Date().toISOString(),by:MYNAME,text:`Status changed from ${pl.status} to ${e.target.value}`}); pl.status=e.target.value; saveState(); refreshCurrentView(); tPlanPanel(id); toast("Plan status updated"); };
  g$("ms-add").onclick=()=>{ const v=g$("ms-v").value; if(v===""){ toast("Enter a measurement value"); return; } C().measures.push({pid:pl.pid,date:todayISO(),key:g$("ms-k").value,value:+v}); saveState(); tPlanPanel(id); toast("Measurement recorded"); };
}
function tPlanForm(pid){
  const p=patientById(pid), gf=n=>`<div class="row-3"><div class="field"><label>Goal ${n} (measurable)</label><input class="input" id="g${n}-l" placeholder="e.g. Knee flexion"></div><div class="field"><label>Unit</label><input class="input" id="g${n}-u" placeholder="°, /10"></div><div class="field"><label>Target date</label><input class="input" type="date" id="g${n}-d" value="${addDays(todayISO(),42)}"></div></div><div class="row-2"><div class="field"><label>Baseline</label><input class="input" type="number" id="g${n}-b"></div><div class="field"><label>Target</label><input class="input" type="number" id="g${n}-t"></div></div>`;
  const m=modalTemplate("Create Treatment Plan",`<div class="hint" style="margin-bottom:12px">${esc(p.first)} ${esc(p.last)} · ${p.id}</div><div class="field"><label>Primary condition</label><input class="input" id="pf-c" value="${esc(p.reason||"")}"></div><div class="row-3"><div class="field"><label>Frequency</label><input class="input" id="pf-f" value="2× per week"></div><div class="field"><label>Duration</label><input class="input" id="pf-d" value="6 weeks"></div><div class="field"><label>Review date</label><input class="input" type="date" id="pf-r" value="${addDays(todayISO(),14)}"></div></div>${gf(1)}${gf(2)}<div class="field"><label>Interventions (one per line: name — purpose)</label><textarea class="input" id="pf-i"></textarea></div><div class="field"><label>Home exercise programme (one per line)</label><textarea class="input" id="pf-h"></textarea></div>`,
  [{label:"Cancel",cls:"btn-ghost",action:closeModal},{label:"Create Plan",cls:"btn-primary",action:()=>{
    const goals=[1,2].map(n=>({n,l:val(`g${n}-l`).trim(),u:val(`g${n}-u`),b:val(`g${n}-b`),t:val(`g${n}-t`),d:val(`g${n}-d`)})).filter(x=>x.l);
    if(!val("pf-c").trim()||!goals.length||goals.some(x=>x.b===""||x.t==="")){ toast("Add a condition and at least one goal with baseline and target values"); return; }
    const plan={id:uid("TP"),pid,status:"Active",created:todayISO(),review:val("pf-r"),condition:val("pf-c"),freq:val("pf-f"),duration:val("pf-d"),
      goals:goals.map(x=>({id:uid("g"),key:/pain/i.test(x.l)?"pain":x.l.toLowerCase().replace(/\W+/g,"_"),label:x.l,unit:x.u,baseline:+x.b,target:+x.t,date:x.d})),
      interventions:val("pf-i").split("\n").filter(Boolean).map(s=>{ const [n,...r]=s.split("—"); return {name:n.trim(),purpose:r.join("—").trim(),freq:""}; }),hep:val("pf-h").split("\n").filter(Boolean),
      revisions:[{at:new Date().toISOString(),by:MYNAME,text:"Plan created"}]};
    plan.goals.forEach(x=>C().measures.push({pid,date:todayISO(),key:x.key,value:x.baseline})); C().plans.push(plan); saveState(); closeModal(); refreshCurrentView(); tPlanPanel(plan.id); toast("Treatment plan created"); }}]); showModal(m);
}

/* ---- Progress reports ---- */
function tReports(){
  const h=tEnsureView("reports"), r=C().reports, recent=addDays(todayISO(),-30);
  h.innerHTML=tHead("Progress Reports","Outcome reports built from recorded clinical data",`<button class="btn btn-primary" id="t-new">+ Generate Progress Report</button>`)+strip([[C().plans.filter(p=>p.status==="Active"&&!r.some(x=>x.pid===p.pid&&x.date>=recent)).length,"Reports Due"],[r.filter(x=>x.status==="draft").length,"Reports Drafted"],[r.filter(x=>x.status==="final").length,"Reports Completed"],[dueReviews().length,"Due for Reassessment"]])+`<div class="panel"><div id="t-body"></div></div>`;
  tList(g$("t-body"),["Date","Patient","Period","Recommendation","Status"],r.slice().sort((a,b)=>a.date<b.date?1:-1).map(x=>[[fmtDMY(x.date),esc(patientName(x.pid)),fmtDMY(x.from)+" – "+fmtDMY(x.to),esc(x.rec),dchip(x.status)],()=>tReportPanel(x)]),"No progress reports yet."); g$("t-new").onclick=()=>tQuick("report");
}
function tReportForm(pid){ const pl=planOf(pid);
  const m=modalTemplate("Generate Progress Report",`<div class="hint" style="margin-bottom:12px">${esc(patientName(pid))} · ${pid}</div><div class="row-2"><div class="field"><label>From</label><input class="input" type="date" id="rf-f" value="${pl?pl.created:addDays(todayISO(),-30)}"></div><div class="field"><label>To</label><input class="input" type="date" id="rf-t" value="${todayISO()}"></div></div>`,
  [{label:"Cancel",cls:"btn-ghost",action:closeModal},{label:"Generate",cls:"btn-primary",action:()=>{ const f=val("rf-f"),t=val("rf-t"); if(!f||!t||f>t){ toast("Choose a valid reporting period"); return; }
    const r={id:uid("R"),pid,from:f,to:t,status:"draft",author:ME,date:todayISO(),summary:"",remaining:"",barriers:"",rec:"Continue current treatment"}; C().reports.push(r); saveState(); closeModal(); refreshCurrentView(); tReportPanel(r); }}]); showModal(m); }
function tReportBody(r){
  const p=patientById(r.pid), pl=planOf(r.pid), as=C().assessments.filter(x=>x.pid===r.pid&&x.status==="final").sort((a,b)=>a.date<b.date?-1:1)[0], notes=C().notes.filter(n=>n.pid===r.pid&&n.status==="final"&&n.date>=r.from&&n.date<=r.to);
  const gr=pl?pl.goals.map(x=>{ const q=goalProg(r.pid,x); return `<tr><td>${esc(x.label)}</td><td>${x.baseline}${esc(x.unit)}</td><td>${q?q.latest+esc(x.unit):"—"}</td><td>${q?q.change+esc(x.unit)+(q.good?" improvement":" change"):"—"}</td><td>${x.target}${esc(x.unit)}</td><td>${q?q.pct+"%":"—"}</td></tr>`; }).join(""):"";
  return `<h3 class="section-title" style="margin-top:0">A. Patient details</h3><div class="kv-grid"><div class="kv"><div class="k">Patient</div><div class="v">${esc(p.first)} ${esc(p.last)} · ${p.id}</div></div><div class="kv"><div class="k">Date of birth</div><div class="v">${fmtDMY(p.dob)}</div></div><div class="kv"><div class="k">Reporting physiotherapist</div><div class="v">${MYNAME}</div></div><div class="kv"><div class="k">Reporting period</div><div class="v">${fmtDMY(r.from)} – ${fmtDMY(r.to)}</div></div><div class="kv"><div class="k">Primary condition</div><div class="v">${esc(pl?pl.condition:p.reason)}</div></div></div>
  <h3 class="section-title">B. Initial presentation</h3><p style="font-size:13px">${as?esc(as.complaint)+(as.rom?" · ROM: "+esc(as.rom):""):"No finalized initial assessment recorded."}</p>
  <h3 class="section-title">C. Treatment provided</h3><p style="font-size:13px">${notes.length} documented session${notes.length===1?"":"s"} in this period.${pl?" Interventions: "+esc(pl.interventions.map(i=>i.name).join(", ")||"none recorded")+". Home exercise programme: "+esc(pl.hep.join("; ")||"none")+".":""}</p>
  <h3 class="section-title">D–E. Clinical and goal progress</h3>${gr?`<div class="scrollx"><table class="dtable"><thead><tr><th>Goal</th><th>Baseline</th><th>Latest</th><th>Change</th><th>Target</th><th>% of target</th></tr></thead><tbody>${gr}</tbody></table></div>`:'<p class="hint">No treatment plan goals recorded.</p>'}<div style="margin-top:14px">${charts(r.pid,r.from,r.to)}</div>`; }
function tReportPanel(r){
  const fin=r.status==="final", p=patientById(r.pid), b=tPanel("Progress report — "+esc(p.first)+" "+esc(p.last)), dis=fin?"disabled":"";
  b.innerHTML=`<div style="padding:20px 24px"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px"><div style="font-family:var(--font-display);font-size:18px;font-weight:600">Clinic OS — Physiotherapy Progress Report</div>${dchip(r.status)}</div><div class="hint" style="margin-bottom:14px">Author: ${MYNAME} · Report date ${fmtDMY(r.date)}${fin?" · finalized "+stampStr(r.finalizedAt):""}</div>${r.snap||tReportBody(r)}
  <h3 class="section-title">F. Clinical summary</h3><div class="field"><label>Overall response to treatment</label><textarea class="input" id="rp-s" ${dis}>${esc(r.summary)}</textarea></div><div class="field"><label>Remaining impairments</label><textarea class="input" id="rp-m" ${dis}>${esc(r.remaining)}</textarea></div><div class="field"><label>Barriers to recovery</label><textarea class="input" id="rp-b" ${dis}>${esc(r.barriers)}</textarea></div>
  <h3 class="section-title">G. Recommendation (clinician-selected)</h3><div class="field"><select class="input" id="rp-r" ${dis}>${["Continue current treatment","Modify treatment plan","Reassess","Discharge","Refer for further medical evaluation"].map(x=>`<option ${x===r.rec?"selected":""}>${x}</option>`).join("")}</select></div>
  <div class="no-print" style="display:flex;gap:10px;flex-wrap:wrap">${fin?"":'<button class="btn" id="rp-save">Save draft</button><button class="btn btn-primary" id="rp-fin">Finalize report</button>'}<button class="btn" id="rp-print">Export PDF / Print</button></div></div>`;
  const col=()=>{ r.summary=g$("rp-s").value; r.remaining=g$("rp-m").value; r.barriers=g$("rp-b").value; r.rec=g$("rp-r").value; };
  g$("rp-print").onclick=()=>{ document.body.classList.add("pr"); try{ window.print(); }catch(e){ toast("Printing isn't available here"); } setTimeout(()=>document.body.classList.remove("pr"),800); };
  if(!fin){ g$("rp-save").onclick=()=>{ col(); saveState(); toast("Draft saved"); };
    g$("rp-fin").onclick=()=>{ col(); if(!r.summary.trim()){ toast("Add the overall response to treatment before finalizing"); return; } r.snap=tReportBody(r); r.status="final"; r.finalizedAt=new Date().toISOString(); C().audit.push({at:r.finalizedAt,by:ME,act:"Finalized progress report",ref:r.id}); saveState(); refreshCurrentView(); tReportPanel(r); toast("Report finalized"); }; }
}

/* ---- Profile (all non-reception portals) ---- */
function tProfile(){ const P=PEOPLE[ROLE];
  showPanel(sidePanelTemplate("My profile",`<div style="display:flex;align-items:center;gap:14px;margin-bottom:22px"><div class="avatar" style="width:56px;height:56px;font-size:18px">${P.ini}</div><div><div style="font-family:var(--font-display);font-size:18px;font-weight:600">${P.name}</div><div style="color:var(--ink-faint);font-size:12.5px">${P.role}</div></div></div>
  <div class="kv-grid"><div class="kv"><div class="k">Email</div><div class="v">${P.email}</div></div><div class="kv"><div class="k">Portal</div><div class="v">${P.role} Portal</div></div><div class="kv"><div class="k">Clinic</div><div class="v">Clinic OS Physiotherapy — Borrowdale, Harare</div></div><div class="kv"><div class="k">Working hours</div><div class="v">08:00 – 17:00</div></div></div>
  <h3 class="section-title">Your access</h3><p style="color:var(--ink-soft);font-size:13px">${ACCESS[ROLE]}</p>`,[{label:"Close",cls:"btn-ghost",action:closePanel},{label:"Log out",cls:"btn-danger",action:logOut}])); }

/* ---- Seed clinical demo data (fictional) ---- */
function seedClinical(){
  const D=n=>addDays(todayISO(),n), c=state.clin={assessments:[],notes:[],plans:[],reports:[],measures:[],audit:[]};
  state.patients.push({id:"P-1006",first:"Chipo",last:"Dube",dob:"1958-03-09",gender:"Female",phone:"+263 77 000 0114",email:"chipo.dube@example.com",address:"18 Argyle Rd, Harare",emergency:"Tino Dube · +263 77 000 0115",reason:"Knee osteoarthritis",referral:"Referring Doctor",referringDoctor:"Dr. A. Mlambo",complaint:"Right knee pain on stairs",conditions:"Hypertension",allergies:"None known",medication:"Amlodipine",insurance:"Sample Health Plan A",membership:"CM-4471",commPref:"Phone",consent:"Signed",therapist:ME,createdAt:D(-35)},
    {id:"P-1007",first:"Blessing",last:"Zhou",dob:"1962-08-21",gender:"Male",phone:"+263 77 000 0116",email:"blessing.zhou@example.com",address:"7 Mazowe St, Harare",emergency:"Rutendo Zhou · +263 77 000 0117",reason:"Stroke rehabilitation",referral:"Referring Doctor",referringDoctor:"Dr. P. Chari",complaint:"Left-sided weakness after stroke",conditions:"Atrial fibrillation",allergies:"Aspirin sensitivity",medication:"Warfarin",insurance:"Sample Health Plan B",membership:"FM-9012",commPref:"SMS",consent:"Signed",therapist:ME,createdAt:D(-32)});
  const ap=(pid,type,s,e,st,room)=>state.appointments.push({id:uid("A"),patientId:pid,therapist:ME,type,date:D(0),start:s,end:e,status:st,room,notes:""});
  ap("P-1006","physio","10:00","10:45","checkedin","Room 1"); ap("P-1007","physio","14:00","14:45","confirmed","Room 3");
  const A=(pid,type,day,o)=>c.assessments.push(Object.assign({id:"AS-"+pid,pid,type,date:D(day),status:"final",author:ME,finalizedAt:D(day),amendments:[],m:{}},o));
  A("P-1006","Musculoskeletal Assessment",-30,{complaint:"Right knee pain and stiffness on stairs for 4 months",onset:"Gradual onset, no trauma",aggr:"Stairs, long walks / rest, heat",obs:"Mild effusion, antalgic gait",rom:"Flexion 75°, extension −5°",strength:"Quadriceps 4−/5",special:"Crepitus on active flexion",impression:"Right knee osteoarthritis with quadriceps weakness and reduced flexion",goals:"Short-term: flexion 100° in 4 weeks. Long-term: 120° and pain ≤2/10"});
  A("P-1007","Neurological Assessment",-28,{complaint:"Left-sided weakness 6 weeks post ischaemic stroke",onset:"Stroke 6 weeks ago, discharged from hospital",aggr:"Fatigue, uneven ground",obs:"Reduced weight-bearing on left, slow gait",rom:"Left shoulder and ankle limited by tone",strength:"Left lower limb 3/5",special:"Berg Balance Score 32/56",impression:"Left hemiparesis with impaired balance and increased falls risk",goals:"Berg Balance Score ≥45 in 8 weeks; independent household ambulation"});
  A("P-1005","Musculoskeletal Assessment",-52,{complaint:"Chronic neck pain with reduced rotation",onset:"Gradual, desk-based work",aggr:"Prolonged sitting / heat, movement",obs:"Forward head posture",rom:"Cervical rotation 40° bilaterally",strength:"Deep neck flexors weak",special:"Spurling's negative",impression:"Cervical spondylosis with postural contribution",goals:"Rotation 70°, pain ≤2/10"});
  [["P-1006",[-28,-21,-14,-7],"flex",[75,85,92,100],[7,6,5,4],"R knee flexion"],["P-1007",[-26,-19,-12,-5],"bbs",[32,36,40,42],[],"Berg Balance Score"],["P-1005",[-50,-35,-20],"rot",[40,55,68],[6,4,3],"Cervical rotation"]].forEach(([pid,ds,k,vs,ps,lab])=>ds.forEach((dd,i)=>{
    const m={[k]:vs[i]}; if(ps[i]!=null) m.pain=ps[i];
    c.notes.push({id:"N-"+pid+i,pid,apptId:null,date:D(dd),status:"final",author:ME,finalizedAt:D(dd),m,mk:k,amendments:[],S:`Session ${i+1}: reports ${ps[i]!=null?"pain "+ps[i]+"/10 and ":""}steady improvement in daily function.`,O:`${lab} ${vs[i]}. Treatment tolerated well.`,A:i?`Improving since session ${i}; ${lab.toLowerCase()} changed by ${vs[i]-vs[0]} from baseline.`:"Baseline findings recorded; consistent with referral.",P:"Continue strengthening and mobility work; progress home exercises; review next session."}); }));
  const pl=(id,pid,cond,rev,goals,iv,hep)=>c.plans.push({id,pid,status:"Active",created:D(-30),review:D(rev),condition:cond,freq:"2× per week",duration:"8 weeks",goals,interventions:iv.map(([n,p])=>({name:n,purpose:p,freq:"Each session"})),hep,revisions:[{at:D(-30),by:MYNAME,text:"Plan created from initial assessment"}]});
  pl("TP-1","P-1006","Right knee osteoarthritis",5,[{id:"g1",key:"flex",label:"Right knee flexion",unit:"°",baseline:75,target:120,date:D(30)},{id:"g2",key:"pain",label:"Pain on stairs",unit:"/10",baseline:7,target:2,date:D(30)}],[["Quadriceps strengthening","Improve knee stability"],["Manual mobilisation","Increase flexion range"]],["Quad sets — 3×10, daily","Heel slides — 3×15, twice daily"]);
  pl("TP-2","P-1007","Stroke rehabilitation — left hemiparesis",12,[{id:"g1",key:"bbs",label:"Berg Balance Score",unit:"/56",baseline:32,target:45,date:D(28)}],[["Balance training","Reduce falls risk"],["Gait training","Independent household ambulation"]],["Sit-to-stand — 3×8, daily","Supported weight shift — 2×10, daily"]);
  pl("TP-3","P-1005","Cervical spondylosis",3,[{id:"g1",key:"rot",label:"Cervical rotation",unit:"°",baseline:40,target:70,date:D(5)},{id:"g2",key:"pain",label:"Neck pain",unit:"/10",baseline:6,target:2,date:D(5)}],[["Postural re-education","Reduce neck load"],["Mobility exercises","Restore rotation"]],["Chin tucks — 3×10, daily"]);
  c.plans[2].created=D(-52);
  c.reports.push({id:"R-1",pid:"P-1005",from:D(-52),to:D(-20),status:"final",author:ME,date:D(-19),finalizedAt:D(-19),summary:"Good response to treatment with steady gains in rotation and reduced pain.",remaining:"Mild end-range stiffness.",barriers:"Prolonged desk work.",rec:"Continue current treatment"});
}
/* ============================================================
   CLINIC OWNER & IT MANAGER PORTALS (shared administrative tier)
   ============================================================ */
const PEOPLE={reception:{name:"Rudo Chikwanha",ini:"RC",role:"Receptionist",email:"rudo.chikwanha@clinicos.demo"},therapist:{name:MYNAME,ini:"TM",role:"Physiotherapist",email:"tendai.moyo@clinicos.demo"},owner:{name:"Nyasha Chuma",ini:"NC",role:"Clinic Owner",email:"nyasha.chuma@clinicos.demo"},it:{name:"Kuda Mutasa",ini:"KM",role:"IT Manager",email:"kuda.mutasa@clinicos.demo"}};
const ACCESS={reception:"You can register patients, manage appointments and check-ins, and manage inventory.",therapist:"You can document assessments and SOAP notes, manage treatment plans and generate progress reports for your assigned patients.",owner:"Business oversight: clinic overview, purchase approvals, staff accounts and roles, a read-only audit log and the reception desk (calendar, patients, inventory). IT systems, the service desk and clinical documentation are not part of this portal.",it:"Technical administration: service desk, team, assets, system health, user accounts, password resets and a read-only audit log. IT staff cannot open patient records, the reception desk, purchase approvals or clinical documentation."};
const RX=[["rx-calendar","▤","Calendar"],["rx-patients","◍","Patients"],["rx-inventory","▣","Inventory"]];
const VIEWS_FOR={owner:["dashboard","approvals","users","audit","rx-calendar","rx-patients","rx-inventory","settings","help"],it:["dashboard","team","assets","health","users","audit","settings","help"]};
const ADMIN_NAV={owner:[["Main",[["dashboard","▦","Overview"],["approvals","✓","Approvals"]]],["Administration",[["users","◍","Staff & Access"],["audit","≡","Audit Log"]]],["Reception Desk",RX]],
  it:[["Main",[["dashboard","☎","Service Desk"],["team","◈","Team"],["assets","▢","Assets"],["health","♥","System Health"]]],["Administration",[["users","◍","Users & Access"],["audit","≡","Audit Log"]]]]};
const THRESH=()=>state.admin?state.admin.threshold:150;
const CATS=["Account access","Printing","Network","Calendar sync","Hardware","EMR / software","Infrastructure","Email / SMS"];
const SLA={1:20,2:45,3:90,4:180}, PRI={1:["P1 Critical","outstock"],2:["P2 High","expiring"],3:["P3 Medium","lowstock"],4:["P4 Low","completed"]};
const STAFF=["Rudo Chikwanha","Dr. Tendai Moyo","Dr. Natasha Phiri","Dr. Brian Ncube","Nyasha Chuma"], ROLES=["Receptionist","Physiotherapist","Clinic Owner","IT Manager"];
const TPL=[
 {title:"Cannot print intake forms",desc:"The Room 2 printer shows offline and the front desk print queue is blocked.",cat:"Printing",pri:3,fixes:["Restart the print spooler and re-add the printer","Reinstall the operating system","Order replacement toner"]},
 {title:"Therapist locked out of the clinical system",desc:"A physiotherapist's account locked after repeated failed sign-ins before a session.",cat:"Account access",pri:2,fixes:["Unlock the account and force a password reset","Delete the user profile","Restart the database server"]},
 {title:"Wi-Fi drops in the gym",desc:"Tablets lose connection during rehabilitation sessions on the gym floor.",cat:"Network",pri:3,fixes:["Reboot the access point and update its firmware","Replace every tablet","Clear the browser cache"]},
 {title:"Calendar not syncing to tablets",desc:"New bookings made at reception are not appearing on therapist tablets.",cat:"Calendar sync",pri:2,fixes:["Re-authenticate the sync service and refresh tokens","Reformat the tablets","Add paper to the printer"]},
 {title:"Reception PC very slow at check-in",desc:"Patient check-in takes over a minute and the queue is building.",cat:"Hardware",pri:3,fixes:["Run disk clean-up, trim startup apps and check disk health","Reset the clinic router","Change the patient's password"]},
 {title:"Barcode scanner not recognised",desc:"The inventory barcode scanner is not detected by the store room PC.",cat:"Hardware",pri:4,fixes:["Reseat the cable, reinstall the driver and test another port","Delete the inventory database","Restart the access point"]},
 {title:"SOAP note autosave failing",desc:"A therapist sees 'draft not saved' errors while documenting a session. Patient records are at risk.",cat:"EMR / software",pri:1,fixes:["Clear the failed sync queue and restore the service connection","Disable audit logging","Replace the keyboard"]},
 {title:"Overnight backup failed",desc:"The nightly backup job reported an error and no restore point exists for today.",cat:"Infrastructure",pri:1,fixes:["Free storage, check credentials and re-run the backup","Delete the audit log","Restart the reception PC"]},
 {title:"New physiotherapist needs an account",desc:"A locum joins Monday and needs access to the schedule and clinical notes only.",cat:"Account access",pri:4,fixes:["Create the account with the Physiotherapist role and enable MFA","Share the owner's login","Grant full admin rights"]},
 {title:"Appointment reminders bouncing",desc:"Patients report no SMS or email reminders and the gateway shows delivery errors.",cat:"Email / SMS",pri:3,fixes:["Fix the sender records and retest the gateway","Restart the printer","Ask patients to change phone numbers"]}];
function detectRole(em){ return /tendai|physio|therapist/.test(em)?"therapist":/nyasha|owner/.test(em)?"owner":/kuda|it\.|manager/.test(em)?"it":/rudo|reception/.test(em)?"reception":ROLE; }
const adm=()=>state.admin, agent=id=>adm().agents.find(a=>a.id===id), simClock=m=>minToTime(m%1440), remMin=t=>t.sla-(adm().sim.min-t.created);
function aLog(act,ref,src){ adm().audit.unshift({at:new Date().toISOString(),by:PEOPLE[ROLE].name,act,ref:ref||"",src:src||"Admin"}); }
const tbl=(head,rows)=>`<div class="scrollx"><table class="dtable"><thead><tr>${head.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`;
const tkChip=s=>`<span class="chip chip-${{New:"submitted","In Progress":"insession",Escalated:"noshow",Resolved:"approved"}[s]}">${s}</span>`;
const sChip=s=>`<span class="chip chip-${{Operational:"approved",Degraded:"lowstock",Down:"outstock",Active:"approved",Suspended:"cancelled",OK:"approved",Faulty:"outstock",Offline:"lowstock"}[s]||"draft"}">${s}</span>`;

/* ---- seed ---- */
function seedAdmin(){
  const D=n=>addDays(todayISO(),n);
  state.admin={threshold:150,next:1001,sim:{min:540,running:true,speed:1},audit:[],tickets:[],
   users:[["Rudo Chikwanha","Receptionist"],["Dr. Tendai Moyo","Physiotherapist"],["Dr. Natasha Phiri","Physiotherapist"],["Dr. Brian Ncube","Physiotherapist"],["Nyasha Chuma","Clinic Owner"],["Kuda Mutasa","IT Manager"]].map(([n,r],i)=>({id:"U"+(i+1),name:n,role:r,email:n.toLowerCase().replace(/dr\. /,"").replace(/ /g,".")+"@clinicos.demo",status:"Active",mfa:i>3||i===1,last:D(-(i%3))})),
   agents:[{id:"ag1",name:"Chiedza Mapfumo",level:"Tier 1",skills:["Account access","EMR / software","Email / SMS"],done:0},{id:"ag2",name:"Tapiwa Nyoni",level:"Tier 2",skills:["Network","Infrastructure","Calendar sync"],done:0},{id:"ag3",name:"Ropafadzo Dube",level:"Tier 1",skills:["Hardware","Printing"],done:0}],
   assets:[["PC-01","Reception desk PC","Front desk","OK"],["PR-02","Room 2 printer","Room 2","Faulty"],["RT-01","Clinic router","Server cupboard","OK"],["AP-02","Gym access point","Gym floor","Faulty"],["TB-03","Therapist tablet","Room 1","OK"],["NAS-01","Backup storage","Server cupboard","OK"],["LP-04","Dr. Natasha's laptop","Room 1","OK"],["SC-01","Barcode scanner","Store room","Offline"]].map(([id,n,l,s],i)=>({id,name:n,loc:l,status:s,type:/printer/i.test(n)?"Printing":/router|access|backup/i.test(n)?"Network":"Hardware",serviced:D(-20-i*9)})),
   services:[["Database (PostgreSQL)","Operational","99.98%"],["Authentication","Operational","99.99%"],["Document storage","Operational","99.95%"],["Nightly backups","Operational","Last run "+D(0)+" 02:00"],["Email & SMS gateway","Degraded","97.4%"],["Row-level security policies","Operational","Enforced"]].map(([n,s,u],i)=>({id:"S"+i,name:n,status:s,info:u}))};
  for(let i=0;i<5;i++) spawnTicket(true);
}
function spawnTicket(back,c){ const a=adm(), t=c||TPL[Math.floor(Math.random()*TPL.length)], fx=(c&&c.fixesReady)||t.fixes.map((x,i)=>({t:x,ok:i===0})).sort(()=>Math.random()-.5);
  a.tickets.unshift({id:"TK-"+a.next++,title:t.title,desc:t.desc,cat:t.cat,pri:t.pri,req:(c&&c.req)||STAFF[Math.floor(Math.random()*STAFF.length)],created:a.sim.min-(back?2+Math.floor(Math.random()*12):0),sla:SLA[t.pri],status:"New",assignee:null,work:0,fixes:fx,reopens:0,wrongs:0,breached:false,log:[]}); return a.tickets[0]; }
function closeTicket(t,by,pen){ const a=adm(); t.status="Resolved"; t.resolvedAt=a.sim.min; t.by=by; if(a.sim.min-t.created>t.sla) t.breached=true;
  t.csat=Math.max(1,5-(t.breached?2:0)-(pen||0)-t.reopens-t.wrongs); t.log.push(simClock(a.sim.min)+" Resolved by "+by); aLog("Resolved "+t.id+" — "+t.title,t.id,"Service desk"); }
function simStep(){ const a=adm(), s=a.sim; s.min++;
  a.tickets.forEach(t=>{ if(t.status==="Resolved") return; if(s.min-t.created>t.sla) t.breached=true;
    if(t.status==="In Progress"){ const ag=agent(t.assignee), m=ag.skills.includes(t.cat); t.work=Math.min(100,t.work+(m?10:5));
      if(t.work>=100){ if(Math.random()<(m?.92:.45)){ ag.done++; closeTicket(t,ag.name); } else { t.log.push(simClock(s.min)+" "+ag.name+"'s fix failed — ticket reopened"); t.status="New"; t.assignee=null; t.work=0; t.reopens++; } } }
    if(t.status==="Escalated"&&s.min>=t.escUntil) closeTicket(t,"Vendor support",1); });
  if(a.tickets.filter(t=>t.status!=="Resolved").length<12&&Math.random()<.11) spawnTicket(); }
setInterval(()=>{ const a=state.admin; if(!a||!isAdmin()||!a.sim.running||g$("app").classList.contains("hidden")) return; for(let i=0;i<a.sim.speed;i++) simStep(); if(a.sim.min%5===0) saveState(); sdDraw(); },1000);

/* ---- Service desk ---- */
function sdDraw(){ if(!g$("sd-queue")) return; const a=adm(), tk=a.tickets, open=tk.filter(t=>t.status!=="Resolved"), res=tk.filter(t=>t.status==="Resolved"), st=state.ui;
  const risk=open.filter(t=>remMin(t)>=0&&remMin(t)<t.sla*.3).length, br=open.filter(t=>remMin(t)<0).length;
  const cs=res.length?(res.reduce((s,t)=>s+t.csat,0)/res.length).toFixed(1)+" / 5":"—", met=res.length?Math.round(res.filter(t=>!t.breached).length/res.length*100)+"%":"—";
  g$("sd-strip").innerHTML=[[open.length,"Open tickets"],[risk,"SLA at risk"],[br,"SLA breached"],[res.length,"Resolved"],[cs,"Customer satisfaction"],[met,"SLA met"]].map(([n,l])=>`<div class="stat"><div class="n">${n}</div><div class="l">${l}</div></div>`).join("");
  g$("sd-clock").textContent="Clinic time "+simClock(a.sim.min); g$("sd-pause").textContent=a.sim.running?"Pause":"Resume"; g$("sd-speed").textContent="Speed "+a.sim.speed+"×";
  const f=st.sdf||"open", list=tk.filter(t=>({open:t.status!=="Resolved",new:t.status==="New",risk:t.status!=="Resolved"&&remMin(t)>=0&&remMin(t)<t.sla*.3,breached:t.status!=="Resolved"&&remMin(t)<0,resolved:t.status==="Resolved"}[f])).sort((x,y)=>x.pri-y.pri||remMin(x)-remMin(y));
  g$("sd-queue").innerHTML=list.length?tbl(["ID","Priority","Ticket","Category","SLA","Assigned","Status"],list.map(t=>{ const r=remMin(t), o=t.status!=="Resolved";
    return `<tr class="dir-row" data-id="${t.id}"><td class="mono">${t.id}</td><td><span class="chip chip-${PRI[t.pri][1]}">${PRI[t.pri][0]}</span></td><td><b>${esc(t.title)}</b><div class="hint">${esc(t.req)}</div></td><td>${esc(t.cat)}</td><td>${!o?"—":r<0?`<span class="wait-flag">Breached ${-r}m</span>`:r<t.sla*.3?`<b style="color:var(--amber)">${r}m</b>`:r+"m"}</td><td>${t.assignee?esc(agent(t.assignee).name)+(t.status==="In Progress"?" · "+t.work+"%":""):"—"}</td><td>${tkChip(t.status)}</td></tr>`; })):`<div class="empty-note">No tickets in this view.</div>`;
  g$("sd-agents").innerHTML=a.agents.map(g=>{ const ld=tk.filter(t=>t.assignee===g.id&&t.status==="In Progress").length; return `<div class="notif-mini"><div class="t">${esc(g.name)} <span class="hint">· ${g.level} · ${ld}/2 busy</span></div><div class="bar"><i style="width:${ld*50}%"></i></div><div class="d">${g.skills.map(esc).join(" · ")}</div></div>`; }).join(""); }
function aServiceDesk(){
  const h=tEnsureView(state.ui.view), a=adm(), st=state.ui; st.sdf=st.sdf||"open";
  h.innerHTML=tHead("Service Desk",'<span id="sd-clock" class="mono"></span> · simulated clinic IT queue',`<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" id="sd-pause"></button><button class="btn" id="sd-speed"></button><button class="btn btn-ghost" id="sd-reset">Reset</button><button class="btn btn-primary" id="sd-new">+ New Ticket</button></div>`)
   +`<div id="sd-strip" class="stat-strip"></div><div class="dash-grid"><div class="panel"><div class="dir-toolbar"><select class="input" id="sd-f" style="max-width:210px">${[["open","Open tickets"],["new","Unassigned"],["risk","SLA at risk"],["breached","SLA breached"],["resolved","Resolved"]].map(([k,l])=>`<option value="${k}" ${st.sdf===k?"selected":""}>${l}</option>`).join("")}</select><span class="dir-count">Assign agents by skill, or fix tickets yourself.</span></div><div id="sd-queue"></div></div><div class="dash-side"><div class="panel"><div class="panel-head"><h3>Agents</h3></div><div class="panel-body" id="sd-agents"></div></div></div></div>`;
  g$("sd-pause").onclick=()=>{ a.sim.running=!a.sim.running; sdDraw(); }; g$("sd-speed").onclick=()=>{ a.sim.speed=a.sim.speed===1?3:1; sdDraw(); };
  g$("sd-reset").onclick=()=>{ a.tickets=[]; a.next=1001; a.sim.min=540; a.agents.forEach(g=>g.done=0); for(let i=0;i<5;i++) spawnTicket(true); saveState(); sdDraw(); toast("Shift restarted"); };
  g$("sd-new").onclick=()=>tkForm(); g$("sd-f").onchange=e=>{ st.sdf=e.target.value; sdDraw(); };
  const q=g$("sd-queue"); q.onmousedown=e=>{ const r=e.target.closest("tr[data-id]"); if(r) tkPanel(r.dataset.id); }; sdDraw();
}
function tkForm(pre){ pre=pre||{};
  showModal(modalTemplate("New IT Ticket",`<div class="field"><label>Summary</label><input class="input" id="tf-t" value="${esc(pre.title||"")}"></div><div class="field"><label>Details</label><textarea class="input" id="tf-d">${esc(pre.desc||"")}</textarea></div><div class="row-3"><div class="field"><label>Category</label><select class="input" id="tf-c">${CATS.map(c=>`<option ${c===pre.cat?"selected":""}>${c}</option>`).join("")}</select></div><div class="field"><label>Priority</label><select class="input" id="tf-p">${[1,2,3,4].map(p=>`<option value="${p}" ${p===(pre.pri||3)?"selected":""}>${PRI[p][0]}</option>`).join("")}</select></div><div class="field"><label>Requested by</label><select class="input" id="tf-r">${STAFF.map(s=>`<option>${s}</option>`).join("")}</select></div></div>`,
  [{label:"Cancel",cls:"btn-ghost",action:closeModal},{label:"Create ticket",cls:"btn-primary",action:()=>{ if(!val("tf-t").trim()){ toast("Add a ticket summary"); return; }
    const cat=val("tf-c"), base=TPL.find(x=>x.cat===cat)||TPL[0], t=spawnTicket(false,{title:val("tf-t"),desc:val("tf-d")||"Reported by staff.",cat,pri:+val("tf-p"),req:val("tf-r"),fixes:base.fixes});
    aLog("Created "+t.id,t.id,"Service desk"); saveState(); closeModal(); if(g$("sd-queue")) sdDraw(); toast("Ticket "+t.id+" created"); }}])); }
function tkPanel(id){
  const a=adm(), t=a.tickets.find(x=>x.id===id); if(!t) return; const open=t.status!=="Resolved", r=remMin(t), b=tPanel("Ticket "+t.id);
  b.innerHTML=`<div style="padding:20px 24px"><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:8px"><span class="chip chip-${PRI[t.pri][1]}">${PRI[t.pri][0]}</span>${tkChip(t.status)}<span class="mono">${esc(t.cat)}</span></div><h2 style="font-size:18px;margin-bottom:6px">${esc(t.title)}</h2>
  <div class="hint" style="margin-bottom:12px">Requested by ${esc(t.req)} · opened ${simClock(t.created)} · ${open?(r<0?"SLA breached "+(-r)+" min ago":r+" min left on SLA"):"resolved by "+esc(t.by)+" · satisfaction "+t.csat+"/5"}</div><p style="font-size:13px;margin-bottom:14px">${esc(t.desc)}</p>
  ${open?`<div class="field"><label>Assign to an agent</label><div style="display:flex;gap:8px"><select class="input" id="tk-ag">${a.agents.map(g=>`<option value="${g.id}">${esc(g.name)} · ${a.tickets.filter(x=>x.assignee===g.id&&x.status==="In Progress").length}/2 · ${g.skills.includes(t.cat)?"skill match":"no skill match"}</option>`).join("")}</select><button class="btn btn-primary" id="tk-assign" ${t.status==="In Progress"?"disabled":""}>Assign</button></div></div>
  <div class="field"><label>Resolve it yourself — choose the correct fix</label>${t.fixes.map((f,i)=>`<label style="display:flex;gap:8px;font-weight:400;padding:4px 0"><input type="radio" name="tk-fix" value="${i}"> ${esc(f.t)}</label>`).join("")}<button class="btn btn-sm" id="tk-fix" style="width:fit-content;margin-top:6px">Apply fix</button></div>
  <button class="btn btn-sm" id="tk-esc" ${t.status==="Escalated"?"disabled":""}>Escalate to vendor</button>`:""}
  <h3 class="section-title">Activity</h3>${t.log.map(l=>`<div class="hint">${esc(l)}</div>`).join("")||'<div class="hint">No activity yet.</div>'}</div>`;
  const done=()=>{ saveState(); sdDraw(); tkPanel(id); };
  if(!open) return;
  g$("tk-assign").onclick=()=>{ const g=agent(val("tk-ag")); if(a.tickets.filter(x=>x.assignee===g.id&&x.status==="In Progress").length>=2){ toast(g.name+" is at capacity"); return; }
    t.assignee=g.id; t.status="In Progress"; t.work=0; t.log.push(simClock(a.sim.min)+" Assigned to "+g.name); aLog("Assigned "+t.id+" to "+g.name,t.id,"Service desk"); done(); toast("Assigned to "+g.name); };
  g$("tk-fix").onclick=()=>{ const c=document.querySelector('input[name="tk-fix"]:checked'); if(!c){ toast("Choose a fix first"); return; }
    if(t.fixes[+c.value].ok){ closeTicket(t,PEOPLE[ROLE].name+" (hands-on)"); toast("Fixed — ticket resolved"); } else { t.wrongs++; t.log.push(simClock(a.sim.min)+" Fix attempted: “"+t.fixes[+c.value].t+"” — did not work"); toast("That fix didn't work and the customer is unhappy."); } done(); };
  g$("tk-esc").onclick=()=>{ t.status="Escalated"; t.assignee=null; t.escUntil=a.sim.min+25; t.log.push(simClock(a.sim.min)+" Escalated to vendor support"); aLog("Escalated "+t.id,t.id,"Service desk"); done(); toast("Escalated — vendor will respond in about 25 minutes"); };
}

/* ---- Team & assets & health ---- */
function aTeam(){ const h=tEnsureView("team"), a=adm();
  h.innerHTML=tHead("Team","Service desk agents, skills and workload")+`<div class="panel" id="tm-body"></div>`;
  g$("tm-body").innerHTML=tbl(["Agent","Level","Skills","Working on","Resolved","Satisfaction",""],a.agents.map(g=>{ const mine=a.tickets.filter(t=>t.by===g.name&&t.status==="Resolved"), cs=mine.length?(mine.reduce((s,t)=>s+t.csat,0)/mine.length).toFixed(1):"—";
    return `<tr><td><b>${esc(g.name)}</b></td><td>${g.level}</td><td>${g.skills.map(esc).join(", ")}</td><td>${a.tickets.filter(t=>t.assignee===g.id&&t.status==="In Progress").length}/2</td><td>${g.done}</td><td>${cs}</td><td><button class="btn btn-sm" data-id="${g.id}">Train</button></td></tr>`; }));
  g$("tm-body").onclick=e=>{ const b=e.target.closest("[data-id]"); if(!b) return; const g=agent(b.dataset.id), opts=CATS.filter(c=>!g.skills.includes(c));
    if(!opts.length){ toast(g.name+" already has every skill"); return; }
    showModal(modalTemplate("Train "+esc(g.name),`<div class="field"><label>New skill</label><select class="input" id="tr-s">${opts.map(c=>`<option>${c}</option>`).join("")}</select></div>`,[{label:"Cancel",cls:"btn-ghost",action:closeModal},{label:"Start training",cls:"btn-primary",action:()=>{ g.skills.push(val("tr-s")); aLog("Trained "+g.name+" in "+g.skills[g.skills.length-1],g.id,"Service desk"); saveState(); closeModal(); aTeam(); toast("Skill added"); }}])); }; }
function aAssets(){ const h=tEnsureView("assets"), a=adm();
  h.innerHTML=tHead("Assets","Clinic devices and equipment")+`<div class="panel" id="as-body"></div>`;
  g$("as-body").innerHTML=tbl(["Asset","Name","Location","Last serviced","Status",""],a.assets.map(x=>`<tr><td class="mono">${x.id}</td><td>${esc(x.name)}</td><td>${esc(x.loc)}</td><td>${fmtDMY(x.serviced)}</td><td>${sChip(x.status)}</td><td style="white-space:nowrap">${x.status==="OK"?`<button class="btn btn-sm" data-a="rep" data-id="${x.id}">Mark faulty</button>`:`<button class="btn btn-sm" data-a="tk" data-id="${x.id}">Raise ticket</button> <button class="btn btn-sm" data-a="fix" data-id="${x.id}">Mark repaired</button>`}</td></tr>`));
  g$("as-body").onclick=e=>{ const b=e.target.closest("[data-id]"); if(!b) return; const x=a.assets.find(y=>y.id===b.dataset.id);
    if(b.dataset.a==="tk") tkForm({title:x.name+" ("+x.id+") needs attention",desc:x.name+" in "+x.loc+" is "+x.status.toLowerCase()+".",cat:x.type,pri:3});
    else { x.status=b.dataset.a==="fix"?"OK":"Faulty"; if(x.status==="OK") x.serviced=todayISO(); aLog(x.id+" marked "+x.status,x.id,"Admin"); saveState(); aAssets(); } }; }
function runBackup(){ const s=adm().services.find(x=>x.name==="Nightly backups"); s.status="Operational"; s.info="Last run "+todayISO()+" "+nowTimeStr(); aLog("Ran manual backup","","Admin"); saveState(); toast("Backup completed"); if(g$("hl-body")) aHealth(); }
function aHealth(){ const h=tEnsureView("health"), a=adm(), sv=a.services;
  h.innerHTML=tHead("System Health","Core Clinic OS services")+strip([[sv.filter(s=>s.status==="Operational").length,"Operational"],[sv.filter(s=>s.status==="Degraded").length,"Degraded"],[sv.filter(s=>s.status==="Down").length,"Down"]])+`<div class="panel" id="hl-body"></div>`;
  g$("hl-body").innerHTML=tbl(["Service","Status","Detail",""],sv.map(s=>`<tr><td><b>${esc(s.name)}</b></td><td>${sChip(s.status)}</td><td>${esc(s.info)}</td><td style="white-space:nowrap">${/backups/i.test(s.name)?'<button class="btn btn-sm" data-a="bk">Run backup</button>':""} ${s.status!=="Operational"?`<button class="btn btn-sm" data-a="rs" data-id="${s.id}">Restart service</button>`:""} ${s.status==="Operational"&&!/backups|security/i.test(s.name)?`<button class="btn btn-sm btn-ghost" data-a="dn" data-id="${s.id}">Simulate outage</button>`:""}</td></tr>`));
  g$("hl-body").onclick=e=>{ const b=e.target.closest("[data-a]"); if(!b) return; if(b.dataset.a==="bk") return runBackup(); const s=sv.find(x=>x.id===b.dataset.id);
    if(b.dataset.a==="rs"){ s.status="Operational"; s.info="Restarted "+nowTimeStr(); aLog("Restarted "+s.name,s.id,"Admin"); } else { s.status="Down"; s.info="Outage since "+nowTimeStr(); aLog("Outage simulated: "+s.name,s.id,"Admin"); const t=spawnTicket(false,{title:s.name+" is down",desc:"Monitoring reports "+s.name+" unavailable.",cat:"Infrastructure",pri:1,fixes:TPL[7].fixes}); t.req="Monitoring"; }
    saveState(); aHealth(); }; }

/* ---- Users, audit, approvals ---- */
function aUsers(){ const h=tEnsureView("users"), a=adm(), me=PEOPLE[ROLE].email;
  const perms=[["View and edit clinical records","–","✓","–","–"],["Patient registration and scheduling","✓","✓","✓","–"],["Inventory management","✓","–","✓","–"],["Approve purchase requests","–","–","✓","–"],["Assign staff roles","–","–","✓","–"],["Create and suspend accounts","–","–","✓","✓"],["Reset passwords and MFA","–","–","–","✓"],["View audit log (read-only)","–","–","✓","✓"],["Service desk, assets and system health","–","–","–","✓"]];
  h.innerHTML=tHead(ROLE==="owner"?"Staff & Access":"Users & Access",ROLE==="owner"?"Staff accounts and roles":"Accounts, passwords and sign-in security",`<button class="btn btn-primary" id="u-add">+ Add User</button>`)+`<div class="panel" style="margin-bottom:8px" id="u-body"></div><h3 class="section-title">Role permissions</h3><div class="panel">${tbl(["Capability"].concat(ROLES),perms.map(p=>`<tr><td>${p[0]}</td>${p.slice(1).map(c=>`<td>${c}</td>`).join("")}</tr>`))}</div>`;
  g$("u-body").innerHTML=tbl(["Name","Email","Role","Status","MFA","Last sign-in",""],a.users.map(u=>`<tr><td><b>${esc(u.name)}</b></td><td>${esc(u.email)}</td><td>${ROLE==="owner"?`<select class="input" data-a="role" data-id="${u.id}" style="padding:5px 8px">${ROLES.map(r=>`<option ${r===u.role?"selected":""}>${r}</option>`).join("")}</select>`:esc(u.role)}</td><td>${sChip(u.status)}</td><td>${u.mfa?"On":"Off"}</td><td>${fmtDMY(u.last)}</td><td style="white-space:nowrap">${ROLE==="it"?`<button class="btn btn-sm" data-a="pw" data-id="${u.id}">Reset password</button> `:""}<button class="btn btn-sm" data-a="sus" data-id="${u.id}">${u.status==="Active"?"Suspend":"Activate"}</button></td></tr>`));
  const on=e=>{ const b=e.target.closest("[data-a]"); if(!b) return; const u=a.users.find(x=>x.id===b.dataset.id), k=b.dataset.a;
    if(k==="pw"){ aLog("Password reset for "+u.name,u.id); toast("Reset link sent to "+u.email); }
    else if(k==="sus"){ if(u.email===me){ toast("You can't suspend your own account"); return; } u.status=u.status==="Active"?"Suspended":"Active"; aLog(u.status+" account: "+u.name,u.id); }
    else if(k==="role"&&e.type==="change"){ aLog("Role of "+u.name+" changed from "+u.role+" to "+b.value,u.id); u.role=b.value; toast("Role updated"); } else return;
    saveState(); aUsers(); };
  g$("u-body").onclick=on; g$("u-body").onchange=on; g$("u-add").onclick=userForm; }
function userForm(){ showModal(modalTemplate("Add User",`<div class="field"><label>Full name</label><input class="input" id="nu-n"></div><div class="field"><label>Email</label><input class="input" id="nu-e"></div><div class="field"><label>Role</label><select class="input" id="nu-r">${ROLES.map(r=>`<option>${r}</option>`).join("")}</select></div><div class="hint">A sign-in invitation with enforced MFA setup is sent to the new user.</div>`,
  [{label:"Cancel",cls:"btn-ghost",action:closeModal},{label:"Add user",cls:"btn-primary",action:()=>{ const n=val("nu-n").trim(), e=val("nu-e").trim();
    if(!n||!/\S+@\S+\.\S+/.test(e)){ toast("Enter a name and a valid email address"); return; } adm().users.push({id:uid("U"),name:n,role:val("nu-r"),email:e,status:"Active",mfa:false,last:todayISO()}); aLog("Created account for "+n+" ("+val("nu-r")+")",e);
    saveState(); closeModal(); if(state.ui.view==="users") aUsers(); toast("User added"); }}])); }
function aAudit(){ const h=tEnsureView("audit"), st=state.ui, okSrc=ROLE==="owner"?["Clinical","Admin"]:["Admin","Service desk"]; if(!okSrc.includes(st.auf)) st.auf="all";
  const ev=adm().audit.map(x=>({at:x.at,by:x.by,act:x.act,ref:x.ref,src:x.src})).concat(C().audit.map(x=>({at:x.at,by:MYNAME,act:x.act,ref:x.ref,src:"Clinical"}))).filter(x=>okSrc.includes(x.src)&&(st.auf==="all"||x.src===st.auf)).sort((x,y)=>x.at<y.at?1:-1);
  h.innerHTML=tHead("Audit Log","Immutable record of clinical, administrative and service desk actions")+`<div class="panel"><div class="dir-toolbar"><select class="input" id="au-f" style="max-width:200px">${["all"].concat(okSrc).map(s=>`<option value="${s}" ${st.auf===s?"selected":""}>${s==="all"?"All sources":s}</option>`).join("")}</select><span class="dir-count">${ev.length} entries</span></div>${ev.length?tbl(["When","Actor","Action","Reference","Source"],ev.slice(0,200).map(x=>`<tr><td class="mono">${stampStr(x.at)}</td><td>${esc(x.by)}</td><td>${esc(x.act)}</td><td class="mono">${esc(x.ref)}</td><td>${x.src}</td></tr>`)):'<div class="empty-note">No entries yet.</div>'}</div>`;
  g$("au-f").onchange=e=>{ st.auf=e.target.value; aAudit(); }; }
function prAct(id,k){ const r=state.purchaseRequests.find(x=>x.id===id), nm={ap:"Approved",rj:"Cancelled",od:"Ordered",rc:"Received"}[k]; r.status=nm;
  if(k==="rc") r.items.forEach(it=>{ const i=itemById(it.itemId); i.qty+=it.qty; state.inventoryTransactions.unshift({id:uid("TX"),itemId:i.id,type:"Stock Added",qty:it.qty,date:todayISO(),user:PEOPLE[ROLE].name,reason:"Purchase "+r.id}); });
  aLog("Purchase request "+id+" → "+nm,id,"Admin"); saveState(); aApprovals(); refreshBadges(); toast(id+" marked "+nm); }
function aApprovals(){ const h=tEnsureView("approvals"), pr=state.purchaseRequests, n=s=>pr.filter(x=>x.status===s).length;
  h.innerHTML=tHead("Approvals","Purchase requests above the approval threshold need sign-off")+strip([[n("Submitted"),"Awaiting approval"],[n("Approved"),"Approved"],[n("Ordered"),"Ordered"],[n("Received"),"Received"]])
  +`<div class="panel" style="margin-bottom:22px"><div class="panel-body pad" style="display:flex;gap:12px;align-items:end;flex-wrap:wrap"><div class="field" style="margin:0"><label>Approval threshold ($)</label><input class="input" type="number" min="0" id="ap-th" value="${THRESH()}"></div><button class="btn" id="ap-save">Save threshold</button></div></div><div class="panel" id="ap-body"></div>`;
  g$("ap-body").innerHTML=tbl(["Request","Items","Supplier","Est. cost","Requested by","Date","Status",""],pr.slice().reverse().map(r=>`<tr><td>${r.id}</td><td>${r.items.map(it=>esc(itemById(it.itemId).name)+" ×"+it.qty).join(", ")}</td><td>${esc(supplierById(r.supplier).name)}</td><td>$${r.estCost.toFixed(2)}</td><td>${esc(r.requestedBy)}</td><td>${fmtDMY(r.date)}</td><td><span class="chip chip-${statusClass(r.status)}">${r.status}</span></td><td style="white-space:nowrap">${r.status==="Submitted"?`<button class="btn btn-primary btn-sm" data-k="ap" data-id="${r.id}">Approve</button> <button class="btn btn-sm" data-k="rj" data-id="${r.id}">Reject</button>`:r.status==="Approved"?`<button class="btn btn-sm" data-k="od" data-id="${r.id}">Mark ordered</button>`:r.status==="Ordered"?`<button class="btn btn-sm" data-k="rc" data-id="${r.id}">Mark received</button>`:""}</td></tr>`));
  g$("ap-body").onclick=e=>{ const b=e.target.closest("[data-k]"); if(b) prAct(b.dataset.id,b.dataset.k); };
  g$("ap-save").onclick=()=>{ const v=+g$("ap-th").value; if(!(v>=0)){ toast("Enter a valid amount"); return; } adm().threshold=v; aLog("Approval threshold set to $"+v,""); saveState(); toast("Threshold saved"); }; }

/* ---- Owner overview ---- */
function aOwner(){
  const h=tEnsureView("dashboard"), t=todayISO(), ws=weekStart(t), we=addDays(ws,6), a=adm(), act=x=>x.status!=="cancelled";
  const wk=state.appointments.filter(x=>x.date>=ws&&x.date<=we&&act(x)), past=state.appointments.filter(x=>x.date>=addDays(t,-30)&&x.date<=t&&act(x)), ns=past.filter(x=>x.status==="noshow").length;
  const pend=state.purchaseRequests.filter(r=>r.status==="Submitted"), low=state.inventoryItems.filter(i=>["lowstock","outstock"].includes(invStatus(i))), op=a.tickets.filter(x=>x.status!=="Resolved"), br=op.filter(x=>remMin(x)<0), rev=dueReviews();
  const al=[]; pend.forEach(r=>al.push(["Purchase request "+r.id+" awaiting approval","$"+r.estCost.toFixed(2)+" · "+supplierById(r.supplier).name,"approvals"])); low.slice(0,3).forEach(i=>al.push([i.name+" is "+(i.qty?"low":"out of stock"),i.qty+" "+i.unit+" · minimum "+i.min,"rx-inventory"])); rev.forEach(p=>al.push(["Treatment plan review due — "+patientName(p.pid),p.condition+" · "+fmtDMY(p.review),"rx-patients"]));
  h.innerHTML=`<div class="dash-head"><div><h1>Good morning, Nyasha</h1><div class="dash-meta"><span>${fmtDateLong(t)}</span></div></div><button class="btn btn-primary" data-v="rx-calendar">Open Calendar</button></div>
  <div class="stat-strip">${[[wk.length,"Appointments this week","rx-calendar"],[past.length?Math.round(ns/past.length*100)+"%":"0%","No-show rate (30d)","rx-calendar"],[C().plans.filter(p=>p.status==="Active").length,"Active treatment plans","rx-patients"],[pend.length,"Pending approvals","approvals"],[low.length,"Low-stock items","rx-inventory"],[state.patients.filter(p=>p.createdAt>=addDays(t,-7)).length,"New patients (7d)","rx-patients"]].map(([n,l,v])=>`<div class="stat" data-v="${v}"><div class="n">${n}</div><div class="l">${l}</div></div>`).join("")}</div>
  <div class="dash-grid"><div class="panel"><div class="panel-head"><h3>Therapist workload</h3></div><div id="ow-th"></div></div><div class="dash-side"><div class="panel"><div class="panel-head"><h3>Needs your attention</h3></div><div class="panel-body" id="ow-al"></div></div></div></div><p class="hint" style="margin-top:18px">Billing and revenue reporting aren't enabled for this clinic yet.</p>`;
  g$("ow-th").innerHTML=tbl(["Therapist","Today","This week","Utilisation","Patients","Active plans"],ALL_TH.map(th=>{ const w=wk.filter(x=>x.therapist===th.id), mins=w.reduce((s,x)=>s+timeToMin(x.end)-timeToMin(x.start),0), pts=state.patients.filter(p=>p.therapist===th.id).map(p=>p.id);
    return `<tr><td><b>${esc(th.name)}</b></td><td>${apptsOn(t).filter(x=>x.therapist===th.id).length}</td><td>${w.length}</td><td>${Math.round(mins/2700*100)}%</td><td>${pts.length}</td><td>${C().plans.filter(p=>p.status==="Active"&&pts.includes(p.pid)).length}</td></tr>`; }));
  g$("ow-al").innerHTML=al.length?al.map((x,i)=>`<div class="notif-mini" data-v="${x[2]}" style="cursor:pointer"><div class="t">${esc(x[0])}</div><div class="d">${esc(x[1])}</div></div>`).join(""):'<div class="empty-note">Nothing needs attention.</div>';
  h.querySelectorAll("[data-v]").forEach(b=>b.onclick=()=>setView(b.dataset.v)); }

/* ---- Role plumbing for all four portals ---- */
const isAdmin=()=>ROLE==="owner"||ROLE==="it";
function aRender(v){ const m={dashboard:()=>ROLE==="it"?aServiceDesk():aOwner(),servicedesk:aServiceDesk,approvals:aApprovals,team:aTeam,assets:aAssets,health:aHealth,users:aUsers,audit:aAudit,"rx-calendar":renderCalendar,"rx-patients":renderPatients,"rx-inventory":renderInventory};
  (m[v]||(()=>renderPlaceholder(v,v==="help"?"Help &amp; Support":"Settings","This area is available in the full Clinic OS build.")))(); }
g$("qa-menu").addEventListener("click",e=>{ const b=e.target.closest("[data-aqa]"); if(!b) return; g$("qa-menu").classList.add("hidden"); ({ticket:()=>tkForm(),user:userForm,backup:runBackup}[b.dataset.aqa])(); });

(function migrate(){ const t=todayISO();
  if(!state.seedDate||!state.clin){ state=seedState(); seedClinical(); seedAdmin(); state.seedDate=t; }
  else if(state.seedDate!==t){ const d=Math.round((new Date(t+"T00:00:00")-new Date(state.seedDate+"T00:00:00"))/864e5), walk=o=>{ for(const k in o){ const v=o[k]; if(k==="dob") continue; if(typeof v==="string"){ if(/^\d{4}-\d\d-\d\d$/.test(v)) o[k]=addDays(v,d); } else if(v&&typeof v==="object") walk(v); } }; walk(state); state.seedDate=t; }
  if(!state.admin) seedAdmin(); saveState(); })();
g$("sidebar").addEventListener("click",e=>{ const it=e.target.closest(".sb-item[data-view]"); if(it) setView(it.dataset.view); });
g$("qa-menu").addEventListener("click",e=>{ const b=e.target.closest("[data-tqa]"); if(b){ g$("qa-menu").classList.add("hidden"); tQuick(b.dataset.tqa); } });
g$("login-btn").addEventListener("click",()=>{ const em=g$("login-email").value.toLowerCase(); setRole(detectRole(em),true); },true);
window.addEventListener("afterprint",()=>document.body.classList.remove("pr"));

init();
})();
